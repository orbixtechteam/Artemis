# The Longevity Clinic: Third Brain and Jarvis

Everything that runs the clinic's AI: the **Third Brain** dashboard, **Jarvis** (Noah's AI chief of staff on OpenClaw), and the automations around them.

| Folder | What it is | Runs on |
| --- | --- | --- |
| [`dashboard/`](dashboard/) | Third Brain: Next.js 15 app with chat, MCP server (OAuth), playbooks, rules, approvals, WhatsApp (Periskope), automations | VPS, PM2 app `ai-brain`, port 3900, behind Cloudflare Tunnel at https://ai-brain.thelongevityclinic.net |
| [`jarvis/`](jarvis/) | Jarvis's server side: scripts, cron wrappers, workspace instructions, playbooks, OpenClaw config (secrets removed) | VPS, OpenClaw gateway |
| [`automations/`](automations/) | Stand-alone automations (email attachments to Drive, payment summaries to WhatsApp, Zapier workflows) | VPS / Zapier |
| [`docs/`](docs/) | Architecture and runbook | |

## First time on a new machine

```bash
git clone <repo-url> && cd tlc-third-brain
git config core.hooksPath .githooks      # turns on the secret scan before every commit
cd dashboard && pnpm install && cp .env.example .env   # fill .env for local use only
```

## Rules for this repo

- **No secrets in git.** API keys, tokens, passwords and OAuth secrets live only in `.env` on the server (and in OpenClaw's own config). The pre-commit hook (`scripts/secret-scan.sh`) refuses commits that look like secrets.
- **No patient data in git.** No databases, uploads, Jarvis memory or exports.
- **Jarvis changes on the server come back with** `bash jarvis/collect.sh`, then review and commit.
- **Deploy the dashboard** with `bash dashboard/scripts/deploy.sh` (from `dashboard/`). See [docs/runbook.md](docs/runbook.md).
