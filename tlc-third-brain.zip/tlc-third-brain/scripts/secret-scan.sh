#!/bin/bash
# Refuses to commit anything that looks like a secret. Runs as the pre-commit hook and by hand: bash scripts/secret-scan.sh
set -uo pipefail
cd "$(git rev-parse --show-toplevel 2>/dev/null || dirname "$0"/..)"
FILES=$( (git diff --cached --name-only --diff-filter=ACM 2>/dev/null; [ "${1:-}" = "--all" ] && git ls-files 2>/dev/null) | sort -u | grep -v -E '(pnpm-lock\.yaml|secret-scan\.sh)$' )
[ -z "$FILES" ] && FILES=$(find . -type f -not -path './.git/*' -not -path '*/node_modules/*' -not -name pnpm-lock.yaml -not -name secret-scan.sh)
PATTERN='sk-ant-[A-Za-z0-9_-]{10,}|xox[abprs]-[A-Za-z0-9-]{10,}|GOCSPX-[A-Za-z0-9_-]{10,}|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{30,}|tb_[A-Za-z0-9_-]{24,}|-----BEGIN [A-Z ]*PRIVATE KEY-----|"(refresh_token|client_secret|access_token)"[[:space:]]*:[[:space:]]*"[^"<]{12,}'
HITS=$(echo "$FILES" | xargs -r grep -nIE "$PATTERN" 2>/dev/null | cut -c1-160)
if [ -n "$HITS" ]; then
  echo "Possible secrets found, commit refused:"; echo "$HITS"
  echo "Remove them (put them in .env on the server), then commit again."
  exit 1
fi
echo "secret scan: clean"
