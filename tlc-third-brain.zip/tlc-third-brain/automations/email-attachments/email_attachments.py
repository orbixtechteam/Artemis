#!/usr/bin/env python3
"""
Patient files that arrive by email → saved straight into the patient's Drive folder, any size.
Claude then picks them up from Drive (unlock, translate, summarise) as before.

Matching: a remembered sender, else the sender's name or the email text matched against the patient
folder names. No unique match → "Unsorted patient files". When someone drags such a file into the right
patient folder in Drive, the next run notices and remembers that sender for next time.

Usage:
  email_attachments.py --check            # test Google access and the patients folder
  email_attachments.py --days 14 --dry-run  # show what would be saved, change nothing
  email_attachments.py                    # normal run (cron, every 10 minutes)
  email_attachments.py --assign <file id> "<patient folder name>"   # file one from Unsorted and remember the sender
"""
import argparse, base64, datetime as dt, json, os, re, subprocess, sys, unicodedata, urllib.parse, urllib.request
from email.utils import parseaddr

# ---------- settings (override with environment variables) ----------
CREDS = os.environ.get("GOOGLE_CREDS_FILE", "/root/.google_workspace_mcp/credentials/noah@thelongevityclinic.net.json")
PATIENTS_ROOT = os.environ.get("PATIENTS_ROOT_FOLDER_ID", "")          # Drive folder that holds one folder per patient
STATE_DIR = os.environ.get("ATTACH_STATE_DIR", "/root/.email-attachments")
SENDERS = os.environ.get("ATTACH_SENDERS_FILE", "/root/.email-attachments/senders.json")
UNSORTED_NAME = "Unsorted patient files"
QUERY = os.environ.get("ATTACH_QUERY", "has:attachment -in:sent -in:chats -category:promotions -category:social -category:forums")
KEEP_EXT = {"pdf", "jpg", "jpeg", "png", "heic", "heif", "tif", "tiff", "doc", "docx", "xls", "xlsx", "csv", "txt", "rtf", "zip", "dcm", "odt"}
SKIP_SUBJECT = re.compile(r"\b(invoice|receipt|factura|rechnung|payment confirmation|order confirmation|newsletter|unsubscribe|webinar)\b", re.I)
SKIP_SENDER = re.compile(r"(no-?reply|noreply|notifications?@|mailer-daemon|calendar-notification|@(stripe|whop|paypal|zoom|slack|asana|google)\.com$)", re.I)
INTERNAL_DOMAIN = "@thelongevityclinic.net"
MIN_IMAGE_BYTES = 40_000  # skips logos and signature images

# ---------- Google ----------
_token = None
def token():
    global _token
    if _token: return _token
    c = json.load(open(CREDS))
    body = urllib.parse.urlencode({"client_id": c["client_id"], "client_secret": c["client_secret"], "refresh_token": c["refresh_token"], "grant_type": "refresh_token"}).encode()
    r = json.load(urllib.request.urlopen(urllib.request.Request(c.get("token_uri") or "https://oauth2.googleapis.com/token", data=body), timeout=30))
    _token = r["access_token"]
    return _token

def api(url, method="GET", data=None, headers=None, raw=False, timeout=120):
    h = {"Authorization": f"Bearer {token()}", **(headers or {})}
    if isinstance(data, (dict, list)): data, h["Content-Type"] = json.dumps(data).encode(), "application/json; charset=UTF-8"
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r if raw else json.loads(r.read() or b"{}")

G = "https://gmail.googleapis.com/gmail/v1/users/me"
D = "https://www.googleapis.com/drive/v3/files"
DRIVE_OPTS = "supportsAllDrives=true&includeItemsFromAllDrives=true"

def scopes():
    r = json.load(urllib.request.urlopen(f"https://oauth2.googleapis.com/tokeninfo?access_token={token()}", timeout=30))
    return set(r.get("scope", "").split())

def drive_list(q, fields="files(id,name,appProperties)"):
    out, page = [], ""
    while True:
        r = api(f"{D}?q={urllib.parse.quote(q)}&fields=nextPageToken,{fields}&pageSize=1000&{DRIVE_OPTS}{'&pageToken=' + page if page else ''}")
        out += r.get("files", []); page = r.get("nextPageToken")
        if not page: return out

def ensure_folder(name, parent):
    q = f"'{parent}' in parents and name = '{name}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
    found = drive_list(q, "files(id,name)")
    if found: return found[0]["id"]
    return api(f"{D}?{DRIVE_OPTS}&fields=id", "POST", {"name": name, "mimeType": "application/vnd.google-apps.folder", "parents": [parent]})["id"]

def already_saved(key):
    q = f"appProperties has {{ key='gmailAttachment' and value='{key}' }} and trashed = false"
    return drive_list(q, "files(id,name,parents)")

def upload(folder, name, mime, data: bytes, props):
    meta = {"name": name, "parents": [folder], "appProperties": props}
    start = urllib.request.Request(f"https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&{DRIVE_OPTS}&fields=id,webViewLink",
        data=json.dumps(meta).encode(), method="POST",
        headers={"Authorization": f"Bearer {token()}", "Content-Type": "application/json; charset=UTF-8", "X-Upload-Content-Type": mime, "X-Upload-Content-Length": str(len(data))})
    with urllib.request.urlopen(start, timeout=60) as r: loc = r.headers["Location"]
    put = urllib.request.Request(loc, data=data, method="PUT", headers={"Content-Type": mime, "Content-Length": str(len(data))})
    with urllib.request.urlopen(put, timeout=600) as r: return json.loads(r.read())

# ---------- Gmail ----------
def header(msg, name):
    return next((h["value"] for h in msg["payload"].get("headers", []) if h["name"].lower() == name.lower()), "")

def parts(p):
    yield p
    for c in p.get("parts", []) or []: yield from parts(c)

def text_body(msg, limit=3000):
    for p in parts(msg["payload"]):
        if p.get("mimeType") == "text/plain" and p.get("body", {}).get("data"):
            return base64.urlsafe_b64decode(p["body"]["data"]).decode("utf-8", "ignore")[:limit]
    return msg.get("snippet", "")

def attachments(msg):
    for p in parts(msg["payload"]):
        fn, body = p.get("filename") or "", p.get("body", {})
        if not fn or not body.get("attachmentId"): continue
        ext = fn.rsplit(".", 1)[-1].lower() if "." in fn else ""
        if ext not in KEEP_EXT: continue
        if p.get("mimeType", "").startswith("image/") and body.get("size", 0) < MIN_IMAGE_BYTES: continue
        yield {"name": fn, "mime": p.get("mimeType") or "application/octet-stream", "size": body.get("size", 0), "id": body["attachmentId"]}

def download(msg_id, att_id):
    r = api(f"{G}/messages/{msg_id}/attachments/{att_id}", timeout=300)
    return base64.urlsafe_b64decode(r["data"])

# ---------- matching ----------
def norm_tokens(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower()
    return [t for t in re.findall(r"[a-z]+", s) if len(t) > 1]

def load_json(path, default):
    try: return json.load(open(path))
    except Exception: return default

def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"; json.dump(obj, open(tmp, "w"), indent=1); os.replace(tmp, path)

def match_folder(folders, senders, from_email, from_name, text):
    if from_email in senders: return senders[from_email], "remembered sender"
    name_t = set(norm_tokens(from_name))
    if len(name_t) >= 2:
        hits = [f for f in folders if name_t <= set(norm_tokens(f["name"]))] or [f for f in folders if set(norm_tokens(f["name"])) and set(norm_tokens(f["name"])) <= name_t]
        if len(hits) == 1: return hits[0]["id"], "sender name"
    words = set(norm_tokens(text))
    hits = [f for f in folders if len(set(norm_tokens(f["name"]))) >= 2 and set(norm_tokens(f["name"])) <= words]
    if len(hits) == 1: return hits[0]["id"], "name in the email"
    return None, "no unique match"

def learn_from_moves(state, senders, folder_ids):
    """Files someone dragged out of Unsorted into a patient folder teach us that sender."""
    learned = []
    for fid, sender in list(state.get("unsorted", {}).items()):
        try:
            meta = api(f"{D}/{fid}?fields=parents,trashed&{DRIVE_OPTS}")
        except Exception:
            state["unsorted"].pop(fid, None); continue
        parent = next((p for p in meta.get("parents", []) if p in folder_ids), None)
        if meta.get("trashed"): state["unsorted"].pop(fid, None)
        elif parent:
            if sender and not sender.endswith(INTERNAL_DOMAIN): senders[sender] = parent
            state["unsorted"].pop(fid, None); learned.append((sender, folder_ids[parent]))
    return learned

# ---------- main ----------
def run(days, dry):
    if not PATIENTS_ROOT: sys.exit("Set PATIENTS_ROOT_FOLDER_ID (the Drive folder with one folder per patient).")
    state = load_json(f"{STATE_DIR}/state.json", {"done": {}, "unsorted": {}})
    state.setdefault("unsorted", {})
    senders = load_json(SENDERS, {})
    folders = drive_list(f"'{PATIENTS_ROOT}' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false", "files(id,name)")
    folders = [f for f in folders if f["name"] != UNSORTED_NAME]
    by_id = {f["id"]: f["name"] for f in folders}
    learned = [] if dry else learn_from_moves(state, senders, by_id)
    if learned: save_json(SENDERS, senders)
    q = f"{QUERY} newer_than:{days}d"
    ids, page = [], ""
    while True:
        r = api(f"{G}/messages?q={urllib.parse.quote(q)}&maxResults=100{'&pageToken=' + page if page else ''}")
        ids += [m["id"] for m in r.get("messages", [])]; page = r.get("nextPageToken")
        if not page or len(ids) >= 500: break

    saved, unsorted, problems = [], [], []
    for mid in reversed(ids):  # oldest first
        if mid in state["done"]: continue
        msg = api(f"{G}/messages/{mid}?format=full")
        from_name, from_email = parseaddr(header(msg, "From")); from_email = from_email.lower()
        subject = header(msg, "Subject")
        files = list(attachments(msg))
        skip = not files or SKIP_SENDER.search(from_email) or SKIP_SUBJECT.search(subject)
        if skip:
            state["done"][mid] = "skipped"; continue
        body = text_body(msg)
        folder, how = match_folder(folders, senders, from_email, from_name, f"{subject} {body} {' '.join(f['name'] for f in files)}")
        date = dt.datetime.fromtimestamp(int(msg["internalDate"]) / 1000).strftime("%Y-%m-%d")
        for a in files:
            key = f"{mid}:{a['id'][:40]}"
            if already_saved(key): continue
            target = folder or (ensure_folder(UNSORTED_NAME, PATIENTS_ROOT) if not dry else "UNSORTED")
            label = by_id.get(folder, UNSORTED_NAME)
            if dry:
                print(f"[dry-run] {date} {from_email} '{a['name']}' ({a['size'] // 1024} KB) → {label} ({how})"); continue
            try:
                data = download(mid, a["id"])
                f = upload(target, f"{date} – {a['name']}", a["mime"], data,
                           {"gmailAttachment": key, "from": from_email[:100], "subject": subject[:100]})
            except Exception as e:
                problems.append(f"{a['name']} from {from_email}: {str(e)[:120]}"); continue
            if folder:
                saved.append(f"{label}: {a['name']} ({len(data) // 1024} KB)")
            else:
                state["unsorted"][f["id"]] = from_email
                unsorted.append(f"{a['name']} from {from_name or from_email} <{from_email}>, subject “{subject[:60]}” → {f.get('webViewLink', '')}")
        if not dry: state["done"][mid] = "ok"

    if dry: return
    # keep the state file small: forget messages older than 30 days
    state["done"] = dict(list(state["done"].items())[-5000:])
    save_json(f"{STATE_DIR}/state.json", state)
    with open(f"{STATE_DIR}/log.csv", "a") as log:
        for s in saved: log.write(f"{dt.datetime.now():%Y-%m-%d %H:%M},saved,\"{s}\"\n")
        for u in unsorted: log.write(f"{dt.datetime.now():%Y-%m-%d %H:%M},unsorted,\"{u}\"\n")
        for p in problems: log.write(f"{dt.datetime.now():%Y-%m-%d %H:%M},problem,\"{p}\"\n")

    stamp = f"{dt.datetime.now():%Y-%m-%d %H:%M}"
    for s_ in saved: print(f"{stamp} saved      {s_}")
    for u in unsorted: print(f"{stamp} unsorted   {u}")
    for snd, name in learned: print(f"{stamp} learned    {snd} → {name}")
    for p in problems: print(f"{stamp} PROBLEM    {p}")

def assign(file_id, patient):
    senders = load_json(SENDERS, {})
    folders = drive_list(f"'{PATIENTS_ROOT}' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false", "files(id,name)")
    want = set(norm_tokens(patient))
    hits = [f for f in folders if want and want <= set(norm_tokens(f["name"]))]
    if len(hits) != 1: sys.exit(f"Found {len(hits)} folders for “{patient}”. Use the exact folder name.")
    meta = api(f"{D}/{file_id}?fields=id,name,parents,appProperties&{DRIVE_OPTS}")
    api(f"{D}/{file_id}?addParents={hits[0]['id']}&removeParents={','.join(meta.get('parents', []))}&{DRIVE_OPTS}", "PATCH", {})
    sender = (meta.get("appProperties") or {}).get("from")
    if sender and not sender.endswith(INTERNAL_DOMAIN):
        senders[sender] = hits[0]["id"]; save_json(SENDERS, senders)
    print(f"Filed {meta['name']} under {hits[0]['name']}" + (f"; future emails from {sender} go there automatically" if sender else ""))

def check():
    s = scopes()
    print("Google scopes:", " ".join(sorted(x.rsplit("/", 1)[-1] for x in s)))
    need_gmail = any(x.endswith(("gmail.readonly", "gmail.modify", "mail.google.com/")) for x in s)
    need_drive = any(x.endswith("/auth/drive") for x in s)
    print("Gmail read:", "ok" if need_gmail else "MISSING")
    print("Drive write into existing folders (full drive):", "ok" if need_drive else "MISSING – re-authorise the Google connector with drive:full, or give this script its own token")
    if PATIENTS_ROOT:
        f = api(f"{D}/{PATIENTS_ROOT}?fields=id,name&{DRIVE_OPTS}")
        n = len(drive_list(f"'{PATIENTS_ROOT}' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false", "files(id)"))
        print(f"Patients folder: {f['name']} ({n} patient folders)")
    else:
        print("PATIENTS_ROOT_FOLDER_ID: not set")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=2)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--assign", nargs=2, metavar=("FILE_ID", "PATIENT"))
    a = ap.parse_args()
    os.makedirs(STATE_DIR, exist_ok=True)
    if a.check: check()
    elif a.assign: assign(*a.assign)
    else: run(a.days, a.dry_run)
