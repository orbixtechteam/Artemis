#!/bin/bash
# Run on the server: bash install.sh <Drive folder id that holds one folder per patient>
set -euo pipefail
FOLDER="${1:-}"; [ -n "$FOLDER" ] || { echo "Usage: bash install.sh <patients folder id>"; exit 1; }
mkdir -p /opt/email-attachments /root/.email-attachments
cp "$(dirname "$0")/email_attachments.py" /opt/email-attachments/
echo "PATIENTS_ROOT_FOLDER_ID=$FOLDER" > /root/.email-attachments/env
cat > /usr/local/bin/email-attachments << 'X'
#!/bin/bash
set -a; . /root/.email-attachments/env; set +a
exec flock -n /root/.email-attachments/.lock python3 /opt/email-attachments/email_attachments.py "$@"
X
chmod +x /usr/local/bin/email-attachments

echo "== Access check"; email-attachments --check
echo; echo "== What it would save from the last 14 days (nothing is changed)"
email-attachments --days 14 --dry-run | head -40
echo
echo "Looks right? Turn it on (every 10 minutes):"
echo "  ( crontab -l 2>/dev/null | grep -v email-attachments; echo '*/10 * * * * /usr/local/bin/email-attachments >> /var/log/email-attachments.log 2>&1' ) | crontab -"
