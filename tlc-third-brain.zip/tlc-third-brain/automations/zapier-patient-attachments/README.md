# Zapier: patient email attachments to Drive

Saves patient attachments from three Gmail inboxes into the patient's folder under **MASTER CLIENT FOLDERS** (paying clients first, then *Sales calls*). New personal senders get a `Name [Sales]` folder; company senders and unmatched team forwards go to *Unsorted patient files*.

| Inbox | Workflow |
| --- | --- |
| noah@ | https://zapier.com/workflow/01a1ca32-f769-74cc-b7ff-a00cc641346c |
| silvana@ | https://zapier.com/workflow/01a1ca59-0039-7687-b0cb-cdc99d170672 |
| clinic@ | https://zapier.com/workflow/01a1ca5f-6a62-7ac8-b58d-1095ddb1d84c |

The source (`workflow.ts`, `lib/match.ts`) lives in Zapier's workflow editor; the three are identical apart from the Gmail trigger account. Drive writes use the operations@ connection (owner of MASTER CLIENT FOLDERS).
