#!/usr/bin/env python3
"""
Payment summary → Noah's WhatsApp.

The payment summary job already posts each summary as a reply in the payment's thread in
#sales-payment-made. This job finds summaries the bot posted since the last run and prints them,
so the OpenClaw cron delivers them to Noah's WhatsApp self-chat. Nothing new → prints NO_REPLY.
The Slack flow itself is not touched.

  payment_to_whatsapp.py            normal run (cron, every 5 minutes)
  payment_to_whatsapp.py --init     mark everything that exists now as already sent (run once at install)
  payment_to_whatsapp.py --test     print the latest summary without marking it (for a test message)
"""
import json, os, sys, time, urllib.parse, urllib.request

CONFIG = os.environ.get("OPENCLAW_CONFIG", "/root/.openclaw/openclaw.json")
CHANNEL_NAME = os.environ.get("PAYMENT_CHANNEL", "sales-payment-made")
STATE = os.environ.get("PAYMENT_WA_STATE", "/root/.jarvis/payments/whatsapp_sent.json")
LOOKBACK_DAYS = 3

def token():
    return json.load(open(CONFIG))["mcp"]["servers"]["slack"]["env"]["SLACK_MCP_XOXB_TOKEN"]

def api(method, **params):
    for attempt in range(4):
        req = urllib.request.Request(f"https://slack.com/api/{method}?{urllib.parse.urlencode(params)}",
                                     headers={"Authorization": f"Bearer {token()}"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                d = json.loads(r.read())
        except urllib.error.HTTPError as e:
            if e.code == 429 and attempt < 3:
                time.sleep(int(e.headers.get("Retry-After", 5))); continue
            raise
        if d.get("ok"):
            return d
        if d.get("error") == "ratelimited" and attempt < 3:
            time.sleep(5); continue
        raise RuntimeError(f"Slack {method}: {d.get('error')}")

def channel_id():
    cursor = ""
    for _ in range(10):
        d = api("conversations.list", types="public_channel,private_channel", limit=1000, exclude_archived="true", cursor=cursor)
        for c in d["channels"]:
            if c["name"] == CHANNEL_NAME:
                return c["id"]
        cursor = d.get("response_metadata", {}).get("next_cursor")
        if not cursor:
            break
    raise RuntimeError(f"Channel #{CHANNEL_NAME} not found or the bot isn't in it.")

def load():
    try:
        return set(json.load(open(STATE)))
    except Exception:
        return set()

def save(seen):
    os.makedirs(os.path.dirname(STATE), exist_ok=True)
    json.dump(sorted(seen)[-5000:], open(STATE, "w"))

def bot_summaries(ch, bot_user):
    """(ts, text, parent_ts) of replies the bot wrote in payment threads of the last few days."""
    oldest = str(time.time() - LOOKBACK_DAYS * 86400)
    out, cursor = [], ""
    for _ in range(10):
        d = api("conversations.history", channel=ch, oldest=oldest, limit=200, cursor=cursor)
        for m in d.get("messages", []):
            if not m.get("reply_count"):
                continue
            for r in api("conversations.replies", channel=ch, ts=m["ts"], limit=200).get("messages", [])[1:]:
                if r.get("user") == bot_user or r.get("bot_id") and r.get("user") in (None, bot_user):
                    if len(r.get("text", "")) > 80:  # summaries, not short acks
                        out.append((r["ts"], r["text"], m["ts"], m.get("text", "")))
        cursor = d.get("response_metadata", {}).get("next_cursor")
        if not cursor:
            break
    return sorted(out)

def clean(text):
    # Slack formatting → plain WhatsApp text
    for a, b in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">")):
        text = text.replace(a, b)
    return text.strip()

def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    ch = channel_id()
    me = api("auth.test")["user_id"]
    items = bot_summaries(ch, me)
    seen = load()
    if mode == "--init":
        save(seen | {ts for ts, *_ in items}); print(f"Marked {len(items)} existing summaries as sent."); return
    if mode == "--test":
        if not items: print("No payment summary in the last days."); return
        ts, text, parent, payment = items[-1]
        print(f"💳 Payment summary (test)\n\n{clean(text)}"); return
    new = [i for i in items if i[0] not in seen]
    if not new:
        print("NO_REPLY"); return
    parts = []
    for ts, text, parent, payment in new[:5]:
        link = api("chat.getPermalink", channel=ch, message_ts=ts).get("permalink", "")
        head = clean(payment).splitlines()[0][:120] if payment else "New payment"
        parts.append(f"💳 {head}\n\n{clean(text)}\n\n{link}")
        seen.add(ts)
    if len(new) > 5:
        parts.append(f"(+{len(new) - 5} more in #{CHANNEL_NAME})")
        seen |= {i[0] for i in new}
    save(seen)
    print("\n\n———\n\n".join(parts))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # never send errors to Noah; log them for the run monitor / Ulvi
        os.makedirs("/var/log", exist_ok=True)
        with open("/var/log/payment-to-whatsapp.log", "a") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M')} {str(e)[:300]}\n")
        print("NO_REPLY")
