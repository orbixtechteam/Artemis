#!/bin/bash
# Run on the server: bash install.sh
set -euo pipefail
export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH
cp "$(dirname "$0")/payment_to_whatsapp.py" /root/jarvis/payment_to_whatsapp.py
printf '#!/bin/sh\nexec python3 /root/jarvis/payment_to_whatsapp.py "$@"\n' > /usr/local/bin/jarvis-payment-whatsapp
chmod +x /usr/local/bin/jarvis-payment-whatsapp

echo "== Latest summary (test, nothing is sent):"
jarvis-payment-whatsapp --test | head -20
echo
echo "== Mark existing summaries as already sent (only new ones will reach WhatsApp):"
jarvis-payment-whatsapp --init

openclaw cron list --json 2>/dev/null | grep -q '"Payment summary to WhatsApp"' || \
openclaw cron create "*/5 * * * *" --name "Payment summary to WhatsApp" \
  --command "/usr/local/bin/jarvis-payment-whatsapp" \
  --announce --channel whatsapp --to "+34673555075"
echo
echo "Done. Each new payment summary now also goes to Noah's WhatsApp within 5 minutes."
