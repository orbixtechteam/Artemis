import type { PrismaClient } from "@prisma/client";

// From "Phase 0: the current list of recurring time sinks" (Noah's connectors, 1 Oct to 1 Nov 2026).
// Hours are the middle of each estimate range; the source says which.
const SOURCE = "Phase 0 analysis, 1 Oct to 1 Nov 2026 (estimate)";
const ROWS: [string, string, string, number, string, string, string | null][] = [
  ["Operations", "Patient order fulfilment: prescription to supplier order, med kit, shipping, refills", "Andi, Milica, Denisa, Noah", 17.5, "20 to 30 orders a month", "Peptide/hormone mix-ups, changing addresses, country rules, knowledge in one person", "fulfilment"],
  ["Patient care", "Medical coordination: bookings across time zones, relaying dose changes, keeping HQ current", "Denisa, Nebojsa, doctors", 14, "40 to 60 touches a week", "Decisions on Noah-only calls relayed by hand; summaries with clinical errors", "medical-coordinator"],
  ["Operations", "Payment links, invoices, splits, renewals and refunds", "Kim, Denisa, Nebojsa, Noah", 10, "17 approvals, 25 payment logs a month", "No single place for what a patient paid or owes; duplicate recurring charges", null],
  ["Patient care", "Coach check-ins and client follow-up admin", "James, Erle, Sofia, Derek", 10, "Weekly per active client", "Doctor topics stay with the coach; clients drift without replies", null],
  ["Company", "Internal coordination meetings and handovers", "Silvana, Noah, Nebojsa, Denisa, Andi", 9, "2 to 3 internal calls a day", "Same issues return without closure; access not revoked quickly", null],
  ["Chief of Staff", "Post-call follow-up after Noah's calls: recaps, tasks, promised links", "Noah", 8.5, "6 to 11 calls a day", "Promises with no evidence they were done; placeholders in drafts", "email-replies"],
  ["Growth", "Webinar and marketing ops", "Will, Lia, Sam, Vagif", 10, "Weekly plus launch spikes", "Noah approval is the bottleneck; date and time mismatches", null],
  ["Operations", "Procurement and pharmacy sourcing", "Andi, Silvana, Noah", 6.5, "About 15 purchases a month", "Invoices not checked against a price list; COAs missing", null],
  ["Patient care", "New-patient onboarding after payment", "Denisa, Ulvi, coaches", 6.5, "About 12 sign-ups a month", "Manual hand-offs for every new patient", null],
  ["Growth", "Pepcura B2B calls and document packs", "Noah, Rebeka, Kim, Andi", 6, "About 11 prospects a month", "Repeated reschedules; same document questions every call", null],
  ["Patient care", "Bloodwork: requisitions, chasing, routing results", "Andi, Nebojsa, Denisa, Silvana", 5, "10 results a month", "Results arrive in 3 to 4 places; missing patient details", null],
  ["Growth", "Renewals, maintenance and continuation pricing", "James, Denisa, Noah, Kim", 4, "3 renewals a week", "No written pricing rule, so every case goes to Noah", null],
  ["Company", "Fixing broken automations and tools", "Ulvi, Ibrahim", 4, "Several a month", "Breakages noticed late, by people instead of alerts", null],
  ["Company", "Scheduling, rescheduling and time-zone fixes", "Denisa, Will, Andi, Noah", 3.5, "About 10 rebookings a month", "Invites created by hand; DST errors", "pre-call-brief"],
  ["Growth", "\"What's included?\" program questions", "Noah, Silvana", 3, "Weekly", "No single program catalogue; prices differ by channel", null],
];

const LINKS: [string, string, string][] = [
  ["payment-summary", "pre-call-brief", "5-month upsell check, then a renewal call is booked"],
  ["patient-summary", "pre-call-brief", "The brief reads the patient file"],
  ["patient-summary", "payment-summary", "The payment summary reads the patient file"],
];
// The order-to-patient chain from the Phase 0 analysis: payment, onboarding, labs, prescription, order, follow-up, renewal.
const JOURNEY: [string, string, string, string | null][] = [
  ["Assessment call", "Noah, sales", "First call; the pre-call brief prepares it.", "pre-call-brief"],
  ["Payment", "Kim", "Payment posted in #sales-payment-made; call summary in the thread.", "payment-summary"],
  ["Onboarding", "Denisa, coaches", "Contract, intake form, coach match, onboarding call.", null],
  ["Bloodwork", "Andi, Nebojsa, Silvana", "Requisition, chasing, results routed to the doctor.", null],
  ["Doctor review and prescription", "Dr. Silvana, Dr. Maher", "Protocol and doses decided by a doctor.", "medical-coordinator"],
  ["Order and shipping", "Andi", "Pharmacy order, med kit, country rules, tracking, paid check.", "fulfilment"],
  ["Weekly check-ins", "Coaches", "Check-in replies within 48 hours; doctor topics flagged.", null],
  ["Follow-up and dose changes", "Doctors, Denisa", "Changes relayed to HQ, patient, stock and next order.", "medical-coordinator"],
  ["Renewal", "Noah, coach", "Month 5: coach asked first, then a renewal call.", "payment-summary"],
];

async function seedFlows(prisma: PrismaClient) {
  if (!(await prisma.playbookLink.count())) {
    for (const [a, b, label] of LINKS) {
      const [x, y] = await Promise.all([prisma.playbook.findUnique({ where: { slug: a } }), prisma.playbook.findUnique({ where: { slug: b } })]);
      if (x && y) await prisma.playbookLink.create({ data: { fromId: x.id, toId: y.id, label } });
    }
  }
  if (!(await prisma.journeyStage.count())) {
    for (const [i, [name, owner, description, slug]] of JOURNEY.entries()) {
      const p = slug ? await prisma.playbook.findUnique({ where: { slug } }) : null;
      await prisma.journeyStage.create({ data: { program: "All programs", position: i + 1, name, owner, description, playbookId: p?.id ?? null } });
    }
  }
}

export async function seedInsights(prisma: PrismaClient) {
  await seedFlows(prisma);
  // Noah's own WhatsApp number, readable by the people who already had WhatsApp access.
  if (!(await prisma.whatsappNumber.count())) {
    const allowed = (await prisma.user.findMany({ where: { whatsapp: true } })).map((u) => u.id);
    await prisma.whatsappNumber.create({ data: { phone: "+34673555075", label: "Noah", readers: JSON.stringify(allowed), senders: "[]" } });
  }
  if (await prisma.timeSink.count()) return console.log("Time sinks already exist.");
  for (const [dept, task, owner, hours, frequency, stuck, slug] of ROWS) {
    const d = await prisma.department.findFirst({ where: { name: dept } });
    const p = slug ? await prisma.playbook.findUnique({ where: { slug } }) : null;
    await prisma.timeSink.create({ data: { departmentId: d?.id ?? null, playbookId: p?.id ?? null, task, owner, hoursPerWeek: hours, frequency, stuck, source: SOURCE } });
  }
  console.log(`Added ${ROWS.length} time sinks from the Phase 0 analysis.`);
}
