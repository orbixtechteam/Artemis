import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import { PrismaClient } from "@prisma/client";
import { seedInsights } from "./seed-insights";

const prisma = new PrismaClient();

async function main() {
  const email = (process.env.NOAH_EMAIL || "noah@thelongevityclinic.net").toLowerCase();
  if (!(await prisma.user.findFirst({ where: { role: "owner" } }))) {
    const pw = process.env.NOAH_PASSWORD || crypto.randomBytes(9).toString("base64url");
    await prisma.user.create({ data: { name: process.env.NOAH_NAME || "Noah Laith", email, role: "owner", passwordHash: await bcrypt.hash(pw, 12) } });
    console.log(`Owner ${email} created${process.env.NOAH_PASSWORD ? "" : `, temporary password: ${pw}`}`);
  }
  if (await prisma.department.count()) {
    console.log("Departments already exist.");
    return seedInsights(prisma);
  }

  const D: Record<string, number> = {};
  for (const [name, owner, agent, description, position] of [
    ["Chief of Staff", "Noah", "Jarvis", "Noah's own recurring work: calls, payments, inbox, planning.", 1],
    ["Patient care", "Dr. Silvana, Dr. Maher", "", "Medical coordination, doctor support, patient success.", 2],
    ["Operations", "Andi", "", "Fulfilment, procurement, finance and team onboarding.", 3],
    ["Growth", "Will, Rebeka", "", "Sales follow-up, Pepcura B2B, marketing and community.", 4],
    ["Company", "Noah", "", "Rules, compliance, systems and the shared foundation.", 5],
  ] as const) D[name] = (await prisma.department.create({ data: { name, owner, agent, description, position } })).id;

  const pbs: [string, string, string, string, string, string, string, string][] = [
    ["Chief of Staff", "Pre-call brief", "pre-call-brief", "Noah", "live", "green", "Call booked in Noah's calendar", "Graphite Context block with who they are, last conversation, promises, open issues and bloodwork."],
    ["Chief of Staff", "Payment summary", "payment-summary", "Noah", "live", "green", "New message in #sales-payment-made", "Call summary in the payment's thread; schedules the 5-month upsell check."],
    ["Chief of Staff", "WhatsApp digest", "whatsapp-replies", "Noah", "live", "amber", "Every hour 08:00 to 22:00", "Who is waiting, promises, and wa.me reply drafts Noah sends himself."],
    ["Chief of Staff", "Email replies", "email-replies", "Noah", "live", "amber", "On request", "Reply drafts in Gmail; sent only after Noah's approval."],
    ["Chief of Staff", "Morning brief", "morning-brief", "Noah", "live", "green", "Every day 07:00", "Calendar, emails that need Noah, overdue Asana tasks."],
    ["Chief of Staff", "Week plan", "week-plan", "Noah", "live", "green", "Sunday 18:00", "Proposed plan for the coming week."],
    ["Patient care", "Patient summary file", "patient-summary", "Noah", "testing", "green", "Nightly, after calls", "One sourced summary file per patient."],
    ["Patient care", "Medical coordinator", "medical-coordinator", "Denisa", "idea", "amber", "Doctor decision or dose change", "Relays changes to HQ, patient, stock and next order."],
    ["Operations", "Fulfilment order checklist", "fulfilment", "Andi", "idea", "amber", "Signed prescription", "Order checklist with country rules, med-kit picker and paid gate."],
    ["Growth", "Non-buyer follow-up", "non-buyer", "Noah", "idea", "amber", "Assessment call with no payment after X days", "Running list and follow-up drafts."],
    ["Growth", "Skool answers", "skool-answers", "Noah", "idea", "amber", "New question in Skool", "Draft answer for Noah or Silvana."],
    ["Growth", "Clinic outreach", "clinic-outreach", "Noah", "idea", "amber", "New target clinic", "Email or contact-form draft."],
    ["Company", "Monday review", "monday-review", "Noah", "live", "green", "Monday 08:00", "Weekly runs, failures, rejected drafts and decisions."],
  ];
  for (const [d, name, slug, owner, status, autonomy, trigger, purpose] of pbs)
    await prisma.playbook.create({ data: { departmentId: D[d], name, slug, owner, status, autonomy, trigger, purpose } });

  const kbs: [string, string, string, string, string, string, boolean][] = [
    ["Company", "Playbooks – Knowledge base", "folder", "https://drive.google.com/drive/folders/1KXAwsQh-lzGz27oW9rnfFInkPWx9WkXV", "Noah", "Live SKILL.md playbooks, mirrored to the server every 15 minutes.", false],
    ["Company", "AI Agents – Organigram structure", "folder", "https://drive.google.com/drive/folders/1R_EQKWwPOWaL7Ighf99aEipW822kLYCq", "Noah", "One folder per agent and the shared foundation.", false],
    ["Patient care", "Meeting AI summary with patients", "sheet", "https://docs.google.com/spreadsheets/d/1LaSu9PAw1HMWMsT_1yfx3djNmILZ09XIlGnX2ES4J-Q", "Noah", "One row per call; summaries and to-dos per clinician.", true],
    ["Patient care", "Zoom calls", "folder", "", "Ulvi", "Every recorded call, saved hourly (Drive: Jarvis/Zoom calls).", true],
    ["Patient care", "Patient summary files", "folder", "", "Ulvi", "One sourced summary per patient (Drive: Jarvis/Patients).", true],
    ["Company", "AI Standards – Digital Brains", "doc", "https://docs.google.com/document/d/1AIOAu6IUDX3_Mww3C87lCFBbIWPayy-oFAiSpXGRaDo", "Noah", "The 10 standards and the road to autonomy.", false],
  ];
  for (const [d, name, kind, link, owner, description, patientData] of kbs)
    await prisma.knowledge.create({ data: { departmentId: D[d], name, kind, link, owner, description, patientData } });

  console.log("Seeded departments, playbooks and knowledge bases. Workflow steps come from Jarvis on the first sync.");
  await seedInsights(prisma);
}

main().finally(() => prisma.$disconnect());
