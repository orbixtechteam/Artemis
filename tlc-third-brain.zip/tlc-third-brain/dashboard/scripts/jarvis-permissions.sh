#!/bin/bash
# Run once on the server: per-person tool limits for Jarvis.
set -euo pipefail
export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH
openclaw config set tools.toolsBySender '{
  "e164:+34673555075": {},
  "channel:telegram:949832775": {},
  "channel:telegram:8619174084": { "deny": ["google__*", "periskope__*", "zoom__*", "fathom__*"] },
  "*": { "deny": ["group:plugins", "group:fs", "group:runtime", "browser"] }
}' --strict-json
openclaw config validate
echo "Noah: full. Ulvi (Telegram): no email, calendar, Drive, WhatsApp or call recordings. Anyone else: no tools."
echo "Test from Ulvi's Telegram after /new: 'Read the last 3 emails in Noah's inbox' must be refused."
