#!/bin/bash
# Run once on the server: bash /root/ai-brain-visual/scripts/jarvis-approvals.sh
# Jarvis stops sending email and Slack messages itself; it queues them in the dashboard's Approvals.
set -euo pipefail
export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH
WS=/root/.openclaw/workspace

read -r -s -p "Dashboard MCP token of the Jarvis user (starts with tb_): " TOKEN; echo
[[ "$TOKEN" == tb_* ]] || { echo "That doesn't look like a dashboard token."; exit 1; }

echo "== 1. Connect Jarvis to the dashboard (queue tools only)"
openclaw mcp set brain "{\"url\":\"http://127.0.0.1:3900/api/mcp/auth\",\"transport\":\"streamable-http\",\"headers\":{\"Authorization\":\"Bearer $TOKEN\"},\"toolFilter\":{\"include\":[\"queue_email\",\"queue_slack_message\",\"list_outbox\"]}}"
unset TOKEN

echo "== 2. Remove Gmail sending from Jarvis's Google connector"
python3 - << 'PY'
import json, subprocess
out = subprocess.run(["openclaw", "config", "get", "mcp.servers.google.args"], capture_output=True, text=True).stdout
args = json.loads(out[out.index("["): out.rindex("]") + 1])
new = [a.replace("gmail:readonly+drafts+send", "gmail:readonly+drafts").replace("+send", "") if a.startswith("gmail:") else a for a in args]
if new != args:
    subprocess.run(["openclaw", "config", "set", "mcp.servers.google.args", json.dumps(new), "--strict-json"], check=True)
print("google args:", new)
PY

echo "== 3. Remove Slack posting from Jarvis's Slack connector"
openclaw config set mcp.servers.slack.env.SLACK_MCP_ADD_MESSAGE_TOOL "false"

echo "== 4. Jarvis's rule"
if ! grep -q "## 21. Email and Slack go through Approvals" "$WS/AGENTS.md"; then
cat >> "$WS/AGENTS.md" << 'MD'

## 21. Email and Slack go through Approvals

- You never send email or post in Slack yourself. To send, call the brain tool queue_email (to, subject, body, thread_id for replies, playbook) or queue_slack_message (channel, text, thread_ts, playbook).
- Then tell Noah in one line: "Queued for approval: <who/where>, <subject>. Approve in the dashboard: https://ai-brain.thelongevityclinic.net/approvals".
- Gmail drafts are still fine when Noah asks for a draft only.
- The payment summary script posts its own thread replies; that is not you.
MD
  git -C "$WS" add AGENTS.md && git -C "$WS" commit -qm "Email and Slack through dashboard approvals" || true
fi

echo "== 5. Check"
openclaw config validate
openclaw mcp doctor brain --probe 2>&1 | grep -E "brain|warn" | head -5
openclaw mcp doctor google --probe 2>&1 | grep -E "google:" | head -2
openclaw mcp doctor slack --probe 2>&1 | grep -E "slack:" | head -2
echo "Done. Start a new Jarvis session (/new) and ask it to email you a test; it should appear in Approvals."
