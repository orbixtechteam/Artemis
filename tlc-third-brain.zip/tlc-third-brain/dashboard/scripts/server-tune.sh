#!/bin/bash
# One-time memory tuning for the Jarvis server. Safe to run again.
set -u
echo "== Before"; free -m

# 1. Swap (so the server slows down instead of freezing when memory is full)
if ! swapon --show | grep -q .; then
  fallocate -l 4G /swapfile && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile
  grep -q "^/swapfile" /etc/fstab || echo "/swapfile none swap sw 0 0" >> /etc/fstab
  echo "swap: 4 GB added"
else echo "swap: already on"; fi
sysctl -q vm.swappiness=10; grep -q "^vm.swappiness" /etc/sysctl.conf || echo "vm.swappiness=10" >> /etc/sysctl.conf

# 2. Ollama: unload the embedding model after 5 idle minutes
if systemctl list-unit-files | grep -q "^ollama.service"; then
  mkdir -p /etc/systemd/system/ollama.service.d
  printf '[Service]\nEnvironment="OLLAMA_KEEP_ALIVE=5m"\n' > /etc/systemd/system/ollama.service.d/keepalive.conf
  systemctl daemon-reload && systemctl restart ollama && echo "ollama: keep-alive 5m"
fi

# 3. SearXNG container: cap its memory
C=$(docker ps --format '{{.Names}}' 2>/dev/null | grep -i searx | head -1)
[ -n "$C" ] && docker update --memory 400m --memory-swap 800m "$C" >/dev/null && echo "searxng: capped at 400 MB ($C)"

# 4. Nightly gateway restart at 04:15 (Madrid) to free memory; the WhatsApp check alerts if it doesn't come back
cat > /usr/local/bin/jarvis-nightly-restart << 'X'
#!/bin/bash
export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH
export XDG_RUNTIME_DIR=/run/user/0
openclaw gateway restart >/dev/null 2>&1
sleep 90
openclaw channels status 2>&1 | grep -E "WhatsApp|Telegram"
X
chmod +x /usr/local/bin/jarvis-nightly-restart
( crontab -l 2>/dev/null | grep -v jarvis-nightly-restart; echo "15 3 * * * /usr/local/bin/jarvis-nightly-restart >> /var/log/jarvis-restart.log 2>&1" ) | crontab -
echo "gateway: nightly restart at 03:15 UTC"

# 5. Memory report command
cat > /usr/local/bin/jarvis-memory << 'X'
#!/bin/bash
free -m; echo
ps aux --sort=-rss | awk 'NR>1 && NR<=16 {printf "%7.0f MB  %s\n", $6/1024, substr($0, index($0,$11), 100)}'
X
chmod +x /usr/local/bin/jarvis-memory
echo; echo "== After"; free -m
