#!/bin/bash
# Run once on the server: bash /root/ai-brain-visual/scripts/automations-setup.sh
# 1) a shared key, 2) one OpenClaw job that runs all chat-made rules every 5 minutes and
#    delivers anything meant for Noah to his WhatsApp, 3) optionally lets Jarvis create rules too.
set -euo pipefail
export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH
cd /root/ai-brain-visual

if ! grep -q '^AUTOMATION_KEY=' .env; then
  echo "AUTOMATION_KEY=\"$(openssl rand -hex 24)\"" >> .env
  pm2 reload ai-brain >/dev/null && sleep 3
fi

cat > /usr/local/bin/brain-automations << 'X'
#!/bin/sh
KEY=$(grep '^AUTOMATION_KEY=' /root/ai-brain-visual/.env | cut -d'"' -f2)
OUT=$(curl -s -m 280 -X POST -H "x-brain-key: $KEY" http://127.0.0.1:3900/api/automations/run)
[ -n "$OUT" ] && echo "$OUT" || echo NO_REPLY
X
chmod +x /usr/local/bin/brain-automations
echo "Test run: $(/usr/local/bin/brain-automations | head -c 200)"

if openclaw cron list --json 2>/dev/null | grep -q '"Brain automations"'; then
  echo "Job already exists."
else
  openclaw cron create "*/5 * * * *" --name "Brain automations" --command "/usr/local/bin/brain-automations" \
    --announce --channel whatsapp --to "+34673555075"
fi

# Remove the one-off payment job if it was installed: the chat rule replaces it.
ID=$(openclaw cron list --json 2>/dev/null | python3 -c "import json,sys;print(next((j['id'] for j in json.load(sys.stdin).get('jobs',[]) if j.get('name')=='Payment summary to WhatsApp'),''))" || true)
[ -n "$ID" ] && openclaw cron remove "$ID" && echo "Removed the old 'Payment summary to WhatsApp' job."

echo
read -r -p "Let Jarvis create rules too? Paste Noah's dashboard MCP token (tb_...), or press Enter to skip: " TOKEN
if [[ "$TOKEN" == tb_* ]]; then
  openclaw mcp set brain "{\"url\":\"http://127.0.0.1:3900/api/mcp\",\"transport\":\"streamable-http\",\"headers\":{\"Authorization\":\"Bearer $TOKEN\"},\"toolFilter\":{\"include\":[\"create_automation\",\"list_brain_automations\",\"update_brain_automation\",\"get_overview\",\"list_playbooks\",\"get_playbook\",\"create_rule\",\"create_lesson\",\"add_step\"]}}"
  unset TOKEN
  openclaw mcp doctor brain --probe 2>&1 | grep -E "brain" | head -2
  echo "Jarvis can now create rules: tell it on WhatsApp, e.g. 'Whenever a payment summary is posted, send it to me here.'"
fi
echo "Done."
