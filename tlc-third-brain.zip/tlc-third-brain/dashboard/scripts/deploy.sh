#!/bin/bash
# Run on the Mac from the project folder: bash scripts/deploy.sh
set -euo pipefail
SERVER="${SERVER:-root@187.126.15.145}"
cd "$(dirname "$0")/.."
echo "== Sending code to $SERVER"
rsync -az --delete --exclude node_modules --exclude .next --exclude .env --exclude 'prisma/*.db' --exclude data ./ "$SERVER:/root/ai-brain-visual/"
echo "== Building on the server"
ssh "$SERVER" 'set -e
export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH
cd /root/ai-brain-visual
corepack enable >/dev/null 2>&1 || true
grep -q '^APP_URL=' .env || echo 'APP_URL="https://ai-brain.thelongevityclinic.net"' >> .env
pnpm install --frozen-lockfile=false
if [ -f prisma/brain.db ]; then cp prisma/brain.db "prisma/brain.db.bak-$(date +%Y%m%d-%H%M)"; ls -1t prisma/brain.db.bak-* | tail -n +6 | xargs -r rm -f; fi
pnpm prisma db push --accept-data-loss
pnpm db:seed
pnpm build
if pm2 describe ai-brain >/dev/null 2>&1; then pm2 reload ai-brain; else pm2 start ecosystem.config.cjs && pm2 save; fi
sleep 3
curl -s -o /dev/null -w "local check: %{http_code}\n" http://127.0.0.1:3900/login'
echo "== Done: https://ai-brain.thelongevityclinic.net"
