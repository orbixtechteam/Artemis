#!/bin/bash
# Run on the server once: bash /root/ai-brain-visual/scripts/whop-setup.sh
# Stores the Whop keys in .env without showing them, checks the key works, and prints the webhook address.
set -euo pipefail
cd /root/ai-brain-visual
export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH
read -r -s -p "Whop API key (Account API key): " KEY; echo
read -r -p "Whop company id (starts with biz_): " BIZ
read -r -s -p "Whop webhook secret (starts with ws_, press Enter to add it later): " WS; echo
sed -i '/^WHOP_API_KEY=/d;/^WHOP_COMPANY_ID=/d' .env
printf 'WHOP_API_KEY="%s"\nWHOP_COMPANY_ID="%s"\n' "$KEY" "$BIZ" >> .env
if [ -n "$WS" ]; then sed -i '/^WHOP_WEBHOOK_SECRET=/d' .env; printf 'WHOP_WEBHOOK_SECRET="%s"\n' "$WS" >> .env; fi
CODE=$(curl -s -o /dev/null -w "%{http_code}" -H "Authorization: Bearer $KEY" "https://api.whop.com/api/v1/payments?company_id=$BIZ&first=1")
unset KEY WS
echo "Whop API check: HTTP $CODE (200 = the key works)"
pm2 reload ai-brain >/dev/null && echo "Dashboard reloaded."
echo "Webhook URL for Whop: $(grep '^APP_URL=' .env | cut -d'"' -f2)/api/webhooks/whop"
