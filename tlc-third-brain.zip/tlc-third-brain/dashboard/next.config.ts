import type { NextConfig } from "next";

const appHost = process.env.APP_URL ? new URL(process.env.APP_URL).host : undefined;

const nextConfig: NextConfig = {
  poweredByHeader: false,
  serverExternalPackages: ["@prisma/client"],
  experimental: {
    // Behind a Cloudflare Tunnel the browser's origin differs from the local host; allow it for server actions.
    serverActions: { allowedOrigins: appHost ? [appHost] : [] },
  },
  async headers() {
    return [{ source: "/(.*)", headers: [
      { key: "X-Frame-Options", value: "DENY" },
      { key: "X-Content-Type-Options", value: "nosniff" },
      { key: "Referrer-Policy", value: "same-origin" },
    ] }];
  },
};
export default nextConfig;
