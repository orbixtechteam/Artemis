"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { removeDepartment, saveDepartment } from "@/lib/actions";

export type AdminDept = { id: number; name: string; parentId?: number | null; owner: string; agent: string; description: string; playbooks: number; members: number[] };
export type AdminPerson = { id: number; name: string; email: string; role: string };

export function DepartmentsAdmin({ departments, people }: { departments: AdminDept[]; people: AdminPerson[] }) {
  const [editing, setEditing] = useState<AdminDept | "new" | null>(null);
  const scoped = people.filter((p) => p.role === "editor" || p.role === "viewer");
  return (
    <section className="mt-8 grid gap-3">
      <div className="flex items-end justify-between gap-3">
        <div><h2 className="text-lg font-bold">Departments</h2><p className="text-sm text-muted-foreground">Add departments and choose who sees each one. Admins and the owner see all of them.</p></div>
        <Button onClick={() => setEditing("new")}>Add department</Button>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Department</TableHead><TableHead>Owner</TableHead><TableHead>Agent</TableHead><TableHead>Playbooks</TableHead><TableHead>People</TableHead></TableRow></TableHeader>
        <TableBody>
          {departments.map((d) => (
            <TableRow key={d.id} data-clickable onClick={() => setEditing(d)}>
              <TableCell className="font-semibold">{d.parentId ? <span className="text-muted-foreground">{departments.find((x) => x.id === d.parentId)?.name} › </span> : null}{d.name}</TableCell>
              <TableCell>{d.owner}</TableCell>
              <TableCell>{d.agent}</TableCell>
              <TableCell className="num">{d.playbooks}</TableCell>
              <TableCell className="max-w-[40ch]">{d.members.map((id) => scoped.find((p) => p.id === id)?.name).filter(Boolean).join(", ") || <span className="text-muted-foreground">Admins only</span>}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {editing && <DeptDialog dept={editing === "new" ? null : editing} people={scoped} all={departments} onClose={() => setEditing(null)} />}
    </section>
  );
}

function DeptDialog({ dept, people, all, onClose }: { dept: AdminDept | null; people: AdminPerson[]; all: AdminDept[]; onClose: () => void }) {
  const [parentId, setParentId] = useState<string>(dept?.parentId ? String(dept.parentId) : "none");
  const router = useRouter();
  const [v, setV] = useState({ name: dept?.name ?? "", owner: dept?.owner ?? "", agent: dept?.agent ?? "", description: dept?.description ?? "" });
  const [members, setMembers] = useState<number[]>(dept?.members ?? []);
  const [error, setError] = useState("");
  const [pending, start] = useTransition();
  const save = (e: React.FormEvent) => {
    e.preventDefault();
    start(async () => {
      const r = await saveDepartment({ id: dept?.id, ...v, members, parentId: parentId === "none" ? null : Number(parentId) });
      if (!r.ok) return setError(r.error ?? "Couldn't save.");
      toast.success(dept ? "Saved changes" : "Added department");
      onClose(); router.refresh();
    });
  };
  const remove = () => {
    if (!dept || !confirm(`Delete ${dept.name}? Its playbooks stay, without a department.`)) return;
    start(async () => {
      const r = await removeDepartment(dept.id);
      if (!r.ok) return setError(r.error ?? "Couldn't delete.");
      toast.success("Deleted department"); onClose(); router.refresh();
    });
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <form onSubmit={save} className="grid gap-4">
          <DialogHeader><DialogTitle>{dept ? dept.name : "Add department"}</DialogTitle><DialogDescription>Name, owner and the people who can see it.</DialogDescription></DialogHeader>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2"><Label htmlFor="d-name">Name</Label><Input id="d-name" required value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} /></div>
            <div className="grid gap-2"><Label htmlFor="d-owner">Owner</Label><Input id="d-owner" value={v.owner} onChange={(e) => setV({ ...v, owner: e.target.value })} /></div>
            <div className="grid gap-2 sm:col-span-2">
              <Label htmlFor="d-parent">Part of (for a sub-department)</Label>
              <select id="d-parent" value={parentId} onChange={(e) => setParentId(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm">
                <option value="none">None (top-level department)</option>
                {all.filter((x) => x.id !== dept?.id).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
              </select>
            </div>
            <div className="grid gap-2 sm:col-span-2"><Label htmlFor="d-agent">Agent</Label><Input id="d-agent" value={v.agent} onChange={(e) => setV({ ...v, agent: e.target.value })} /></div>
          </div>
          <div className="grid gap-2"><Label htmlFor="d-desc">What this department does</Label><Textarea id="d-desc" value={v.description} onChange={(e) => setV({ ...v, description: e.target.value })} /></div>
          <fieldset className="grid gap-2">
            <legend className="mb-2 text-sm font-semibold">People who can see it (editors and viewers)</legend>
            {people.length ? (
              <div className="flex flex-wrap gap-x-5 gap-y-2">
                {people.map((p) => (
                  <Label key={p.id} className="font-medium">
                    <Checkbox checked={members.includes(p.id)} onCheckedChange={(c) => setMembers((s) => (c ? [...s, p.id] : s.filter((x) => x !== p.id)))} />
                    {p.name} <span className="text-xs text-muted-foreground">{p.role}</span>
                  </Label>
                ))}
              </div>
            ) : <p className="text-sm text-muted-foreground">No editors or viewers yet. Add people below.</p>}
          </fieldset>
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          <DialogFooter className="sm:justify-between">
            {dept ? <Button type="button" variant="ghost" className="text-destructive" onClick={remove} disabled={pending}>Delete</Button> : <span />}
            <div className="flex gap-2"><Button type="button" variant="outline" onClick={onClose}>Cancel</Button><Button type="submit" disabled={pending}>{dept ? "Save changes" : "Add department"}</Button></div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
