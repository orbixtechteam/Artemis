import Link from "next/link";
import { StatusBadge } from "@/components/status";
import { AUTONOMY } from "@/lib/constants";
import { ago, cn, isOk } from "@/lib/utils";

export type MapPlaybook = {
  id: number; name: string; status: string; autonomy: string; trigger: string; departmentId: number | null;
  testsPassed: number; testsTotal: number; lastRunAt: Date | null; lastRunStatus: string | null;
};

export function PlaybookRow({ p }: { p: MapPlaybook }) {
  const faded = p.status === "idea" || p.status === "draft";
  const meta = [p.testsTotal ? `${p.testsPassed}/${p.testsTotal} tests` : "", p.lastRunAt ? `ran ${ago(p.lastRunAt)}` : "", !isOk(p.lastRunStatus) ? "last run failed" : ""].filter(Boolean);
  const strip = p.autonomy === "green" ? "bg-signal-green" : p.autonomy === "red" ? "bg-signal-red" : "bg-signal-amber";
  return (
    <Link href={`/playbooks/${p.id}`} title={AUTONOMY[p.autonomy as keyof typeof AUTONOMY]}
      className="grid grid-cols-[4px_1fr_auto] items-center gap-x-3 gap-y-1 rounded-md py-2 pr-2 hover:bg-muted">
      <span className={cn("row-span-2 self-stretch rounded-full", strip)} />
      <span className={cn("leading-tight font-semibold", faded && "font-medium text-muted-foreground")}>{p.name}</span>
      <StatusBadge status={p.status} />
      <span className="col-span-2 flex flex-wrap gap-x-3 text-xs text-muted-foreground">
        <span>{p.trigger}</span>
        {meta.length > 0 && <span className={cn("num", !isOk(p.lastRunStatus) && "text-signal-red")}>{meta.join(" · ")}</span>}
      </span>
    </Link>
  );
}

export function BrainMap({ departments, playbooks }: {
  departments: { id: number; name: string; owner: string; agent: string }[]; playbooks: MapPlaybook[];
}) {
  return (
    <>
      <div className="grid auto-cols-[minmax(230px,1fr)] grid-flow-col overflow-x-auto rounded-xl border bg-card">
        {departments.map((d) => {
          const pbs = playbooks.filter((p) => p.departmentId === d.id);
          return (
            <section key={d.id} className="flex min-w-0 flex-col border-r last:border-r-0">
              <div className="border-b px-4 pt-4 pb-3">
                <h2 className="font-bold"><Link href={`/departments/${d.id}`} className="hover:underline">{d.name}</Link></h2>
                <p className="text-sm text-muted-foreground">{d.owner || "Owner to confirm"}{d.agent ? `, agent ${d.agent}` : ""}</p>
              </div>
              <div className="grid content-start gap-0.5 p-2">
                {pbs.length ? pbs.map((p) => <PlaybookRow key={p.id} p={p} />) : <p className="p-2 text-sm text-muted-foreground">No playbooks yet.</p>}
              </div>
            </section>
          );
        })}
      </div>
      <div className="mt-2.5 flex flex-wrap gap-5 text-xs text-muted-foreground">
        {Object.entries(AUTONOMY).map(([k, v]) => (
          <span key={k} className="inline-flex items-center gap-1.5">
            <span className={cn("size-2 rounded-full", k === "green" ? "bg-signal-green" : k === "red" ? "bg-signal-red" : "bg-signal-amber")} />{v}
          </span>
        ))}
        <span>Faded names are ideas or drafts</span>
      </div>
    </>
  );
}
