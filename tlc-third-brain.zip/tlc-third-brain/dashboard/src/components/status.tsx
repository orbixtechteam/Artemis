import { Badge } from "@/components/ui/badge";
import { AUTONOMY } from "@/lib/constants";
import { cn, isOk } from "@/lib/utils";

const STATUS_TONE: Record<string, "green" | "amber" | "red" | "neutral"> = {
  live: "green", testing: "amber", paused: "red", idea: "neutral", draft: "neutral",
  active: "green", candidate: "amber", rejected: "red", superseded: "neutral",
};

export function StatusBadge({ status }: { status: string }) {
  return <Badge tone={STATUS_TONE[status] ?? "neutral"}>{status}</Badge>;
}

export function AutonomyDot({ level, className }: { level: string; className?: string }) {
  const color = level === "green" ? "bg-signal-green" : level === "red" ? "bg-signal-red" : "bg-signal-amber";
  return <span aria-hidden className={cn("inline-block size-2 shrink-0 rounded-full", color, className)} />;
}

export function AutonomyLabel({ level }: { level: string }) {
  return (
    <span className="inline-flex items-center gap-2">
      <AutonomyDot level={level} />
      {AUTONOMY[level as keyof typeof AUTONOMY] ?? level}
    </span>
  );
}

export function RunBadge({ status }: { status?: string | null }) {
  if (!status) return <Badge>not run</Badge>;
  return <Badge tone={isOk(status) ? "green" : "red"}>{status}</Badge>;
}
