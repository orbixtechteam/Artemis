"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { deleteEntity, saveEntity } from "@/lib/actions";
import { ENTITY_FORMS, type EntityKey, type Option } from "@/lib/fields";

export type Ref = { id: number; name: string };
type Row = Record<string, unknown> & { id?: number };

const NONE = "__none__";
const DEFAULTS: Partial<Record<EntityKey, Row>> = {
  playbooks: { status: "draft", autonomy: "amber", testsPassed: 0, testsTotal: 0 },
  rules: { status: "active", kind: "policy" },
  knowledge: { kind: "folder", patientData: false },
  automations: { kind: "schedule", enabled: true },
  departments: { position: 0 },
};

export function EntityDialog({
  entity, row, open, onOpenChange, departments, playbooks, canDelete,
}: {
  entity: EntityKey; row?: Row | null; open: boolean; onOpenChange: (o: boolean) => void;
  departments: Ref[]; playbooks: Ref[]; canDelete?: boolean;
}) {
  const cfg = ENTITY_FORMS[entity];
  const isNew = !row?.id;
  const [values, setValues] = useState<Row>({});
  const [error, setError] = useState("");
  const [pending, start] = useTransition();
  const router = useRouter();

  const init = () => { setValues({ ...(DEFAULTS[entity] ?? {}), ...(row ?? {}) }); setError(""); };
  const set = (k: string, v: unknown) => setValues((s) => ({ ...s, [k]: v }));
  const optionsFor = (o: "departments" | "playbooks" | Option[]): Option[] =>
    o === "departments" ? departments.map((d) => ({ value: String(d.id), label: d.name }))
      : o === "playbooks" ? playbooks.map((p) => ({ value: String(p.id), label: p.name })) : o;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    start(async () => {
      const body: Record<string, unknown> = {};
      for (const f of cfg.fields) body[f.key] = values[f.key] ?? (f.type === "checkbox" ? false : "");
      const res = await saveEntity(entity, row?.id ?? null, body);
      if (!res.ok) return setError(res.error ?? "Couldn't save.");
      toast.success(isNew ? `Added ${cfg.title}` : "Saved changes");
      onOpenChange(false);
      router.refresh();
    });
  };
  const remove = () => {
    if (!row?.id || !confirm(`Delete this ${cfg.title}? This can't be undone.`)) return;
    start(async () => {
      const res = await deleteEntity(entity, row.id!);
      if (!res.ok) return setError(res.error ?? "Couldn't delete.");
      toast.success(`Deleted ${cfg.title}`);
      onOpenChange(false);
      router.refresh();
    });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (o) init(); onOpenChange(o); }}>
      <DialogContent onOpenAutoFocus={() => init()}>
        <form onSubmit={submit} className="grid gap-4">
          <DialogHeader>
            <DialogTitle>{isNew ? "Add" : "Edit"} {cfg.title}</DialogTitle>
            <DialogDescription className="sr-only">Fill in the fields and save.</DialogDescription>
          </DialogHeader>
          {cfg.fields.map((f) => {
            const id = `f-${f.key}`;
            const v = values[f.key];
            if (f.type === "checkbox")
              return (
                <Label key={f.key} htmlFor={id} className="font-medium">
                  <Checkbox id={id} checked={!!v} onCheckedChange={(c) => set(f.key, c === true)} /> {f.label}
                </Label>
              );
            return (
              <div key={f.key} className="grid gap-2">
                <Label htmlFor={id}>{f.label}</Label>
                {f.type === "textarea" ? (
                  <Textarea id={id} required={f.required} value={String(v ?? "")} onChange={(e) => set(f.key, e.target.value)} />
                ) : f.type === "select" && f.options ? (
                  <Select value={v == null || v === "" ? NONE : String(v)} onValueChange={(x) => set(f.key, x === NONE ? null : f.key.endsWith("Id") ? Number(x) : x)}>
                    <SelectTrigger id={id}><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {(f.options === "departments" || f.options === "playbooks") && <SelectItem value={NONE}>None</SelectItem>}
                      {optionsFor(f.options).map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input id={id} type={f.type ?? "text"} required={f.required} value={String(v ?? "")}
                    onChange={(e) => set(f.key, f.type === "number" ? Number(e.target.value) : e.target.value)} />
                )}
              </div>
            );
          })}
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          <DialogFooter className="sm:justify-between">
            {!isNew && canDelete ? <Button type="button" variant="ghost" className="text-destructive" onClick={remove} disabled={pending}>Delete</Button> : <span />}
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" disabled={pending}>{isNew ? "Add" : "Save changes"}</Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function AddButton({ entity, label, departments, playbooks, preset }: {
  entity: EntityKey; label: string; departments: Ref[]; playbooks: Ref[]; preset?: Row;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setOpen(true)}>{label}</Button>
      <EntityDialog entity={entity} row={preset ?? null} open={open} onOpenChange={setOpen} departments={departments} playbooks={playbooks} />
    </>
  );
}

export function EditButton({ entity, label, row, departments, playbooks, canDelete }: {
  entity: EntityKey; label: string; row: Row; departments: Ref[]; playbooks: Ref[]; canDelete?: boolean;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)}>{label}</Button>
      <EntityDialog entity={entity} row={row} open={open} onOpenChange={setOpen} departments={departments} playbooks={playbooks} canDelete={canDelete} />
    </>
  );
}
