"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowUp, AudioLines, Check, ChevronDown, FileText, ImageIcon, Loader2, Mic, Paperclip, Sparkles, Square, TriangleAlert, VolumeX, X } from "lucide-react";
import { useVoice } from "@/components/chat/voice";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Markdown } from "@/components/chat/markdown";
import { InlineApproval } from "@/components/chat/inline-approval";
import { cn } from "@/lib/utils";

export type ToolEvent = { tool: string; ok: boolean; write: boolean; summary: string; outboxId?: number };
export type FileRef = { id: number; name: string; mime: string; size: number };
export type ChatMsg = { id?: number; role: "user" | "assistant"; content: string; events?: ToolEvent[]; files?: FileRef[] };

const SUGGESTIONS: Record<string, string[]> = {
  general: [
    "What changed in the brain this week?",
    "Which playbooks are still ideas, and which job takes the most time without one?",
    "How is the system? Anything down?",
    "Add a department called Finance, owner Kim",
  ],
  department: [
    "Summarise this department: playbooks, rules and open lessons",
    "Write a skill for the most time-consuming job here",
    "Add a rule from this screenshot",
    "Who can see this department? Add Andi as an editor",
  ],
};

export function ChatView({ conversationId, departmentId, departments, initialMessages, userName, canChooseDept }: {
  conversationId: number | null; departmentId: number | null; departments: { id: number; name: string }[];
  initialMessages: ChatMsg[]; userName: string; canChooseDept: boolean;
}) {
  const router = useRouter();
  const [messages, setMessages] = useState<ChatMsg[]>(initialMessages);
  const [live, setLive] = useState<ToolEvent[] | null>(null);
  const [text, setText] = useState("");
  const [files, setFiles] = useState<FileRef[]>([]);
  const [uploading, setUploading] = useState(0);
  const [dept, setDept] = useState<string>(departmentId ? String(departmentId) : "none");
  const [dragging, setDragging] = useState(false);
  const convo = useRef<number | null>(conversationId);
  const end = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const picker = useRef<HTMLInputElement>(null);
  const busy = live !== null;
  const [voiceMode, setVoiceMode] = useState(false);
  const voiceModeRef = useRef(false); voiceModeRef.current = voiceMode;
  const sendRef = useRef<(t: string) => void>(() => {});
  const voice = useVoice(
    (spoken) => { if (voiceModeRef.current) sendRef.current(spoken); else setText((t) => (t ? `${t} ${spoken}` : spoken)); },
    (msg) => setMessages((m) => [...m, { role: "assistant", content: msg }]),
  );
  const onReply = useRef<(t: string) => void>(() => {});
  onReply.current = (reply: string) => { if (voiceModeRef.current) voice.speak(reply, () => { if (voiceModeRef.current) voice.start(true); }); };
  const toggleVoiceMode = () => {
    if (voiceMode) { setVoiceMode(false); voice.stop(); voice.quiet(); }
    else { setVoiceMode(true); voice.start(true); }
  };
  const deptName = departments.find((d) => String(d.id) === dept)?.name;

  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [messages, live]);
  useEffect(() => { input.current?.focus(); }, []);
  useEffect(() => {
    const el = input.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 240)}px`;
  }, [text]);

  const upload = async (list: FileList | File[]) => {
    const arr = Array.from(list);
    if (!arr.length) return;
    setUploading((n) => n + arr.length);
    const fd = new FormData();
    arr.forEach((f, i) => fd.append("files", f, f.name || `pasted-${Date.now()}-${i}.png`));
    try {
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setFiles((f) => [...f, ...data.files]);
    } catch (e) {
      setMessages((m) => [...m, { role: "assistant", content: `Couldn't attach the file: ${(e as Error).message}` }]);
    } finally { setUploading((n) => n - arr.length); }
  };

  const send = async (content: string) => {
    const t = content.trim();
    if ((!t && !files.length) || busy || uploading) return;
    const sent = files;
    setMessages((m) => [...m, { role: "user", content: t, files: sent }]);
    setText(""); setFiles([]); setLive([]);
    let isNew = convo.current === null, wrote = false;
    try {
      const res = await fetch("/api/chat", {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ conversationId: convo.current, departmentId: dept === "none" ? null : Number(dept), message: t, attachments: sent }),
      });
      if (!res.ok || !res.body) throw new Error((await res.json().catch(() => ({}))).error ?? `Request failed (${res.status})`);
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "", steps: ToolEvent[] = [];
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let nl;
        while ((nl = buf.indexOf("\n")) >= 0) {
          const line = buf.slice(0, nl).trim();
          buf = buf.slice(nl + 1);
          if (!line) continue;
          const ev = JSON.parse(line);
          if (ev.type === "conversation" && convo.current === null) {
            convo.current = ev.id;
            window.history.replaceState(null, "", `/chat/${ev.id}`);
          } else if (ev.type === "tool") {
            steps = [...steps, { tool: ev.tool, ok: ev.ok, write: ev.write, summary: ev.summary, outboxId: ev.outboxId }];
            setLive(steps);
          } else if (ev.type === "reply") {
            wrote = ev.wrote;
            setMessages((m) => [...m, { role: "assistant", content: ev.text, events: steps }]);
            onReply.current(ev.text);
          }
        }
      }
    } catch (e) {
      setMessages((m) => [...m, { role: "assistant", content: `I couldn't finish that: ${(e as Error).message}` }]);
      isNew = false;
    } finally {
      setLive(null);
      if (isNew || wrote) router.refresh();
    }
  };

  sendRef.current = (t: string) => { void send(t); };
  const empty = messages.length === 0;
  const greeting = (() => { const h = new Date().getHours(); return h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening"; })();

  return (
    <div className={cn("flex h-full min-h-0 flex-col", dragging && "ring-2 ring-inset ring-primary")}
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }} onDragLeave={(e) => { if (e.currentTarget === e.target) setDragging(false); }}
      onDrop={(e) => { e.preventDefault(); setDragging(false); upload(e.dataTransfer.files); }}>

      <div className="min-h-0 flex-1 overflow-y-auto">
        {empty ? (
          <div className="mx-auto flex h-full max-w-3xl flex-col justify-center px-5 py-10">
            <span className="mb-4 grid size-11 place-items-center rounded-2xl bg-primary/10 text-primary"><Sparkles className="size-5" /></span>
            <h1 className="text-3xl font-extrabold tracking-tight">{greeting}, {userName.split(" ")[0]}</h1>
            <p className="mt-2 text-muted-foreground">
              {deptName ? `This chat is about ${deptName}. ` : ""}Ask anything about the brain, or tell me what to change: departments, people, playbooks, rules, memory, files and workflows. Rules and lessons also go to Jarvis.
            </p>
            <div className="mt-8 grid gap-2 sm:grid-cols-2">
              {SUGGESTIONS[deptName ? "department" : "general"].map((s) => (
                <button key={s} type="button" onClick={() => send(s)} className="rounded-xl border bg-card px-4 py-3 text-left text-sm hover:border-foreground/30">{s}</button>
              ))}
            </div>
          </div>
        ) : (
          <div className="mx-auto grid max-w-3xl gap-6 px-5 pt-8 pb-6">
            {messages.map((m, i) => <Message key={m.id ?? `m${i}`} m={m} />)}
            {live && <LiveSteps steps={live} />}
            <div ref={end} />
          </div>
        )}
      </div>

      <div className="mx-auto w-full max-w-3xl px-4 pb-4">
        {voiceMode && (
          <div className="mb-2 flex items-center gap-3 rounded-2xl border bg-card px-4 py-2.5 text-sm" role="status" aria-live="polite">
            <span className="flex h-6 items-end gap-0.5" aria-hidden>
              {[0.6, 1, 0.75, 0.9, 0.5].map((k, i) => (
                <span key={i} className={cn("w-1 rounded-full", voice.recording ? "bg-primary" : "bg-muted-foreground/40")}
                  style={{ height: `${Math.max(15, (voice.recording ? voice.level : voice.speaking ? 0.5 : 0.1) * k * 100)}%` }} />
              ))}
            </span>
            <span className="flex-1">
              {voice.recording ? "Listening… stop talking to send" : voice.transcribing ? "Writing down what you said…" : busy ? "Thinking…" : voice.speaking ? "Speaking…" : "Voice mode is on"}
            </span>
            {voice.speaking && <Button type="button" variant="ghost" size="sm" onClick={() => { voice.quiet(); voice.start(true); }}><VolumeX /> Skip</Button>}
            {!voice.recording && !voice.transcribing && !busy && !voice.speaking && <Button type="button" variant="ghost" size="sm" onClick={() => voice.start(true)}><Mic /> Talk</Button>}
            {voice.recording && <Button type="button" variant="ghost" size="sm" onClick={voice.stop}><Square /> Send</Button>}
            <Button type="button" variant="ghost" size="icon" className="size-7" onClick={toggleVoiceMode} aria-label="Turn voice mode off"><X /></Button>
          </div>
        )}
        <form className="rounded-2xl border bg-card shadow-sm focus-within:border-ring" onSubmit={(e) => { e.preventDefault(); send(text); }}>
          {(files.length > 0 || uploading > 0) && (
            <div className="flex flex-wrap items-center gap-1.5 px-3 pt-3">
              <FileChips files={files} onRemove={(id) => setFiles((f) => f.filter((x) => x.id !== id))} />
              {uploading > 0 && <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground"><Loader2 className="size-3.5 animate-spin" /> Attaching</span>}
            </div>
          )}
          <textarea ref={input} rows={1} value={text} onChange={(e) => setText(e.target.value)} placeholder={deptName ? `Ask about ${deptName}…` : "Ask the brain…"}
            className="block max-h-60 w-full resize-none bg-transparent px-4 pt-3.5 pb-2 text-[15px] outline-none placeholder:text-muted-foreground"
            onPaste={(e) => { if (e.clipboardData.files.length) { e.preventDefault(); upload(e.clipboardData.files); } }}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(text); } }} aria-label="Message" />
          <div className="flex items-center gap-1.5 px-2 pb-2">
            <input ref={picker} type="file" multiple hidden onChange={(e) => { if (e.target.files) upload(e.target.files); e.target.value = ""; }} />
            <Button type="button" variant="ghost" size="icon" className="size-8" onClick={() => picker.current?.click()} aria-label="Attach files"><Paperclip /></Button>
            <Button type="button" variant={voice.recording && !voiceMode ? "destructive" : "ghost"} size="icon" className="size-8"
              disabled={voice.transcribing || voiceMode} onClick={() => (voice.recording ? voice.stop() : voice.start(false))}
              aria-label={voice.recording ? "Stop recording" : "Dictate"} title={voice.recording ? "Stop and transcribe" : "Dictate (speech to text)"}>
              {voice.transcribing && !voiceMode ? <Loader2 className="animate-spin" /> : voice.recording && !voiceMode ? <Square /> : <Mic />}
            </Button>
            <Button type="button" variant={voiceMode ? "default" : "ghost"} size="sm" className="h-8 gap-1.5 rounded-full px-3" onClick={toggleVoiceMode}
              aria-pressed={voiceMode} title="Voice mode: talk, hear the answer, keep talking">
              <AudioLines /> {voiceMode ? "Voice on" : "Voice"}
            </Button>
            {canChooseDept ? (
              <Select value={dept} onValueChange={setDept}>
                <SelectTrigger className="h-8 w-auto gap-1.5 rounded-full border-dashed px-3 text-xs" aria-label="Department for this chat"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">General</SelectItem>
                  {departments.map((d) => <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>)}
                </SelectContent>
              </Select>
            ) : deptName && <span className="rounded-full border px-3 py-1 text-xs text-muted-foreground">{deptName}</span>}
            <Button type="submit" size="icon" className="ml-auto size-8 rounded-full" disabled={busy || uploading > 0 || (!text.trim() && !files.length)} aria-label="Send">
              {busy ? <Loader2 className="animate-spin" /> : <ArrowUp />}
            </Button>
          </div>
        </form>
        <p className="mt-2 text-center text-[11px] text-muted-foreground">Works with your permissions; deleting always asks first. Paste or drop files, or use the mic to talk.</p>
      </div>
    </div>
  );
}

function Message({ m }: { m: ChatMsg }) {
  if (m.role === "user") {
    return (
      <div className="grid justify-items-end gap-2">
        {m.files && m.files.length > 0 && <FileChips files={m.files} />}
        {m.content && <div className="max-w-[85%] rounded-2xl bg-muted px-4 py-2.5 text-[15px] leading-relaxed whitespace-pre-wrap">{m.content}</div>}
      </div>
    );
  }
  return (
    <div className="flex gap-3">
      <span className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-full bg-primary/10 text-primary"><Sparkles className="size-3.5" /></span>
      <div className="min-w-0 flex-1 grid gap-2">
        {m.events && m.events.length > 0 && <Steps steps={m.events} />}
        <Markdown text={m.content} />
        {m.events?.filter((e) => e.outboxId).map((e) => <InlineApproval key={e.outboxId} id={e.outboxId!} />)}
      </div>
    </div>
  );
}

function Steps({ steps }: { steps: ToolEvent[] }) {
  const [open, setOpen] = useState(false);
  const changes = steps.filter((s) => s.ok && s.write).length;
  const failed = steps.filter((s) => !s.ok).length;
  return (
    <div className="text-sm">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} className="inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground">
        <ChevronDown className={cn("size-3.5 transition-transform", !open && "-rotate-90")} />
        {steps.length} step{steps.length === 1 ? "" : "s"}{changes ? `, ${changes} change${changes === 1 ? "" : "s"}` : ""}{failed ? `, ${failed} failed` : ""}
      </button>
      {open && <StepList steps={steps} />}
    </div>
  );
}

function LiveSteps({ steps }: { steps: ToolEvent[] }) {
  return (
    <div className="flex gap-3">
      <span className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-full bg-primary/10 text-primary"><Loader2 className="size-3.5 animate-spin" /></span>
      <div className="grid gap-1 text-sm">
        <span className="text-muted-foreground">{steps.length ? "Working on it" : "Thinking"}</span>
        {steps.length > 0 && <StepList steps={steps} />}
      </div>
    </div>
  );
}

function StepList({ steps }: { steps: ToolEvent[] }) {
  return (
    <ul className="mt-1.5 grid gap-1 border-l pl-3">
      {steps.map((s, i) => (
        <li key={i} className={cn("flex items-start gap-1.5 text-xs", s.ok ? "text-muted-foreground" : "text-destructive")}>
          {s.ok ? <Check className={cn("mt-0.5 size-3.5 shrink-0", s.write && "text-signal-green")} /> : <TriangleAlert className="mt-0.5 size-3.5 shrink-0" />}
          <span className={cn(s.ok && s.write && "font-semibold text-foreground")}>{s.summary}</span>
        </li>
      ))}
    </ul>
  );
}

function FileChips({ files, onRemove }: { files: FileRef[]; onRemove?: (id: number) => void }) {
  return (
    <div className="flex flex-wrap justify-end gap-1.5">
      {files.map((f) => (
        <span key={f.id} className="inline-flex max-w-[240px] items-center gap-1.5 rounded-lg border bg-background px-2 py-1 text-xs">
          {f.mime.startsWith("image/") ? <ImageIcon className="size-3.5 shrink-0 text-muted-foreground" /> : <FileText className="size-3.5 shrink-0 text-muted-foreground" />}
          <span className="truncate">{f.name}</span>
          {onRemove && <button type="button" onClick={() => onRemove(f.id)} aria-label={`Remove ${f.name}`} className="text-muted-foreground hover:text-foreground"><X className="size-3" /></button>}
        </span>
      ))}
    </div>
  );
}
