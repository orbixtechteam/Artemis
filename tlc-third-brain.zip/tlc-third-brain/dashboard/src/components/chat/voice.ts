"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Microphone recording with optional automatic stop on silence, server transcription, and spoken replies.
 * Transcription runs on our server (local Whisper); speech uses the browser's built-in voices.
 */
export function useVoice(onText: (text: string) => void, onError: (msg: string) => void) {
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [level, setLevel] = useState(0);
  const rec = useRef<MediaRecorder | null>(null);
  const stopTimer = useRef<() => void>(() => {});
  const textCb = useRef(onText); textCb.current = onText;
  const errCb = useRef(onError); errCb.current = onError;

  const stop = useCallback(() => { if (rec.current?.state === "recording") rec.current.stop(); }, []);

  const start = useCallback(async (autoStop: boolean) => {
    if (rec.current?.state === "recording") return;
    window.speechSynthesis?.cancel();
    let stream: MediaStream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
    catch { errCb.current("Microphone not allowed. Allow it in the browser's address bar and try again."); return; }
    const type = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg"].find((t) => MediaRecorder.isTypeSupported?.(t)) ?? "";
    const mr = new MediaRecorder(stream, type ? { mimeType: type } : undefined);
    const chunks: Blob[] = [];
    mr.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };

    // Level meter and silence detection.
    const ac = new AudioContext();
    const an = ac.createAnalyser(); an.fftSize = 1024;
    ac.createMediaStreamSource(stream).connect(an);
    const buf = new Uint8Array(an.fftSize);
    const started = Date.now();
    let lastSound = Date.now(), heard = false, raf = 0;
    const tick = () => {
      an.getByteTimeDomainData(buf);
      let sum = 0; for (const v of buf) sum += ((v - 128) / 128) ** 2;
      const rms = Math.sqrt(sum / buf.length);
      setLevel(Math.min(1, rms * 6));
      if (rms > 0.03) { lastSound = Date.now(); heard = true; }
      const now = Date.now();
      if (autoStop && heard && now - lastSound > 1600 && now - started > 1200) return stop();
      if (now - started > 120_000) return stop();
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    stopTimer.current = () => { cancelAnimationFrame(raf); ac.close().catch(() => {}); stream.getTracks().forEach((t) => t.stop()); setLevel(0); };

    mr.onstop = async () => {
      stopTimer.current();
      setRecording(false);
      const blob = new Blob(chunks, { type: mr.mimeType || "audio/webm" });
      if (blob.size < 2000 || !heard) return; // nothing said
      setTranscribing(true);
      try {
        const fd = new FormData(); fd.append("audio", blob, "voice");
        const res = await fetch("/api/transcribe", { method: "POST", body: fd });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        if (data.text) textCb.current(data.text);
      } catch (e) { errCb.current((e as Error).message); }
      finally { setTranscribing(false); }
    };
    rec.current = mr;
    mr.start();
    setRecording(true);
  }, [stop]);

  const speak = useCallback((markdown: string, onEnd?: () => void) => {
    const synth = window.speechSynthesis;
    if (!synth) { onEnd?.(); return; }
    synth.cancel();
    const plain = markdown
      .replace(/```[\s\S]*?```/g, " ")
      .replace(/^\s*\|.*\|\s*$/gm, " ")
      .replace(/!?\[([^\]]*)\]\([^)]*\)/g, "$1")
      .replace(/[*_#>`~]/g, "")
      .replace(/\s+/g, " ").trim();
    if (!plain) { onEnd?.(); return; }
    // Speak sentence by sentence (long single utterances get cut off in some browsers).
    const parts = plain.match(/[^.!?]+[.!?]*/g) ?? [plain];
    setSpeaking(true);
    parts.forEach((p, i) => {
      const u = new SpeechSynthesisUtterance(p.trim());
      u.lang = guessLang(plain);
      u.rate = 1.05;
      if (i === parts.length - 1) u.onend = () => { setSpeaking(false); onEnd?.(); };
      u.onerror = () => { if (i === parts.length - 1) { setSpeaking(false); onEnd?.(); } };
      synth.speak(u);
    });
  }, []);

  const quiet = useCallback(() => { window.speechSynthesis?.cancel(); setSpeaking(false); }, []);

  useEffect(() => () => { stopTimer.current(); window.speechSynthesis?.cancel(); }, []);

  return { recording, transcribing, speaking, level, start, stop, speak, quiet };
}

/** Picks a voice language from the reply text, so a Turkish answer isn't read with an English voice. */
function guessLang(t: string): string {
  if (/[ğışĞİŞ]/.test(t)) return "tr-TR";
  if (/[ñ¿¡]/.test(t) || /\b(que|para|con|los|las|una)\b/i.test(t)) return "es-ES";
  if (/\b(het|een|niet|ook|voor|zijn)\b/i.test(t)) return "nl-NL";
  if (/[α-ωΑ-Ω]/.test(t)) return "el-GR";
  if (/[äöüß]/.test(t) && /\b(und|der|die|das|nicht)\b/i.test(t)) return "de-DE";
  if (/[çöü]/.test(t) && /\b(ve|bir|bu|için|ile)\b/i.test(t)) return "tr-TR";
  return navigator.language || "en-US";
}
