"use client";

import { useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { History, MessageSquarePlus, MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { deleteConversation, renameConversation } from "@/lib/actions";
import { ago, cn } from "@/lib/utils";

export type ConvoItem = { id: number; title: string; departmentId: number | null; updatedAt: Date };
type Dept = { id: number; name: string };

export function ChatShell({ conversations, departments, children }: { conversations: ConvoItem[]; departments: Dept[]; children: React.ReactNode }) {
  const path = usePathname();
  const [filter, setFilter] = useState("all");
  const [open, setOpen] = useState(false);
  const deptName = (id: number | null) => departments.find((d) => d.id === id)?.name;
  const shown = useMemo(() => conversations.filter((c) => filter === "all" || (filter === "none" ? c.departmentId === null : String(c.departmentId) === filter)), [conversations, filter]);
  const newHref = filter !== "all" && filter !== "none" ? `/chat?dept=${filter}` : "/chat";

  const list = (
    <div className="flex h-full flex-col">
      <div className="grid gap-2 p-3">
        <Button asChild className="justify-start"><Link href={newHref} onClick={() => setOpen(false)}><MessageSquarePlus /> New chat</Link></Button>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger aria-label="Filter chats by department"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All chats</SelectItem>
            <SelectItem value="none">General</SelectItem>
            {departments.map((d) => <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <nav className="min-h-0 flex-1 overflow-y-auto px-2 pb-3" aria-label="Chat history">
        {shown.length ? shown.map((c) => (
          <Row key={c.id} c={c} active={path === `/chat/${c.id}`} dept={deptName(c.departmentId)} onNavigate={() => setOpen(false)} />
        )) : <p className="px-3 py-6 text-sm text-muted-foreground">No chats here yet.</p>}
      </nav>
    </div>
  );

  return (
    <div className="flex h-dvh min-h-0">
      <aside className="hidden w-72 shrink-0 border-r bg-sidebar lg:block">{list}</aside>
      {open && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/30" onClick={() => setOpen(false)} aria-hidden />
          <aside className="absolute inset-y-0 left-0 w-80 bg-sidebar shadow-xl">{list}</aside>
        </div>
      )}
      <div className="relative flex min-w-0 flex-1 flex-col">
        <Button variant="outline" size="sm" className="absolute top-3 right-3 z-10 bg-card lg:hidden" onClick={() => setOpen(true)}><History /> Chats</Button>
        {children}
      </div>
    </div>
  );
}

function Row({ c, active, dept, onNavigate }: { c: ConvoItem; active: boolean; dept?: string; onNavigate: () => void }) {
  const router = useRouter();
  const [menu, setMenu] = useState(false);
  const [, start] = useTransition();
  return (
    <div className={cn("group relative rounded-lg", active ? "bg-accent" : "hover:bg-muted")}>
      <Link href={`/chat/${c.id}`} onClick={onNavigate} aria-current={active ? "page" : undefined} className="grid gap-0.5 px-3 py-2 pr-9">
        <span className={cn("truncate text-sm", active ? "font-semibold text-accent-foreground" : "text-foreground/90")}>{c.title}</span>
        <span className="truncate text-xs text-muted-foreground">{dept ? `${dept} · ` : ""}{ago(c.updatedAt)}</span>
      </Link>
      <button type="button" onClick={() => setMenu((m) => !m)} aria-label={`Options for ${c.title}`}
        className="absolute top-2 right-2 rounded-md p-1 text-muted-foreground opacity-0 group-hover:opacity-100 hover:bg-background focus-visible:opacity-100">
        <MoreHorizontal className="size-4" />
      </button>
      {menu && (
        <div className="absolute top-9 right-2 z-20 grid w-36 rounded-lg border bg-popover p-1 text-sm shadow-md" onMouseLeave={() => setMenu(false)}>
          <button type="button" className="flex items-center gap-2 rounded-md px-2 py-1.5 text-left hover:bg-muted" onClick={() => {
            setMenu(false);
            const t = prompt("Rename chat", c.title);
            if (t) start(async () => { const r = await renameConversation(c.id, t); if (!r.ok) toast.error(r.error); router.refresh(); });
          }}><Pencil className="size-3.5" /> Rename</button>
          <button type="button" className="flex items-center gap-2 rounded-md px-2 py-1.5 text-left text-destructive hover:bg-muted" onClick={() => {
            setMenu(false);
            if (!confirm("Delete this chat? This can't be undone.")) return;
            start(async () => { const r = await deleteConversation(c.id); if (!r.ok) toast.error(r.error); if (active) router.push("/chat"); router.refresh(); });
          }}><Trash2 className="size-3.5" /> Delete</button>
        </div>
      )}
    </div>
  );
}
