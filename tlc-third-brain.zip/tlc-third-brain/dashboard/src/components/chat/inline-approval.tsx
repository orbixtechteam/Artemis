"use client";

import { useEffect, useState, useTransition } from "react";
import { Check, Loader2, Mail, MessageSquare, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { approveOutbox, getOutboxItem, rejectOutbox } from "@/lib/actions";
import { cn } from "@/lib/utils";

type Item = NonNullable<Awaited<ReturnType<typeof getOutboxItem>>>;

/** An email or Slack message waiting for approval, decided right inside the chat. */
export function InlineApproval({ id }: { id: number }) {
  const [item, setItem] = useState<Item | null>(null);
  const [body, setBody] = useState("");
  const [why, setWhy] = useState("");
  const [rejecting, setRejecting] = useState(false);
  const [sendAs, setSendAs] = useState<"bot" | "me">("bot");
  const [pending, start] = useTransition();
  const load = () => getOutboxItem(id).then((x) => { setItem(x); if (x) setBody(x.body); });
  useEffect(() => { load(); }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!item) return null;
  const email = item.channel === "gmail";
  const where = email ? `Email to ${item.toAddr}${item.subject ? ` · ${item.subject}` : ""}` : `Slack · ${item.slackChannel}`;

  if (item.status !== "pending") {
    return (
      <div className={cn("inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs", item.status === "sent" ? "text-signal-green" : "text-muted-foreground")}>
        {item.status === "sent" ? <Check className="size-3.5" /> : <X className="size-3.5" />}
        {where}: {item.status}{item.decidedBy ? ` by ${item.decidedBy}` : ""}{item.status === "failed" && item.error ? ` (${item.error})` : ""}
      </div>
    );
  }
  return (
    <div className="grid gap-2 rounded-xl border bg-card p-3">
      <span className="flex items-center gap-1.5 text-sm font-semibold">{email ? <Mail className="size-4 text-primary" /> : <MessageSquare className="size-4 text-primary" />}{where}</span>
      <textarea value={body} onChange={(e) => setBody(e.target.value)} disabled={!item.canDecide || pending} rows={Math.min(10, Math.max(3, body.split("\n").length + 1))}
        className="w-full resize-y rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:border-ring" aria-label="Message to approve" />
      {!item.canDecide ? <span className="text-xs text-muted-foreground">Waiting for an admin to approve.</span> : rejecting ? (
        <div className="flex flex-wrap items-center gap-2">
          <input value={why} onChange={(e) => setWhy(e.target.value)} placeholder="What's wrong? (becomes a lesson)" autoFocus
            className="h-8 min-w-0 flex-1 rounded-lg border bg-background px-3 text-sm outline-none focus:border-ring" />
          <Button size="sm" variant="ghost" onClick={() => setRejecting(false)} disabled={pending}>Cancel</Button>
          <Button size="sm" variant="destructive" disabled={pending} onClick={() => start(async () => {
            const r = await rejectOutbox(id, why); if (!r.ok) toast.error(r.error); await load();
          })}>Reject</Button>
        </div>
      ) : (
        <div className="flex flex-wrap items-center justify-end gap-2">
          {!email && (
            <select value={sendAs} onChange={(e) => setSendAs(e.target.value as "bot" | "me")} aria-label="Send as" className="mr-auto h-8 rounded-md border bg-transparent px-2 text-sm">
              <option value="bot">Send as the Slack bot</option>
              <option value="me">Send as me</option>
            </select>
          )}
          <Button size="sm" variant="ghost" onClick={() => setRejecting(true)} disabled={pending}>Reject</Button>
          <Button size="sm" disabled={pending || !body.trim()} onClick={() => start(async () => {
            const r = await approveOutbox(id, { body, ...(email ? {} : { sendAs }) });
            if (r.ok) toast.success(email ? "Email sent" : "Posted in Slack"); else toast.error(r.error);
            await load();
          })}>{pending ? <Loader2 className="animate-spin" /> : <Check />} {email ? "Approve and send" : "Approve and post"}</Button>
        </div>
      )}
    </div>
  );
}
