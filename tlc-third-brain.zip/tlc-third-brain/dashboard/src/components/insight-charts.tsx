import { cn } from "@/lib/utils";

export function Pareto({ rows }: { rows: { id: number; task: string; hours: number; cumulative: number; top: boolean }[] }) {
  const W = 760, H = 260, L = 34, R = 40, T = 12, B = 30;
  const max = Math.max(...rows.map((r) => r.hours));
  const slot = (W - L - R) / rows.length;
  const y = (h: number) => T + (H - T - B) * (1 - h / max);
  const yc = (c: number) => T + (H - T - B) * (1 - c);
  const line = rows.map((r, i) => `${i ? "L" : "M"}${L + slot * i + slot / 2},${yc(r.cumulative)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label="Hours a week per job, largest first, with the cumulative share">
      {[0.25, 0.5, 0.75, 1].map((g) => <line key={g} x1={L} x2={W - R} y1={yc(g)} y2={yc(g)} className="stroke-border" strokeDasharray="3 4" />)}
      <line x1={L} x2={W - R} y1={yc(0.8)} y2={yc(0.8)} className="stroke-signal-amber" strokeDasharray="5 4" />
      <text x={W - R + 4} y={yc(0.8) + 4} className="fill-signal-amber text-[11px] font-semibold">80%</text>
      {rows.map((r, i) => (
        <g key={r.id}>
          <rect x={L + slot * i + 4} y={y(r.hours)} width={slot - 8} height={H - B - y(r.hours)} rx={3} className={r.top ? "fill-primary" : "fill-muted-foreground/35"}><title>{`${r.task}: ${r.hours} h/week`}</title></rect>
          <text x={L + slot * i + slot / 2} y={H - B + 14} textAnchor="middle" className="fill-muted-foreground text-[11px]">{i + 1}</text>
        </g>
      ))}
      <path d={line} fill="none" className="stroke-foreground" strokeWidth={1.5} />
      {rows.map((r, i) => <circle key={r.id} cx={L + slot * i + slot / 2} cy={yc(r.cumulative)} r={2.5} className="fill-foreground" />)}
      <text x={L - 6} y={y(max) + 4} textAnchor="end" className="fill-muted-foreground text-[11px]">{max}h</text>
      <text x={L - 6} y={H - B + 4} textAnchor="end" className="fill-muted-foreground text-[11px]">0</text>
    </svg>
  );
}

export function WeekBars({ weeks }: { weeks: { label: string; n: number }[] }) {
  const W = 520, H = 150, B = 22, max = Math.max(1, ...weeks.map((w) => w.n)), slot = W / weeks.length;
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label="Corrections logged per week">
      {weeks.map((w, i) => {
        const h = (w.n / max) * (H - B - 18);
        return (
          <g key={w.label}>
            <rect x={i * slot + 8} y={H - B - h} width={slot - 16} height={Math.max(h, 1)} rx={3} className="fill-signal-amber"><title>{`Week of ${w.label}: ${w.n}`}</title></rect>
            {w.n > 0 && <text x={i * slot + slot / 2} y={H - B - h - 4} textAnchor="middle" className="fill-foreground text-[11px] font-semibold">{w.n}</text>}
            <text x={i * slot + slot / 2} y={H - 6} textAnchor="middle" className="fill-muted-foreground text-[10px]">{w.label}</text>
          </g>
        );
      })}
    </svg>
  );
}
