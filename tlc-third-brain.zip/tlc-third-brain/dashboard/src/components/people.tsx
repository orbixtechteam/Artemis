"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Copy } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { resetPassword, savePerson } from "@/lib/actions";
import { ROLES } from "@/lib/constants";
import { ago } from "@/lib/utils";

export type Person = { id: number; name: string; email: string; role: string; departments: number[]; active: boolean; whatsapp?: boolean; lastLogin: Date | null };
type Dept = { id: number; name: string };

export function People({ people, departments, meIsOwner }: { people: Person[]; departments: Dept[]; meIsOwner: boolean }) {
  const [editing, setEditing] = useState<Person | "new" | null>(null);
  const [secret, setSecret] = useState<{ name: string; email: string; link: string } | null>(null);
  const deptNames = (p: Person) => (p.role === "owner" || p.role === "admin" ? "All departments"
    : p.departments.map((id) => departments.find((d) => d.id === id)?.name).filter(Boolean).join(", ") || "None yet");

  return (
    <section className="mt-8 grid gap-3">
      <div className="flex items-end justify-between gap-3">
        <div><h2 className="text-lg font-bold">People</h2><p className="text-sm text-muted-foreground">Who can open the dashboard and which departments they see.</p></div>
        <Button onClick={() => setEditing("new")}>Add person</Button>
      </div>
      <Table>
        <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Email</TableHead><TableHead>Role</TableHead><TableHead>Departments</TableHead><TableHead>Last sign-in</TableHead></TableRow></TableHeader>
        <TableBody>
          {people.map((p) => (
            <TableRow key={p.id} data-clickable onClick={() => setEditing(p)}>
              <TableCell className="font-semibold">{p.name} {!p.active && <Badge>off</Badge>}</TableCell>
              <TableCell>{p.email}</TableCell>
              <TableCell><Badge tone={p.role === "owner" ? "accent" : "neutral"}>{p.role}</Badge></TableCell>
              <TableCell className="max-w-[40ch]">{deptNames(p)}</TableCell>
              <TableCell className="num">{ago(p.lastLogin)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {editing && (
        <PersonDialog person={editing === "new" ? null : editing} departments={departments} meIsOwner={meIsOwner}
          onClose={() => setEditing(null)} onSecret={(s) => { setEditing(null); setSecret(s); }} />
      )}
      <Dialog open={!!secret} onOpenChange={(o) => !o && setSecret(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Access link for {secret?.name}</DialogTitle>
            <DialogDescription>A one-time link where they set their own password (valid 72 hours). Send it one to one, never in a group chat. No password is shown or sent.</DialogDescription>
          </DialogHeader>
          <pre className="rounded-md bg-muted px-3 py-2.5 font-mono text-sm whitespace-pre-wrap select-all">{secret && loginText(secret)}</pre>
          <DialogFooter>
            <Button variant="outline" onClick={() => secret && navigator.clipboard.writeText(loginText(secret)).then(() => toast.success("Copied"))}><Copy /> Copy access message</Button>
            <Button onClick={() => setSecret(null)}>Done</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}

function PersonDialog({ person, departments, meIsOwner, onClose, onSecret }: {
  person: Person | null; departments: Dept[]; meIsOwner: boolean; onClose: () => void; onSecret: (s: { name: string; email: string; link: string }) => void;
}) {
  const isNew = !person;
  const owner = person?.role === "owner";
  const [name, setName] = useState(person?.name ?? "");
  const [email, setEmail] = useState(person?.email ?? "");
  const [role, setRole] = useState(person?.role && !owner ? person.role : "viewer");
  const [depts, setDepts] = useState<number[]>(person?.departments ?? []);
  const [active, setActive] = useState(person?.active ?? true);
  const [whatsapp, setWhatsapp] = useState(person?.whatsapp ?? false);
  const [error, setError] = useState("");
  const [pending, start] = useTransition();
  const router = useRouter();
  const roles = Object.entries(ROLES).filter(([k]) => k !== "owner");
  void meIsOwner;

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    start(async () => {
      const r = await savePerson({ id: person?.id, name, email: isNew ? email : undefined, role: owner ? undefined : (role as "admin" | "editor" | "viewer"), departments: depts, active: owner ? undefined : active, whatsapp: meIsOwner && !owner ? whatsapp : undefined });
      if (!r.ok) return setError(r.error ?? "Couldn't save.");
      router.refresh();
      if (r.link) onSecret({ name, email: isNew ? email : person!.email, link: r.link });
      else { toast.success(isNew ? "Added person" : "Saved changes"); onClose(); }
    });
  };
  const reset = () => start(async () => {
    const r = await resetPassword(person!.id);
    if (!r.ok || !r.link) return setError(r.error ?? "Couldn't create the link.");
    onSecret({ name, email: person!.email, link: r.link });
  });

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <form onSubmit={save} className="grid gap-4">
          <DialogHeader>
            <DialogTitle>{isNew ? "Add person" : person.name}</DialogTitle>
            <DialogDescription>{owner ? "The owner sees and manages everything." : "Admins see everything. Editors and viewers see only the departments you tick."}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2"><Label htmlFor="p-name">Name</Label><Input id="p-name" required value={name} onChange={(e) => setName(e.target.value)} /></div>
            <div className="grid gap-2"><Label htmlFor="p-email">Email</Label><Input id="p-email" type="email" required disabled={!isNew} value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          </div>
          {!owner && (
            <>
              <div className="grid gap-2">
                <Label htmlFor="p-role">Role</Label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger id="p-role"><SelectValue /></SelectTrigger>
                  <SelectContent>{roles.map(([k, t]) => <SelectItem key={k} value={k}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              {role !== "admin" && (
                <fieldset className="grid gap-2">
                  <legend className="mb-2 text-sm font-semibold">Departments they can see</legend>
                  <div className="flex flex-wrap gap-x-5 gap-y-2">
                    {departments.map((d) => (
                      <Label key={d.id} className="font-medium">
                        <Checkbox checked={depts.includes(d.id)} onCheckedChange={(c) => setDepts((s) => (c ? [...s, d.id] : s.filter((x) => x !== d.id)))} />
                        {d.name}
                      </Label>
                    ))}
                  </div>
                </fieldset>
              )}
              {!isNew && <Label className="font-medium"><Checkbox checked={active} onCheckedChange={(c) => setActive(c === true)} /> Can sign in</Label>}
              {meIsOwner && !owner && <Label className="font-medium"><Checkbox checked={whatsapp} onCheckedChange={(c) => setWhatsapp(c === true)} /> Can use WhatsApp through Jarvis</Label>}
            </>
          )}
          {isNew && <p className="text-sm text-muted-foreground">They'll get a one-time link to set their own password. No password is created for you to pass on.</p>}
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          <DialogFooter className="sm:justify-between">
            {!isNew ? <Button type="button" variant="outline" onClick={reset} disabled={pending}>Send new password link</Button> : <span />}
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={pending}>{isNew ? "Add person" : "Save changes"}</Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function loginText(s: { name: string; email: string; link: string }) {
  const url = typeof window !== "undefined" ? `${window.location.origin}/login` : "/login";
  return `Hi ${s.name.split(" ")[0]}, your Third Brain access is ready.

Set your own password and sign in (one-time link, 72 hours): ${s.link}

Use it from your own Claude: Settings → Connectors → Add custom connector → ${url.replace(/\/login$/, "")}/api/mcp → Connect → Allow.`;
}
