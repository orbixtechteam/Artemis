"use client";

import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { oauthDecision } from "@/lib/actions";

type Params = { client_id: string; redirect_uri: string; code_challenge: string; state: string; scope: string; resource: string };

export function ConsentForm({ params }: { params: Params }) {
  const [error, setError] = useState("");
  const [pending, start] = useTransition();
  const decide = (allow: boolean) => start(async () => {
    const r = await oauthDecision(params, allow);
    if (r.ok && r.redirect) window.location.href = r.redirect;
    else setError(r.error ?? "Something went wrong.");
  });
  return (
    <div className="grid gap-3">
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <div className="flex gap-2">
        <Button variant="outline" className="flex-1" disabled={pending} onClick={() => decide(false)}>Cancel</Button>
        <Button className="flex-1" disabled={pending} onClick={() => decide(true)}>{pending ? "Connecting" : "Allow"}</Button>
      </div>
    </div>
  );
}
