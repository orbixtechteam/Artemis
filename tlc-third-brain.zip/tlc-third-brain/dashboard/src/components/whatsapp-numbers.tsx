"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { deleteWhatsappNumber, saveWhatsappNumber } from "@/lib/actions";

type Num = { id: number; phone: string; label: string; readers: number[]; senders: number[] };
type Person = { id: number; name: string; role: string };

export function WhatsappNumbers({ numbers, people }: { numbers: Num[]; people: Person[] }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [draft, setDraft] = useState<Num>({ id: 0, phone: "", label: "", readers: [], senders: [] });
  const others = people.filter((p) => p.role !== "owner");
  const save = (n: Num) => start(async () => {
    const r = await saveWhatsappNumber({ id: n.id || undefined, phone: n.phone, label: n.label, readers: n.readers, senders: n.senders });
    if (r.ok) { toast.success("Saved"); if (!n.id) setDraft({ id: 0, phone: "", label: "", readers: [], senders: [] }); router.refresh(); } else toast.error(r.error);
  });
  return (
    <Card className="mt-8">
      <CardHeader className="grid gap-1">
        <CardTitle>WhatsApp numbers</CardTitle>
        <p className="text-sm text-muted-foreground">Numbers in Periskope, and who may read or send from each. Tick one or more people per number. People see only the numbers ticked for them, in the dashboard chat and their own Claude. Only Noah changes access to his own number.</p>
      </CardHeader>
      <CardContent className="grid gap-4">
        {[...numbers, draft].map((n) => <Row key={n.id || "new"} n={n} people={others} pending={pending} onSave={save}
          onChange={n.id ? undefined : setDraft} onDelete={n.id ? () => { if (confirm(`Remove ${n.label}? People lose access to it.`)) start(async () => { await deleteWhatsappNumber(n.id); router.refresh(); }); } : undefined} />)}
      </CardContent>
    </Card>
  );
}

function Row({ n, people, pending, onSave, onChange, onDelete }: { n: Num; people: Person[]; pending: boolean; onSave: (n: Num) => void; onChange?: (n: Num) => void; onDelete?: () => void }) {
  const [v, setV] = useState(n);
  const cur = onChange ? n : v;
  const set = (x: Num) => (onChange ? onChange(x) : setV(x));
  const toggle = (key: "readers" | "senders", id: number, on: boolean) => {
    const next = { ...cur, [key]: on ? [...new Set([...cur[key], id])] : cur[key].filter((x) => x !== id) };
    if (key === "senders" && on) next.readers = [...new Set([...next.readers, id])];
    set(next);
  };
  return (
    <div className="grid gap-3 rounded-xl border p-4">
      <div className="grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
        <Input placeholder="Label, e.g. Clinic" value={cur.label} onChange={(e) => set({ ...cur, label: e.target.value })} aria-label="Label" />
        <Input placeholder="+34…" value={cur.phone} onChange={(e) => set({ ...cur, phone: e.target.value })} aria-label="Phone number" />
        <div className="flex gap-2">
          <Button disabled={pending} onClick={() => onSave(cur)}>{n.id ? "Save" : "Add number"}</Button>
          {onDelete && <Button variant="ghost" className="text-destructive" onClick={onDelete}>Remove</Button>}
        </div>
      </div>
      {people.length > 0 && (
        <div className="overflow-x-auto">
          <table className="text-sm">
            <thead><tr className="text-left text-xs text-muted-foreground"><th className="pr-6 font-medium">Person</th><th className="pr-6 font-medium">Can read</th><th className="font-medium">Can send</th></tr></thead>
            <tbody>
              {people.map((p) => (
                <tr key={p.id}>
                  <td className="py-1 pr-6">{p.name}</td>
                  <td className="py-1 pr-6"><input type="checkbox" checked={cur.readers.includes(p.id)} onChange={(e) => toggle("readers", p.id, e.target.checked)} aria-label={`${p.name} can read`} /></td>
                  <td className="py-1"><input type="checkbox" checked={cur.senders.includes(p.id)} onChange={(e) => toggle("senders", p.id, e.target.checked)} aria-label={`${p.name} can send`} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
