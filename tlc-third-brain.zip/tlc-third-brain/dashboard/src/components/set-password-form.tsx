"use client";

import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { setPasswordWithLink } from "@/lib/actions";

export function SetPasswordForm({ token }: { token: string }) {
  const [pw, setPw] = useState(""), [again, setAgain] = useState(""), [error, setError] = useState("");
  const [pending, start] = useTransition();
  return (
    <form className="grid gap-4" onSubmit={(e) => { e.preventDefault(); start(async () => { const r = await setPasswordWithLink(token, pw, again); if (r && !r.ok) setError(r.error ?? "Couldn't save."); }); }}>
      <div className="grid gap-2"><Label htmlFor="pw">New password (at least 10 characters)</Label><Input id="pw" type="password" autoComplete="new-password" required minLength={10} value={pw} onChange={(e) => setPw(e.target.value)} autoFocus /></div>
      <div className="grid gap-2"><Label htmlFor="pw2">Same password again</Label><Input id="pw2" type="password" autoComplete="new-password" required value={again} onChange={(e) => setAgain(e.target.value)} /></div>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <Button type="submit" disabled={pending}>{pending ? "Saving" : "Save and sign in"}</Button>
    </form>
  );
}
