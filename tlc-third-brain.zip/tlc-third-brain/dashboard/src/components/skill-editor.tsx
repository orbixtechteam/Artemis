"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Markdown } from "@/components/chat/markdown";
import { approveSkill, saveSkill, skillFor } from "@/lib/actions";

/** View and edit a playbook's SKILL.md in place: save as a proposal, then approve to publish it for Jarvis. */
export function SkillEditor({ playbookId, clinical }: { playbookId: number; clinical: boolean }) {
  const router = useRouter();
  const [data, setData] = useState<{ approved?: string | null; proposed?: string | null; canEdit?: boolean } | null>(null);
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState("");
  const [reason, setReason] = useState("");
  const [pending, start] = useTransition();
  const load = () => skillFor(playbookId).then((r) => { setData(r); setText(r.proposed ?? r.approved ?? ""); });
  useEffect(() => { load(); }, [playbookId]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!data) return null;
  const hasDraft = !!data.proposed && data.proposed.replace(/^PROPOSED [^\n]*\n+/, "").trim() !== (data.approved ?? "").trim();
  const shown = (hasDraft ? data.proposed : data.approved ?? data.proposed) ?? "";

  return (
    <Card className="mt-6">
      <CardHeader className="flex-row items-center justify-between gap-3">
        <div className="grid gap-1">
          <CardTitle>SKILL.md</CardTitle>
          <p className="text-sm text-muted-foreground">
            {!shown ? "No skill yet. Write one here, or ask the brain to draft it from the steps and rules."
              : hasDraft ? "Showing the draft waiting for approval. Jarvis uses the approved version until you approve." : "The version Jarvis uses."}
          </p>
        </div>
        {data.canEdit && !editing && (
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => { setText((data.proposed ?? data.approved ?? "").replace(/^PROPOSED [^\n]*\n+/, "")); setEditing(true); }}>{shown ? "Edit" : "Write"}</Button>
            {hasDraft || (data.proposed && !data.approved) ? (
              <Button disabled={pending} onClick={() => {
                if (!confirm(clinical ? "This is a clinical playbook. Has a doctor approved this version?" : "Publish this version for Jarvis?")) return;
                start(async () => { const r = await approveSkill(playbookId); if (r.ok) { toast.success("Approved: Jarvis uses it now"); await load(); router.refresh(); } else toast.error(r.error); });
              }}>Approve</Button>
            ) : null}
          </div>
        )}
      </CardHeader>
      <CardContent>
        {editing ? (
          <div className="grid gap-3">
            <textarea value={text} onChange={(e) => setText(e.target.value)} rows={Math.min(40, Math.max(14, text.split("\n").length + 2))}
              className="w-full resize-y rounded-lg border bg-background px-3 py-2 font-mono text-sm outline-none focus:border-ring" aria-label="SKILL.md" />
            <Input placeholder="What did you change, and why? (kept in the history)" value={reason} onChange={(e) => setReason(e.target.value)} aria-label="Reason" />
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setEditing(false)} disabled={pending}>Cancel</Button>
              <Button disabled={pending || text.trim().length < 20} onClick={() => start(async () => {
                const r = await saveSkill(playbookId, text, reason);
                if (r.ok) { toast.success("Saved as a draft. Approve it to publish."); setEditing(false); setReason(""); await load(); } else toast.error(r.error);
              })}>Save draft</Button>
            </div>
          </div>
        ) : shown ? (
          <div className="max-h-[70vh] overflow-y-auto rounded-lg border bg-background px-5 py-4"><Markdown text={shown.replace(/^PROPOSED [^\n]*\n+/, "")} /></div>
        ) : null}
      </CardContent>
    </Card>
  );
}
