"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { addMcpServer, removeMcpServer } from "@/lib/actions";

type Server = { id: number; name: string; url: string; authType: string; status: string; lastError: string };

export function MyMcpServers({ servers, presets = [] }: { servers: Server[]; presets?: { name: string; url: string; whatsapp?: boolean }[] }) {
  const router = useRouter();
  const [v, setV] = useState({ name: "", url: "", key: "", clientId: "", clientSecret: "" });
  const [withApp, setWithApp] = useState(false);
  const [withKey, setWithKey] = useState(false);
  const [pending, start] = useTransition();
  return (
    <div className="grid gap-3 border-t pt-4">
      <div>
        <p className="font-semibold">My MCP servers</p>
        <p className="text-sm text-muted-foreground">Add any tool that has an MCP server (for example your Periskope, Notion or Linear). If it uses sign-in you're sent to its login page; if it uses an API key, paste the key. Only you use it, in your own chats.</p>
      </div>
      {servers.map((s) => (
        <div key={s.id} className="flex flex-wrap items-center gap-3 rounded-xl border p-3">
          <div className="min-w-0 flex-1">
            <p className="font-semibold">{s.name}</p>
            <p className="truncate text-xs text-muted-foreground">{s.url}</p>
            {s.status !== "connected" && <p className="text-xs text-destructive">{s.status === "needs_login" || s.status === "new" ? "Needs sign-in" : s.lastError || s.status}</p>}
          </div>
          {s.status !== "connected" && s.authType !== "bearer" && <Button asChild size="sm"><a href={`/api/mcp-connect/start?id=${s.id}`}>Sign in</a></Button>}
          {s.status === "connected" && <span className="text-sm font-semibold text-signal-green">Connected</span>}
          <Button size="sm" variant="ghost" className="text-destructive" disabled={pending} onClick={() => {
            if (!confirm(`Remove ${s.name}?`)) return;
            start(async () => { const r = await removeMcpServer(s.id); if (r.ok) router.refresh(); else toast.error(r.error); });
          }}>Remove</Button>
        </div>
      ))}
      {presets.filter((p) => !servers.some((s) => s.url === p.url)).length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm text-muted-foreground">One click:</span>
          {presets.filter((p) => !servers.some((s) => s.url === p.url)).map((p) => (
            <Button key={p.url} type="button" size="sm" variant="outline" disabled={pending} onClick={() => start(async () => {
              const r = await addMcpServer(p.name, p.url);
              if (!r.ok) { toast.error(r.error); return; }
              if (r.signIn) window.location.href = r.signIn; else { toast.success(`${p.name} connected`); router.refresh(); }
            })}>{p.name}</Button>
          ))}
        </div>
      )}
      <form className="grid gap-2 sm:grid-cols-[1fr_2fr_auto]" onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          const r = await addMcpServer(v.name, v.url, withKey ? v.key : undefined, withApp && v.clientId ? { id: v.clientId, secret: v.clientSecret } : undefined);
          if (!r.ok) { toast.error(r.error); return; }
          setV({ name: "", url: "", key: "", clientId: "", clientSecret: "" });
          if (r.signIn) window.location.href = r.signIn; else { toast.success("Connected"); router.refresh(); }
        });
      }}>
        <Input placeholder="Name, e.g. Periskope" value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} aria-label="Server name" />
        <Input placeholder="https://… /mcp address" value={v.url} onChange={(e) => setV({ ...v, url: e.target.value })} aria-label="Server address" />
        <Button type="submit" disabled={pending}>{pending ? "Connecting" : "Add"}</Button>
        <label className="flex items-center gap-2 text-sm text-muted-foreground sm:col-span-3">
          <input type="checkbox" checked={withKey} onChange={(e) => setWithKey(e.target.checked)} /> It uses an API key instead of sign-in
        </label>
        {withKey && <Input className="sm:col-span-3" type="password" placeholder="API key or token" value={v.key} onChange={(e) => setV({ ...v, key: e.target.value })} aria-label="API key" />}
        <label className="flex items-center gap-2 text-sm text-muted-foreground sm:col-span-3">
          <input type="checkbox" checked={withApp} onChange={(e) => setWithApp(e.target.checked)} /> I created my own app for it (e.g. Asana)
        </label>
        {withApp && (
          <div className="grid gap-2 sm:col-span-3 sm:grid-cols-2">
            <Input placeholder="Client ID" value={v.clientId} onChange={(e) => setV({ ...v, clientId: e.target.value })} aria-label="Client ID" />
            <Input type="password" placeholder="Client secret" value={v.clientSecret} onChange={(e) => setV({ ...v, clientSecret: e.target.value })} aria-label="Client secret" />
            <p className="text-xs text-muted-foreground sm:col-span-2">In your app's settings, add this redirect URL: <code>{typeof window !== "undefined" ? window.location.origin : ""}/api/mcp-connect/callback</code></p>
          </div>
        )}
      </form>
    </div>
  );
}
