"use client";

import { useState, useTransition } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { changePassword } from "@/lib/actions";

export function PasswordForm() {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [error, setError] = useState("");
  const [pending, start] = useTransition();
  return (
    <form className="grid gap-4" onSubmit={(e) => {
      e.preventDefault();
      start(async () => {
        const r = await changePassword(current, next);
        if (!r.ok) return setError(r.error ?? "Couldn't change the password.");
        setError(""); setCurrent(""); setNext(""); toast.success("Password changed");
      });
    }}>
      <div className="grid gap-2"><Label htmlFor="cur">Current password</Label><Input id="cur" type="password" autoComplete="current-password" required value={current} onChange={(e) => setCurrent(e.target.value)} /></div>
      <div className="grid gap-2"><Label htmlFor="new">New password</Label><Input id="new" type="password" autoComplete="new-password" minLength={10} required value={next} onChange={(e) => setNext(e.target.value)} /></div>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
      <div><Button type="submit" disabled={pending}>Change password</Button></div>
    </form>
  );
}
