export function PageHead({ title, intro, crumbs, children }: { title: string; intro?: string; crumbs?: React.ReactNode; children?: React.ReactNode }) {
  return (
    <div className="mb-6 grid gap-2">
      {crumbs && <p className="text-sm text-muted-foreground">{crumbs}</p>}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="grid gap-1.5">
          <h1 className="text-3xl font-extrabold tracking-tight">{title}</h1>
          {intro && <p className="max-w-[70ch] text-muted-foreground">{intro}</p>}
        </div>
        {children && <div className="flex gap-2">{children}</div>}
      </div>
    </div>
  );
}
