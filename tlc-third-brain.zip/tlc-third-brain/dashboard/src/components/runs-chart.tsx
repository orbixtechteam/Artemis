export function RunsChart({ days }: { days: { d: string; ok: number; bad: number }[] }) {
  if (!days.length) return <p className="py-4 text-sm text-muted-foreground">No runs logged yet.</p>;
  const W = 560, H = 130, slot = W / 14, bw = slot - 8, max = Math.max(...days.map((r) => r.ok + r.bad), 1);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="h-32 w-full" role="img" aria-label="Runs per day, ok and failed">
      {days.map((r, i) => {
        const x = i * slot + 4, hOk = (r.ok / max) * (H - 22), hBad = (r.bad / max) * (H - 22);
        return (
          <g key={r.d}>
            <rect x={x} y={H - 16 - hOk - hBad} width={bw} height={hOk} rx={2} className="fill-signal-green"><title>{`${r.d}: ${r.ok} ok`}</title></rect>
            <rect x={x} y={H - 16 - hBad} width={bw} height={hBad} rx={2} className="fill-signal-red"><title>{`${r.d}: ${r.bad} failed`}</title></rect>
            <text x={x + bw / 2} y={H - 3} textAnchor="middle" className="fill-muted-foreground text-[10px]">{r.d.slice(8)}</text>
          </g>
        );
      })}
    </svg>
  );
}
