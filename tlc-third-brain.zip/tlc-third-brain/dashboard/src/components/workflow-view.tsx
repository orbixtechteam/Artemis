"use client";

import "@xyflow/react/dist/style.css";
import { memo, useCallback, useEffect, useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Background, BackgroundVariant, Controls, Handle, MarkerType, Position, ReactFlow, ReactFlowProvider,
  useEdgesState, useNodesState, useReactFlow, type Connection, type Edge, type Node, type NodeProps,
} from "@xyflow/react";
import { ChevronDown, ChevronRight, PanelRightClose, PanelRightOpen, Plus } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/status";
import { STEP_KIND_LABEL, STEP_KINDS, type StepKind } from "@/lib/constants";
import { connectSteps, deleteConnection, deleteStep, moveSection, moveStep, saveStep } from "@/lib/workflow-actions";
import { cn } from "@/lib/utils";

export type WfStep = { id: number; playbookId: number; title: string; kind: string; role: string; tool: string; note: string; source: string; x: number; y: number };
export type WfSection = { id: number; name: string; status: string; autonomy: string; canvasX: number | null; canvasY: number | null; steps: WfStep[] };
export type WfConnection = { id: number; fromId: number; toId: number; label: string };

const KIND_BAR: Record<string, string> = {
  person: "bg-kind-person", automation: "bg-kind-automation", ai_agent: "bg-kind-ai", empty: "bg-kind-empty",
};
const STEP_W = 184, STEP_H = 92, PAD_X = 24, HEAD = 56, COL_GAP = 80, ROW_GAP = 72;

const sectionSize = (s: WfSection) => ({
  w: Math.max(420, ...s.steps.map((st) => st.x + STEP_W + PAD_X)),
  h: Math.max(200, ...s.steps.map((st) => st.y + STEP_H + PAD_X)),
});

/** Sections without a saved position flow into two columns. */
function layout(sections: WfSection[]) {
  const pos = new Map<number, { x: number; y: number }>();
  const colY = [0, 0];
  const colW = [0, 0];
  sections.forEach((s, i) => { if (s.canvasX == null) colW[i % 2] = Math.max(colW[i % 2], sectionSize(s).w); });
  sections.forEach((s, i) => {
    if (s.canvasX != null && s.canvasY != null) return pos.set(s.id, { x: s.canvasX, y: s.canvasY });
    const c = i % 2;
    pos.set(s.id, { x: c === 0 ? 0 : colW[0] + COL_GAP, y: colY[c] });
    colY[c] += sectionSize(s).h + ROW_GAP;
  });
  return pos;
}

function toolTone(tool: string) {
  let h = 0;
  for (const c of tool) h = (h * 31 + c.charCodeAt(0)) % 360;
  return `hsl(${h} 55% 45%)`;
}

// ---------- nodes ----------
type StepData = { step: WfStep; dim: boolean };
type SectionData = { section: WfSection; canEdit: boolean; onAdd: (playbookId: number) => void };

const StepNode = memo(function StepNode({ data, selected }: NodeProps<Node<StepData>>) {
  const s = data.step;
  return (
    <div className={cn("relative w-[184px] overflow-hidden rounded-lg border bg-card text-card-foreground shadow-sm transition-opacity",
      selected && "ring-2 ring-ring", data.dim && "opacity-25")}>
      <Handle type="target" position={Position.Left} className="!size-2.5 !border-2 !border-card !bg-muted-foreground" />
      <div className={cn("h-1", KIND_BAR[s.kind] ?? "bg-kind-empty")} />
      <div className="grid gap-2 p-2.5">
        <p className={cn("line-clamp-2 pr-9 text-[12.5px] leading-snug font-semibold", s.kind === "empty" && "text-muted-foreground italic")}>{s.title}</p>
        <div className="flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
          {s.tool ? (
            <span className="inline-flex min-w-0 items-center gap-1.5">
              <span className="grid size-4 shrink-0 place-items-center rounded text-[9px] font-bold text-white" style={{ background: toolTone(s.tool) }}>{s.tool.slice(0, 1).toUpperCase()}</span>
              <span className="truncate">{s.tool}</span>
            </span>
          ) : <span />}
          {s.role && <span className="truncate font-medium text-foreground/70">{s.role}</span>}
        </div>
        {s.note && <p className="truncate text-[10.5px] text-muted-foreground">{s.note}</p>}
      {s.source !== "manual" && (
        <span title={s.source === "skill" ? "From the playbook's SKILL.md" : "From Jarvis"} className="absolute top-2 right-2 rounded bg-muted px-1 text-[9px] font-semibold text-muted-foreground">
          {s.source === "skill" ? "SKILL" : "JARVIS"}
        </span>
      )}
      </div>
      <Handle type="source" position={Position.Right} className="!size-2.5 !border-2 !border-card !bg-muted-foreground" />
    </div>
  );
});

const SectionNode = memo(function SectionNode({ data }: NodeProps<Node<SectionData>>) {
  const s = data.section;
  return (
    <div className="size-full rounded-2xl border border-dashed border-foreground/15 bg-muted/35">
      <div className="flex items-center gap-2 px-4 pt-3">
        <Link href={`/playbooks/${s.id}`} className="nodrag truncate text-sm font-bold hover:underline">{s.name}</Link>
        <StatusBadge status={s.status} />
        {data.canEdit && (
          <Button size="sm" variant="ghost" className="nodrag ml-auto h-7 px-2 text-xs" onClick={() => data.onAdd(s.id)}>
            <Plus className="size-3.5" /> Step
          </Button>
        )}
      </div>
      {!s.steps.length && <p className="px-4 pt-6 text-sm text-muted-foreground">No steps yet.{data.canEdit ? " Add the first one." : ""}</p>}
    </div>
  );
});

const nodeTypes = { step: StepNode, section: SectionNode };

// ---------- main ----------
export function WorkflowView(props: {
  department: { id: number; name: string }; sections: WfSection[]; connections: WfConnection[];
  roles: string[]; tools: string[]; allTools: string[]; canEdit: boolean;
}) {
  return <ReactFlowProvider><Workflow {...props} /></ReactFlowProvider>;
}

function Workflow({ department, sections, connections, roles, tools, allTools, canEdit }: Parameters<typeof WorkflowView>[0]) {
  const router = useRouter();
  const rf = useReactFlow();
  const [role, setRole] = useState("all");
  const [panelOpen, setPanelOpen] = useState(true);
  const [dialog, setDialog] = useState<{ step: Partial<WfStep> } | null>(null);

  const openAdd = useCallback((playbookId: number) => setDialog({ step: { playbookId, kind: "person" } }), []);
  const built = useMemo(() => {
    const pos = layout(sections);
    const nodes: Node[] = [];
    for (const s of sections) {
      const { w, h } = sectionSize(s);
      nodes.push({ id: `pb-${s.id}`, type: "section", position: pos.get(s.id)!, data: { section: s, canEdit, onAdd: openAdd },
        style: { width: w, height: h }, draggable: canEdit, selectable: false, zIndex: 0 });
      for (const st of s.steps)
        nodes.push({ id: `s-${st.id}`, type: "step", parentId: `pb-${s.id}`, position: { x: st.x, y: Math.max(st.y, HEAD) },
          data: { step: st, dim: role !== "all" && st.role !== role }, draggable: canEdit, zIndex: 1 });
    }
    const edges: Edge[] = connections.map((c) => ({
      id: `c-${c.id}`, source: `s-${c.fromId}`, target: `s-${c.toId}`, type: "smoothstep", label: c.label || undefined,
      markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 }, style: { strokeWidth: 1.5 },
    }));
    return { nodes, edges };
  }, [sections, connections, canEdit, openAdd, role]);

  const [nodes, setNodes, onNodesChange] = useNodesState(built.nodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(built.edges);
  useEffect(() => { setNodes(built.nodes); setEdges(built.edges); }, [built, setNodes, setEdges]);

  const steps = sections.flatMap((s) => s.steps);
  const counts = STEP_KINDS.map((k) => ({ k, n: steps.filter((s) => s.kind === k).length }));

  const onNodeDragStop = useCallback(async (_: unknown, node: Node) => {
    const [type, id] = node.id.split("-");
    const r = type === "s" ? await moveStep(Number(id), node.position.x, node.position.y) : await moveSection(Number(id), node.position.x, node.position.y);
    if (!r.ok) toast.error(r.error);
    router.refresh();
  }, [router]);

  const onConnect = useCallback(async (c: Connection) => {
    if (!c.source || !c.target) return;
    const r = await connectSteps(Number(c.source.slice(2)), Number(c.target.slice(2)));
    if (!r.ok) toast.error(r.error);
    router.refresh();
  }, [router]);

  const onBeforeDelete = useCallback(async ({ edges: es }: { nodes: Node[]; edges: Edge[] }) => {
    if (!es.length || !confirm(`Remove ${es.length === 1 ? "this connection" : `${es.length} connections`}?`)) return false;
    for (const e of es) await deleteConnection(Number(e.id.slice(2)));
    router.refresh();
    return { nodes: [], edges: es };
  }, [router]);

  const focus = (id: number) => rf.fitView({ nodes: [{ id: `pb-${id}` }], duration: 500, padding: 0.15 });

  return (
    <div className="relative flex h-full min-h-0">
      <div className="relative min-w-0 flex-1">
        <ReactFlow
          nodes={nodes} edges={edges} nodeTypes={nodeTypes}
          onNodesChange={onNodesChange} onEdgesChange={onEdgesChange}
          onNodeDragStop={canEdit ? onNodeDragStop : undefined}
          onConnect={canEdit ? onConnect : undefined}
          onBeforeDelete={canEdit ? onBeforeDelete : async () => false}
          onNodeClick={(_, n) => { if (n.type === "step") setDialog({ step: (n.data as StepData).step }); }}
          nodesConnectable={canEdit} deleteKeyCode={canEdit ? ["Backspace", "Delete"] : null}
          fitView fitViewOptions={{ padding: 0.12 }} minZoom={0.15} maxZoom={2} colorMode="system" proOptions={{ hideAttribution: true }}
        >
          <Background variant={BackgroundVariant.Dots} gap={18} size={1} />
          <Controls position="bottom-left" showInteractive={false} />
        </ReactFlow>

        <div className="absolute top-4 left-16 z-10 flex items-center gap-2 rounded-xl border bg-card/95 px-3 py-2 shadow-sm backdrop-blur">
          <span className="text-sm font-bold">View as</span>
          <Select value={role} onValueChange={setRole}>
            <SelectTrigger className="h-8 w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Everyone</SelectItem>
              {roles.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="absolute bottom-4 left-16 z-10 rounded-lg border bg-card/95 px-3 py-1.5 text-sm shadow-sm">
          <Link href="/workflows" className="text-muted-foreground hover:underline">Workflows</Link>
          <span className="mx-2 text-muted-foreground">/</span><span className="font-semibold">{department.name}</span>
        </div>
        <Button variant="outline" size="icon" className="absolute top-4 right-4 z-10 bg-card" onClick={() => setPanelOpen((o) => !o)} aria-label={panelOpen ? "Hide panel" : "Show panel"}>
          {panelOpen ? <PanelRightClose /> : <PanelRightOpen />}
        </Button>
      </div>

      {panelOpen && (
        <aside className="hidden w-[340px] shrink-0 overflow-y-auto border-l bg-card p-6 lg:block">
          <h2 className="text-2xl font-extrabold tracking-tight">{department.name}</h2>
          <div className="mt-5 grid grid-cols-3 gap-2">
            {[[sections.length, "Sections"], [steps.length, "Steps"], [connections.length, "Connections"]].map(([n, l]) => (
              <div key={l} className="rounded-xl border bg-background px-2 py-3 text-center">
                <div className="num text-2xl font-extrabold">{n}</div><div className="text-xs text-muted-foreground">{l}</div>
              </div>
            ))}
          </div>
          {steps.length === 0 && (
            <p className="mt-5 rounded-xl border border-dashed p-4 text-sm text-muted-foreground">
              No steps yet. They appear after the first sync with Jarvis on the server: every scheduled job and every SKILL.md with a Steps list becomes boxes here.
            </p>
          )}
          <Summary counts={counts} total={steps.length} />
          <div className="mt-6 grid gap-2">
            {sections.map((s) => (
              <button key={s.id} type="button" onClick={() => focus(s.id)}
                className="flex items-center justify-between gap-2 rounded-xl border bg-background px-4 py-3 text-left text-sm font-semibold hover:border-foreground/30">
                <span className="truncate">{s.name}</span><span className="num shrink-0 text-xs font-medium text-muted-foreground">{s.steps.length} steps</span>
              </button>
            ))}
          </div>
          {tools.length > 0 && (
            <div className="mt-6">
              <p className="mb-2 text-sm font-semibold">Tools in this workflow</p>
              <div className="flex flex-wrap gap-1.5">{tools.map((t) => <Badge key={t}>{t}</Badge>)}</div>
            </div>
          )}
        </aside>
      )}

      {dialog && (
        <StepDialog step={dialog.step} sections={sections} roles={roles} tools={allTools} canEdit={canEdit}
          onClose={() => setDialog(null)} onSaved={() => { setDialog(null); router.refresh(); }} />
      )}
    </div>
  );
}

function Summary({ counts, total }: { counts: { k: StepKind; n: number }[]; total: number }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="mt-5 rounded-xl border bg-background">
      <button type="button" className="flex w-full items-center justify-between px-4 py-3 font-semibold" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        Summary {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
      </button>
      {open && (
        <div className="grid gap-3 px-4 pb-4">
          <p className="text-sm text-muted-foreground">Who does the work</p>
          <div className="flex h-3 overflow-hidden rounded-full bg-muted">
            {total > 0 && counts.map(({ k, n }) => n > 0 && <span key={k} className={KIND_BAR[k]} style={{ width: `${(n / total) * 100}%` }} title={`${STEP_KIND_LABEL[k]}: ${n}`} />)}
          </div>
          <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-sm">
            {counts.map(({ k, n }) => (
              <span key={k} className="inline-flex items-center gap-2"><span className={cn("size-3 rounded-[3px]", KIND_BAR[k])} />{STEP_KIND_LABEL[k]} <span className="num text-muted-foreground">{n}</span></span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StepDialog({ step, sections, roles, tools, canEdit: canEditAll, onClose, onSaved }: {
  step: Partial<WfStep>; sections: WfSection[]; roles: string[]; tools: string[]; canEdit: boolean; onClose: () => void; onSaved: () => void;
}) {
  const isNew = !step.id;
  const synced = !!step.source && step.source !== "manual";
  const canEdit = canEditAll && !synced;
  const [v, setV] = useState({ title: step.title ?? "", kind: step.kind ?? "person", role: step.role ?? "", tool: step.tool ?? "", note: step.note ?? "", playbookId: step.playbookId ?? sections[0]?.id });
  const [error, setError] = useState("");
  const [pending, start] = useTransition();
  const set = (k: keyof typeof v, x: string | number) => setV((s) => ({ ...s, [k]: x }));

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    start(async () => {
      const r = await saveStep({ id: step.id, playbookId: Number(v.playbookId), title: v.title, kind: v.kind as StepKind, role: v.role, tool: v.tool, note: v.note });
      if (!r.ok) return setError(r.error ?? "Couldn't save.");
      toast.success(isNew ? "Added step" : "Saved changes");
      onSaved();
    });
  };
  const remove = () => {
    if (!step.id || !confirm("Delete this step and its connections?")) return;
    start(async () => {
      const r = await deleteStep(step.id!);
      if (!r.ok) return setError(r.error ?? "Couldn't delete.");
      toast.success("Deleted step");
      onSaved();
    });
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <form onSubmit={save} className="grid gap-4">
          <DialogHeader>
            <DialogTitle>{isNew ? "Add step" : canEdit ? "Edit step" : step.title}</DialogTitle>
            <DialogDescription>{synced
              ? step.source === "skill" ? "This step comes from the playbook's SKILL.md in Drive. Change it there; the canvas updates on the next sync." : "This step comes from Jarvis's real scheduled job. Change the job on the server; the canvas updates on the next sync."
              : "A step is one action in this workflow and who or what does it."}</DialogDescription>
          </DialogHeader>
          <fieldset disabled={!canEdit} className="grid gap-4">
            <div className="grid gap-2"><Label htmlFor="st-title">What happens</Label><Input id="st-title" required value={v.title} onChange={(e) => set("title", e.target.value)} /></div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-2">
                <Label htmlFor="st-kind">Done by</Label>
                <Select value={v.kind} onValueChange={(x) => set("kind", x)}>
                  <SelectTrigger id="st-kind"><SelectValue /></SelectTrigger>
                  <SelectContent>{STEP_KINDS.map((k) => <SelectItem key={k} value={k}>{STEP_KIND_LABEL[k]}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="st-section">Section</Label>
                <Select value={String(v.playbookId)} onValueChange={(x) => set("playbookId", Number(x))}>
                  <SelectTrigger id="st-section"><SelectValue /></SelectTrigger>
                  <SelectContent>{sections.map((s) => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid gap-2"><Label htmlFor="st-role">Who (person or agent)</Label><Input id="st-role" list="wf-roles" value={v.role} onChange={(e) => set("role", e.target.value)} /></div>
              <div className="grid gap-2"><Label htmlFor="st-tool">Tool</Label><Input id="st-tool" list="wf-tools" value={v.tool} onChange={(e) => set("tool", e.target.value)} /></div>
            </div>
            <div className="grid gap-2"><Label htmlFor="st-note">Notes</Label><Textarea id="st-note" value={v.note} onChange={(e) => set("note", e.target.value)} /></div>
          </fieldset>
          <datalist id="wf-roles">{roles.map((r) => <option key={r} value={r} />)}</datalist>
          <datalist id="wf-tools">{tools.map((t) => <option key={t} value={t} />)}</datalist>
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          {canEdit ? (
            <DialogFooter className="sm:justify-between">
              {!isNew ? <Button type="button" variant="ghost" className="text-destructive" onClick={remove} disabled={pending}>Delete step</Button> : <span />}
              <div className="flex gap-2"><Button type="button" variant="outline" onClick={onClose}>Cancel</Button><Button type="submit" disabled={pending}>{isNew ? "Add step" : "Save changes"}</Button></div>
            </DialogFooter>
          ) : <DialogFooter><Button type="button" onClick={onClose}>Close</Button></DialogFooter>}
        </form>
      </DialogContent>
    </Dialog>
  );
}
