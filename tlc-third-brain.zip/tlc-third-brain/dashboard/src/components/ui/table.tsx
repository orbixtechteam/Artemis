import * as React from "react";
import { cn } from "@/lib/utils";

function Table({ className, ...props }: React.ComponentProps<"table">) {
  return (
    <div className="relative w-full overflow-x-auto rounded-xl border bg-card">
      <table data-slot="table" className={cn("w-full caption-bottom text-sm", className)} {...props} />
    </div>
  );
}
const TableHeader = ({ className, ...p }: React.ComponentProps<"thead">) => <thead className={cn("[&_tr]:border-b", className)} {...p} />;
const TableBody = ({ className, ...p }: React.ComponentProps<"tbody">) => <tbody className={cn("[&_tr:last-child]:border-0", className)} {...p} />;
const TableRow = ({ className, ...p }: React.ComponentProps<"tr">) => <tr className={cn("border-b transition-colors data-[clickable=true]:cursor-pointer data-[clickable=true]:hover:bg-muted/60", className)} {...p} />;
const TableHead = ({ className, ...p }: React.ComponentProps<"th">) => <th className={cn("h-10 px-4 text-left align-middle text-xs font-semibold whitespace-nowrap text-muted-foreground", className)} {...p} />;
const TableCell = ({ className, ...p }: React.ComponentProps<"td">) => <td className={cn("px-4 py-3 align-top", className)} {...p} />;
export { Table, TableHeader, TableBody, TableRow, TableHead, TableCell };
