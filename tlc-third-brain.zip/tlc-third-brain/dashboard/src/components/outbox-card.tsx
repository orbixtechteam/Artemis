"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Mail, MessageSquare } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { approveOutbox, rejectOutbox } from "@/lib/actions";
import { ago } from "@/lib/utils";

type M = { id: number; channel: string; toAddr: string; cc: string; subject: string; body: string; slackChannel: string; slackThreadTs: string; playbook: string; requestedBy: string; reason: string; createdAt: Date };

export function OutboxCard({ m }: { m: M }) {
  const router = useRouter();
  const [v, setV] = useState({ toAddr: m.toAddr, cc: m.cc, subject: m.subject, body: m.body });
  const [why, setWhy] = useState("");
  const [sendAs, setSendAs] = useState<"bot" | "me">("bot");
  const [rejecting, setRejecting] = useState(false);
  const [pending, start] = useTransition();
  const email = m.channel === "gmail";
  return (
    <Card className="grid gap-4 p-5">
      <div className="flex flex-wrap items-center gap-2 text-sm">
        {email ? <Mail className="size-4 text-primary" /> : <MessageSquare className="size-4 text-primary" />}
        <strong>{email ? "Email" : `Slack message in ${m.slackChannel}${m.slackThreadTs ? " (thread reply)" : ""}`}</strong>
        <span className="text-muted-foreground">· from {m.requestedBy}{m.playbook ? ` · ${m.playbook}` : ""} · {ago(m.createdAt)}</span>
      </div>
      {m.reason && <p className="text-sm text-muted-foreground">Why: {m.reason}</p>}
      {email && (
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="grid gap-1.5"><Label htmlFor={`to-${m.id}`}>To</Label><Input id={`to-${m.id}`} value={v.toAddr} onChange={(e) => setV({ ...v, toAddr: e.target.value })} /></div>
          <div className="grid gap-1.5"><Label htmlFor={`cc-${m.id}`}>Cc</Label><Input id={`cc-${m.id}`} value={v.cc} onChange={(e) => setV({ ...v, cc: e.target.value })} /></div>
          <div className="grid gap-1.5 sm:col-span-2"><Label htmlFor={`su-${m.id}`}>Subject</Label><Input id={`su-${m.id}`} value={v.subject} onChange={(e) => setV({ ...v, subject: e.target.value })} /></div>
        </div>
      )}
      <div className="grid gap-1.5"><Label htmlFor={`b-${m.id}`}>Message</Label><Textarea id={`b-${m.id}`} className="min-h-40" value={v.body} onChange={(e) => setV({ ...v, body: e.target.value })} /></div>
      {!email && (
        <label className="flex items-center gap-2 text-sm">
          <span className="text-muted-foreground">Send as</span>
          <select value={sendAs} onChange={(e) => setSendAs(e.target.value as "bot" | "me")} className="h-8 rounded-md border bg-transparent px-2">
            <option value="bot">The clinic&apos;s Slack bot</option>
            <option value="me">Me (my own Slack)</option>
          </select>
        </label>
      )}
      {rejecting && (
        <div className="grid gap-1.5"><Label htmlFor={`r-${m.id}`}>What's wrong? (becomes a lesson for the playbook)</Label><Input id={`r-${m.id}`} value={why} onChange={(e) => setWhy(e.target.value)} placeholder="e.g. too formal for this client" autoFocus /></div>
      )}
      <div className="flex flex-wrap justify-end gap-2">
        {rejecting ? (
          <>
            <Button variant="outline" onClick={() => setRejecting(false)} disabled={pending}>Cancel</Button>
            <Button variant="destructive" disabled={pending} onClick={() => start(async () => {
              const r = await rejectOutbox(m.id, why);
              if (r.ok) toast.success("Rejected"); else toast.error(r.error);
              router.refresh();
            })}>Reject</Button>
          </>
        ) : (
          <>
            <Button variant="outline" onClick={() => setRejecting(true)} disabled={pending}>Reject</Button>
            <Button disabled={pending} onClick={() => {
              if (!confirm(email ? `Send this email to ${v.toAddr}?` : `Post this in ${m.slackChannel}?`)) return;
              start(async () => {
                const r = await approveOutbox(m.id, { ...v, ...(email ? {} : { sendAs }) });
                if (r.ok) toast.success(email ? "Email sent" : "Posted in Slack"); else toast.error(r.error);
                router.refresh();
              });
            }}>{pending ? "Sending" : email ? "Approve and send" : "Approve and post"}</Button>
          </>
        )}
      </div>
    </Card>
  );
}
