"use client";

import "@xyflow/react/dist/style.css";
import { useRouter } from "next/navigation";
import { Background, BackgroundVariant, Controls, Handle, MarkerType, Position, ReactFlow, type Edge, type Node, type NodeProps } from "@xyflow/react";
import { StatusBadge } from "@/components/status";
import { cn } from "@/lib/utils";

type N = { id: number; name: string; status: string; autonomy: string; trigger: string; department: string };
type L = { id: number; from: number; to: number; label: string };

function Card({ data }: NodeProps<Node<N>>) {
  return (
    <div className="w-60 overflow-hidden rounded-xl border bg-card shadow-sm">
      <Handle type="target" position={Position.Left} className="!size-2 !bg-muted-foreground" />
      <div className={cn("h-1", data.autonomy === "green" ? "bg-signal-green" : data.autonomy === "red" ? "bg-signal-red" : "bg-signal-amber")} />
      <div className="grid gap-1.5 p-3">
        <span className="flex items-start justify-between gap-2"><span className="text-sm leading-tight font-bold">{data.name}</span><StatusBadge status={data.status} /></span>
        <span className="text-xs text-muted-foreground">{data.department}</span>
        {data.trigger && <span className="line-clamp-2 text-xs text-muted-foreground">Starts: {data.trigger}</span>}
      </div>
      <Handle type="source" position={Position.Right} className="!size-2 !bg-muted-foreground" />
    </div>
  );
}

export function ChainsView({ nodes, links }: { nodes: N[]; links: L[] }) {
  const router = useRouter();
  // Layers by longest path from the starting playbooks (guarded against cycles).
  const depth = new Map<number, number>(nodes.map((n) => [n.id, 0]));
  for (let pass = 0; pass < nodes.length; pass++)
    for (const l of links) depth.set(l.to, Math.max(depth.get(l.to) ?? 0, Math.min((depth.get(l.from) ?? 0) + 1, nodes.length)));
  const rows = new Map<number, number>();
  const flowNodes: Node[] = nodes.map((n) => {
    const d = depth.get(n.id) ?? 0;
    const r = rows.get(d) ?? 0;
    rows.set(d, r + 1);
    return { id: String(n.id), type: "card", position: { x: d * 330, y: r * 150 }, data: n };
  });
  const edges: Edge[] = links.map((l) => ({
    id: `l${l.id}`, source: String(l.from), target: String(l.to), label: l.label || undefined, type: "smoothstep",
    markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 }, style: { strokeWidth: 1.5 },
    labelStyle: { fontSize: 11 }, labelBgPadding: [6, 3], labelBgBorderRadius: 6,
  }));
  return (
    <div className="min-h-[420px] overflow-hidden rounded-xl border">
      <ReactFlow nodes={flowNodes} edges={edges} nodeTypes={{ card: Card }} nodesDraggable={false} nodesConnectable={false} fitView fitViewOptions={{ padding: 0.2 }}
        colorMode="system" proOptions={{ hideAttribution: true }} onNodeClick={(_, n) => router.push(`/playbooks/${n.id}`)}>
        <Background variant={BackgroundVariant.Dots} gap={18} size={1} />
        <Controls position="bottom-left" showInteractive={false} />
      </ReactFlow>
    </div>
  );
}
