"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Play, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { refreshStatusAction, runJobAction } from "@/lib/actions";

export function CheckNowButton() {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <Button variant="outline" disabled={pending} onClick={() => start(async () => {
      const r = await refreshStatusAction();
      if (r.ok) toast.success("Checked everything"); else toast.error(r.error);
      router.refresh();
    })}>
      <RefreshCw className={pending ? "animate-spin" : ""} /> {pending ? "Testing connectors one by one" : "Check now"}
    </Button>
  );
}

export function RunJobButton({ job }: { job: string }) {
  const [pending, start] = useTransition();
  return (
    <Button variant="ghost" size="sm" disabled={pending} onClick={() => start(async () => {
      const r = await runJobAction(job);
      if (r.ok) toast.success(`Started ${job}`); else toast.error(r.error);
    })}>
      <Play /> Run now
    </Button>
  );
}
