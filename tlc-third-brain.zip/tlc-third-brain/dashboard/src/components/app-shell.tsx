"use client";

import { useState } from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { BookOpen, ChevronsRight, GitBranch, Inbox, LayoutDashboard, LineChart, Menu, Settings, Sparkles } from "lucide-react";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function AppShell({ user, departments, tools, admin, pendingApprovals = 0, children }: {
  user: { name: string; role: string }; departments: { id: number; name: string; statuses: string[] }[];
  tools: { name: string; count: number }[]; admin: boolean; pendingApprovals?: number; children: React.ReactNode;
}) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const path = usePathname();
  const canvas = path.startsWith("/workflows") || path.startsWith("/chat");

  return (
    <div className={cn("min-h-dvh md:grid", collapsed ? "md:grid-cols-[64px_1fr]" : "md:grid-cols-[280px_1fr]")}>
      <aside className={cn(
        "fixed inset-y-0 left-0 z-40 w-[290px] -translate-x-full overflow-hidden border-r bg-sidebar transition-transform md:sticky md:top-0 md:h-dvh md:w-auto md:translate-x-0",
        mobileOpen && "translate-x-0 shadow-xl", collapsed && "md:w-16")}>
        {collapsed ? (
          <nav className="hidden h-full flex-col items-center gap-1.5 py-4 md:flex" aria-label="Main (collapsed)">
            <Rail onClick={() => setCollapsed(false)} label="Show sidebar"><ChevronsRight /></Rail>
            <span className="my-1 h-px w-8 bg-border" />
            <Rail href="/chat" label="Ask the brain" active={path.startsWith("/chat")}><Sparkles className="text-primary" /></Rail>
            <Rail href="/" label="Overview" active={path === "/"}><LayoutDashboard /></Rail>
            <Rail href={departments[0] ? `/workflows/${departments[0].id}` : "/workflows"} label="Workflows" active={path.startsWith("/workflows")}><GitBranch /></Rail>
            <Rail href="/playbooks" label="Library" active={path.startsWith("/playbooks")}><BookOpen /></Rail>
            <Rail href="/insights" label="Insights" active={path.startsWith("/insights")}><LineChart /></Rail>
            <Rail href="/approvals" label="Approvals" active={path.startsWith("/approvals")}>
              <Inbox />{pendingApprovals > 0 && <span className="num absolute -top-1 -right-1 rounded-full bg-signal-amber px-1 text-[10px] font-bold text-white">{pendingApprovals}</span>}
            </Rail>
            <span className="flex-1" />
            <Rail href="/settings" label="Settings" active={path.startsWith("/settings")}><Settings /></Rail>
          </nav>
        ) : (
          <Sidebar user={user} departments={departments} tools={tools} admin={admin} pendingApprovals={pendingApprovals}
            onNavigate={() => setMobileOpen(false)} onCollapse={() => setCollapsed(true)} />
        )}
      </aside>
      {mobileOpen && <div className="fixed inset-0 z-30 bg-black/30 md:hidden" onClick={() => setMobileOpen(false)} aria-hidden />}

      <div className="relative min-w-0">
        <Button variant="outline" size="icon" className="fixed top-3 left-3 z-20 bg-card md:hidden" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu /></Button>
        {canvas ? children : <main className="mx-auto w-full max-w-[1400px] px-4 pt-16 pb-24 md:px-8 md:pt-8">{children}</main>}
      </div>
      {!path.startsWith("/chat") && (
        <Button asChild className="fixed right-5 bottom-5 z-40 h-11 rounded-full px-5 shadow-lg">
          <Link href="/chat"><Sparkles /> Ask the brain</Link>
        </Button>
      )}
    </div>
  );
}

function Rail({ href, label, active, onClick, children }: { href?: string; label: string; active?: boolean; onClick?: () => void; children: React.ReactNode }) {
  const cls = cn("relative grid size-10 place-items-center rounded-xl text-muted-foreground hover:bg-muted hover:text-foreground [&_svg]:size-[18px]", active && "bg-accent text-accent-foreground");
  return href
    ? <Link href={href} className={cls} title={label} aria-label={label} aria-current={active ? "page" : undefined}>{children}</Link>
    : <button type="button" onClick={onClick} className={cls} title={label} aria-label={label}>{children}</button>;
}
