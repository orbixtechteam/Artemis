"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { AutonomyDot, RunBadge, StatusBadge } from "@/components/status";
import { EntityDialog, type Ref } from "@/components/entity-dialog";
import type { EntityKey } from "@/lib/fields";
import { ago } from "@/lib/utils";

type Row = Record<string, any> & { id: number }; // eslint-disable-line @typescript-eslint/no-explicit-any
type Col = { label: string; cell: (r: Row, x: Lookups) => React.ReactNode; wrap?: boolean };
type Filter = { key: string; label: string; options: (x: Lookups, rows: Row[]) => { value: string; label: string }[] };
type Lookups = { dept: (id?: number | null) => string; pb: (id?: number | null) => string; departments: Ref[]; playbooks: Ref[] };

const ext = (u?: string) => (/^https?:\/\//i.test(u ?? "") ? <a href={u} target="_blank" rel="noopener" className="text-primary hover:underline" onClick={(e) => e.stopPropagation()}>Open</a> : <span className="text-muted-foreground">No link</span>);
const deptFilter: Filter = { key: "departmentId", label: "Department", options: (x) => x.departments.map((d) => ({ value: String(d.id), label: d.name })) };
const list = (xs: string[]) => () => xs.map((v) => ({ value: v, label: v }));

const CONFIG: Record<EntityKey | "runs", { cols: Col[]; filters: Filter[] }> = {
  playbooks: {
    filters: [deptFilter, { key: "status", label: "Status", options: list(["idea", "draft", "testing", "live", "paused"]) }, { key: "autonomy", label: "Autonomy", options: list(["green", "amber", "red"]) }],
    cols: [
      { label: "Playbook", wrap: true, cell: (r) => <div className="flex gap-3"><AutonomyDot level={r.autonomy} className="mt-1.5" /><div><div className="font-semibold">{r.name}</div><div className="text-xs text-muted-foreground">{r.trigger}</div></div></div> },
      { label: "Department", cell: (r, x) => x.dept(r.departmentId) },
      { label: "Owner", cell: (r) => r.owner },
      { label: "Status", cell: (r) => <StatusBadge status={r.status} /> },
      { label: "Tests", cell: (r) => (r.testsTotal ? <span className="num">{r.testsPassed}/{r.testsTotal}</span> : <span className="text-muted-foreground">none</span>) },
      { label: "Last run", cell: (r) => <span className="num">{ago(r.lastRunAt)}</span> },
    ],
  },
  rules: {
    filters: [deptFilter, { key: "status", label: "Status", options: list(["active", "candidate", "rejected", "superseded"]) }, { key: "kind", label: "Kind", options: list(["policy", "fact", "style", "preference"]) }],
    cols: [
      { label: "Rule", wrap: true, cell: (r) => r.text },
      { label: "Status", cell: (r) => <StatusBadge status={r.status} /> },
      { label: "Kind", cell: (r) => r.kind },
      { label: "Playbook", cell: (r, x) => x.pb(r.playbookId) || <span className="text-muted-foreground">All</span> },
      { label: "Source", wrap: true, cell: (r) => r.source },
      { label: "Date", cell: (r) => <span className="num">{r.ruleDate}</span> },
    ],
  },
  lessons: {
    filters: [deptFilter, { key: "playbookId", label: "Playbook", options: (x) => x.playbooks.map((p) => ({ value: String(p.id), label: p.name })) }],
    cols: [
      { label: "Date", cell: (r) => <span className="num">{r.lessonDate}</span> },
      { label: "What went wrong", wrap: true, cell: (r) => <><div className="font-semibold">{r.what}</div>{r.reason && <div className="text-xs text-muted-foreground">{r.reason}</div>}</> },
      { label: "Fix", wrap: true, cell: (r) => r.fix },
      { label: "Playbook", cell: (r, x) => x.pb(r.playbookId) },
    ],
  },
  knowledge: {
    filters: [deptFilter, { key: "kind", label: "Kind", options: list(["folder", "doc", "sheet", "file", "system", "other"]) }],
    cols: [
      { label: "Name", wrap: true, cell: (r) => <><div className="font-semibold">{r.name}</div><div className="text-xs text-muted-foreground">{r.description}</div></> },
      { label: "Department", cell: (r, x) => x.dept(r.departmentId) },
      { label: "Kind", cell: (r) => <div className="flex gap-1.5"><Badge>{r.kind}</Badge>{r.patientData && <Badge tone="red">patient data</Badge>}</div> },
      { label: "Owner", cell: (r) => r.owner },
      { label: "Reviewed", cell: (r) => <span className="num">{r.reviewedAt ?? "never"}</span> },
      { label: "Link", cell: (r) => ext(r.link) },
    ],
  },
  automations: {
    filters: [{ key: "kind", label: "Kind", options: list(["schedule", "event", "command"]) }],
    cols: [
      { label: "Automation", wrap: true, cell: (r) => <><div className="font-semibold">{r.name} {!r.enabled && <Badge>off</Badge>}</div><div className="text-xs text-muted-foreground">{r.delivery}</div></> },
      { label: "When", cell: (r) => r.schedule },
      { label: "Playbook", cell: (r, x) => x.pb(r.playbookId) || <span className="text-muted-foreground">Not linked</span> },
      { label: "Last run", cell: (r) => <span className="num">{ago(r.lastRunAt)}</span> },
      { label: "Status", wrap: true, cell: (r) => <><RunBadge status={r.lastStatus} />{r.lastError && <div className="mt-1 text-xs text-muted-foreground">{String(r.lastError).slice(0, 140)}</div>}</> },
    ],
  },
  departments: { filters: [], cols: [] },
  runs: {
    filters: [
      { key: "job", label: "Job", options: (_x, rows) => [...new Set(rows.map((r) => r.job as string))].sort().map((v) => ({ value: v, label: v })) },
      { key: "status", label: "Status", options: (_x, rows) => [...new Set(rows.map((r) => r.status as string))].map((v) => ({ value: v, label: v })) },
    ],
    cols: [
      { label: "When (UTC)", cell: (r) => <span className="num">{new Date(r.runAt).toISOString().slice(0, 16).replace("T", " ")}</span> },
      { label: "Job", cell: (r) => r.job },
      { label: "Status", cell: (r) => <RunBadge status={r.status} /> },
      { label: "Took", cell: (r) => <span className="num">{r.durationS != null ? `${r.durationS} s` : ""}</span> },
      { label: "Delivery", cell: (r) => r.delivery },
    ],
  },
};

const ALL = "__all__";

export function EntityTable({ entity, rows, departments, playbooks, canEdit, canDelete }: {
  entity: EntityKey | "runs"; rows: Row[]; departments: Ref[]; playbooks: Ref[]; canEdit: boolean; canDelete: boolean;
}) {
  const cfg = CONFIG[entity];
  const router = useRouter();
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<Record<string, string>>({});
  const [editing, setEditing] = useState<Row | null>(null);
  const x: Lookups = useMemo(() => ({
    departments, playbooks,
    dept: (id) => departments.find((d) => d.id === id)?.name ?? "No department",
    pb: (id) => playbooks.find((p) => p.id === id)?.name ?? "",
  }), [departments, playbooks]);

  const shown = rows.filter((r) => (!q || JSON.stringify(r).toLowerCase().includes(q.toLowerCase()))
    && Object.entries(sel).every(([k, v]) => !v || v === ALL || String(r[k]) === v));

  const open = (r: Row) => {
    if (entity === "playbooks") router.push(`/playbooks/${r.id}`);
    else if (entity !== "runs" && canEdit) setEditing(r);
  };

  return (
    <div className="grid gap-3">
      <div className="flex flex-wrap gap-2">
        <Input className="w-64" type="search" placeholder="Filter" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Filter" />
        {cfg.filters.map((f) => (
          <Select key={f.key} value={sel[f.key] ?? ALL} onValueChange={(v) => setSel((s) => ({ ...s, [f.key]: v }))}>
            <SelectTrigger className="w-48" aria-label={f.label}><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL}>{f.label}: all</SelectItem>
              {f.options(x, rows).map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
            </SelectContent>
          </Select>
        ))}
      </div>
      <Table>
        <TableHeader><TableRow>{cfg.cols.map((c) => <TableHead key={c.label}>{c.label}</TableHead>)}</TableRow></TableHeader>
        <TableBody>
          {shown.length ? shown.map((r) => (
            <TableRow key={r.id} data-clickable={entity === "playbooks" || (entity !== "runs" && canEdit)} onClick={() => open(r)}>
              {cfg.cols.map((c) => <TableCell key={c.label} className={c.wrap ? "max-w-[52ch]" : "whitespace-nowrap"}>{c.cell(r, x)}</TableCell>)}
            </TableRow>
          )) : (
            <TableRow><TableCell colSpan={cfg.cols.length} className="py-8 text-center text-muted-foreground">Nothing matches. Clear the filters.</TableCell></TableRow>
          )}
        </TableBody>
      </Table>
      {entity !== "runs" && entity !== "playbooks" && (
        <EntityDialog entity={entity} row={editing} open={!!editing} onOpenChange={(o) => !o && setEditing(null)}
          departments={departments} playbooks={playbooks} canDelete={canDelete} />
      )}
    </div>
  );
}
