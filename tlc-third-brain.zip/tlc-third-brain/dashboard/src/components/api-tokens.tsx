"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Copy } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { createApiToken, revokeApiToken, revokeOAuthClient } from "@/lib/actions";
import { ago } from "@/lib/utils";

export type TokenRow = { id: number; name: string; owner: string; createdAt: Date; lastUsed: Date | null };

export type AppRow = { clientId: string; name: string; owner: string; lastUsed: Date | null };

export function ApiTokens({ tokens, apps, appUrl }: { tokens: TokenRow[]; apps: AppRow[]; appUrl: string }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [created, setCreated] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const url = created ? `${appUrl}/api/mcp/${created}` : "";
  const copy = (t: string) => navigator.clipboard.writeText(t).then(() => toast.success("Copied"));

  return (
    <section className="mt-8 grid gap-3">
      <div>
        <h2 className="text-lg font-bold">Connect Claude (MCP)</h2>
        <p className="max-w-[75ch] text-sm text-muted-foreground">
          In Claude: Settings → Connectors → Add custom connector → <code className="rounded bg-muted px-1.5 py-0.5">{appUrl}/api/mcp</code> → Connect. You sign in here and allow it; Claude then works with your permissions.
          For tools without sign-in support, create a personal token link below instead.
        </p>
      </div>
      {apps.length > 0 && (
        <Table>
          <TableHeader><TableRow><TableHead>Connected app</TableHead><TableHead>Person</TableHead><TableHead>Last used</TableHead><TableHead /></TableRow></TableHeader>
          <TableBody>
            {apps.map((a) => (
              <TableRow key={a.clientId + a.owner}>
                <TableCell className="font-semibold">{a.name}</TableCell>
                <TableCell>{a.owner}</TableCell>
                <TableCell className="num">{ago(a.lastUsed)}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" className="text-destructive" onClick={() => {
                    if (!confirm(`Disconnect ${a.name}? It loses access straight away.`)) return;
                    start(async () => { const r = await revokeOAuthClient(a.clientId); if (r.ok) { toast.success("Disconnected"); router.refresh(); } else toast.error(r.error); });
                  }}>Disconnect</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
      <div>
      </div>
      <form className="flex flex-wrap gap-2" onSubmit={(e) => {
        e.preventDefault();
        start(async () => {
          const r = await createApiToken(name);
          if (!r.ok || !r.token) { toast.error(r.error ?? "Couldn't create the token."); return; }
          setCreated(r.token); setName(""); router.refresh();
        });
      }}>
        <Input className="w-64" placeholder="Name, e.g. Noah's Claude" value={name} onChange={(e) => setName(e.target.value)} aria-label="Token name" />
        <Button type="submit" disabled={pending}>Create token</Button>
      </form>
      {tokens.length > 0 && (
        <Table>
          <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Person</TableHead><TableHead>Created</TableHead><TableHead>Last used</TableHead><TableHead /></TableRow></TableHeader>
          <TableBody>
            {tokens.map((t) => (
              <TableRow key={t.id}>
                <TableCell className="font-semibold">{t.name}</TableCell>
                <TableCell>{t.owner}</TableCell>
                <TableCell className="num">{ago(t.createdAt)}</TableCell>
                <TableCell className="num">{ago(t.lastUsed)}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" className="text-destructive" onClick={() => {
                    if (!confirm(`Revoke "${t.name}"? Claude loses access straight away.`)) return;
                    start(async () => { const r = await revokeApiToken(t.id); if (r.ok) { toast.success("Revoked"); router.refresh(); } else toast.error(r.error); });
                  }}>Revoke</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
      <Dialog open={!!created} onOpenChange={(o) => !o && setCreated(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Your MCP link</DialogTitle>
            <DialogDescription>Shown only once. Paste it into Claude as a custom connector. Anyone with this link acts as you.</DialogDescription>
          </DialogHeader>
          <div className="flex items-center gap-2 rounded-md bg-muted px-3 py-2.5">
            <code className="min-w-0 flex-1 break-all text-sm select-all">{url}</code>
            <Button variant="ghost" size="icon" onClick={() => copy(url)} aria-label="Copy link"><Copy /></Button>
          </div>
          <p className="text-sm text-muted-foreground">Behind Cloudflare Access, add a bypass rule for the path <code>/api/mcp/*</code>, otherwise Claude can&apos;t reach it.</p>
          <DialogFooter><Button onClick={() => setCreated(null)}>Done</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
}
