"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  BookOpen, ChevronDown, ChevronsLeft, GitBranch, LogOut, RefreshCw, Search, Settings, Sparkles, Users, Wrench,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { logoutAction, runSyncAction } from "@/lib/actions";
import { cn } from "@/lib/utils";

type Dept = { id: number; name: string; statuses: string[]; depth?: number };

const LIBRARY: [string, string, boolean?][] = [
  ["/", "Overview"], ["/approvals", "Approvals"], ["/insights", "Insights"], ["/journey", "Patient journey"], ["/chains", "Event chains"], ["/playbooks", "Playbooks"], ["/rules", "Rules"], ["/lessons", "Lessons from errors"],
  ["/knowledge", "Knowledge bases"], ["/automations", "Automations"], ["/runs", "Runs", true], ["/costs", "Costs", true], ["/system", "System status", true], ["/activity", "Activity", true],
];

function Group({ icon: Icon, title, children, defaultOpen = true }: { icon: React.ElementType; title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="grid gap-1">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open}
        className="flex items-center gap-2.5 rounded-xl bg-muted/70 px-3 py-2 text-sm font-semibold hover:bg-muted">
        <Icon className="size-4 text-muted-foreground" /> {title}
        <ChevronDown className={cn("ml-auto size-4 text-muted-foreground transition-transform", !open && "-rotate-90")} />
      </button>
      {open && <div className="grid gap-0.5 py-1">{children}</div>}
    </div>
  );
}

function Item({ href, active, onClick, children }: { href: string; active: boolean; onClick?: () => void; children: React.ReactNode }) {
  return (
    <Link href={href} onClick={onClick} aria-current={active ? "page" : undefined}
      className={cn("flex items-center justify-between gap-2 rounded-lg px-3 py-1.5 pl-9 text-sm text-foreground/80 hover:bg-muted hover:text-foreground",
        active && "bg-accent font-semibold text-accent-foreground hover:bg-accent")}>
      {children}
    </Link>
  );
}

export function Sidebar({ user, departments, tools, admin, pendingApprovals = 0, onNavigate, onCollapse }: {
  user: { name: string; role: string }; departments: Dept[]; tools: { name: string; count: number }[];
  admin: boolean; pendingApprovals?: number; onNavigate?: () => void; onCollapse?: () => void;
}) {
  const path = usePathname();
  const router = useRouter();
  const [q, setQ] = useState("");
  const [syncing, start] = useTransition();
  const is = (href: string) => (href === "/" ? path === "/" : path === href || path.startsWith(`${href}/`));

  return (
    <div className="flex h-full flex-col gap-4 px-3 py-4">
      <div className="flex items-center gap-2.5 px-1">
        <span className="grid size-8 place-items-center rounded-full bg-primary text-xs font-extrabold text-primary-foreground">TLC</span>
        <span className="min-w-0 flex-1 leading-tight"><span className="block truncate font-extrabold">Third Brain</span><span className="block truncate text-xs text-muted-foreground">The Longevity Clinic</span></span>
        {onCollapse && <Button variant="ghost" size="icon" className="size-8" onClick={onCollapse} aria-label="Hide sidebar"><ChevronsLeft /></Button>}
      </div>

      <form role="search" className="relative" onSubmit={(e) => { e.preventDefault(); if (q.trim()) { router.push(`/search?q=${encodeURIComponent(q.trim())}`); onNavigate?.(); } }}>
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <input value={q} onChange={(e) => setQ(e.target.value)} type="search" placeholder="Search…" aria-label="Search"
          className="h-10 w-full rounded-xl border bg-background pr-3 pl-9 text-sm outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50" />
      </form>

      <Link href="/chat" onClick={onNavigate} aria-current={is("/chat") ? "page" : undefined}
        className={cn("flex items-center gap-2.5 rounded-xl border px-3 py-2.5 text-sm font-semibold hover:bg-muted", is("/chat") && "border-primary/40 bg-accent text-accent-foreground")}>
        <Sparkles className="size-4 text-primary" /> Ask the brain
      </Link>

      <nav className="-mx-1 grid flex-1 content-start gap-3 overflow-y-auto px-1" aria-label="Main">
        <Group icon={GitBranch} title="Workflows">
          {departments.map((d) => (
            <Item key={d.id} href={`/workflows/${d.id}`} active={is(`/workflows/${d.id}`)} onClick={onNavigate}>
              <span className="truncate" style={{ paddingLeft: `${(d.depth ?? 0) * 14}px` }}>{d.depth ? "↳ " : ""}{d.name}</span>
              <span className="num text-xs text-muted-foreground">{d.statuses.filter((s) => s === "live").length}/{d.statuses.length}</span>
            </Item>
          ))}
        </Group>
        <Group icon={BookOpen} title="Library">
          {LIBRARY.filter(([, , adminOnly]) => !adminOnly || admin).map(([href, label]) => (
            <Item key={href} href={href} active={is(href)} onClick={onNavigate}>
              {label}
              {href === "/approvals" && pendingApprovals > 0 && <span className="num rounded-full bg-signal-amber px-1.5 text-xs font-bold text-white">{pendingApprovals}</span>}
            </Item>
          ))}
        </Group>
        <Group icon={Users} title="Departments" defaultOpen={false}>
          {departments.map((d) => (
            <Item key={d.id} href={`/departments/${d.id}`} active={is(`/departments/${d.id}`)} onClick={onNavigate}>
              <span className="truncate" style={{ paddingLeft: `${(d.depth ?? 0) * 14}px` }}>{d.depth ? "↳ " : ""}{d.name}</span>
              <span className="flex h-1 w-14 gap-0.5" aria-hidden>
                {d.statuses.map((s, i) => <span key={i} className={cn("flex-1 rounded-full bg-border", s === "live" && "bg-signal-green", s === "testing" && "bg-signal-amber")} />)}
              </span>
            </Item>
          ))}
        </Group>
        {tools.length > 0 && (
          <Group icon={Wrench} title="Tools" defaultOpen={false}>
            {tools.map((t) => (
              <Item key={t.name} href={`/search?q=${encodeURIComponent(t.name)}`} active={false} onClick={onNavigate}>
                <span className="truncate">{t.name}</span><span className="num text-xs text-muted-foreground">{t.count}</span>
              </Item>
            ))}
          </Group>
        )}
      </nav>

      <div className="grid gap-1 border-t pt-3">
        {admin && (
          <Button variant="ghost" className="justify-start" disabled={syncing} onClick={() => start(async () => {
            const r = await runSyncAction();
            if (r.ok) toast.success("Synced with Jarvis"); else toast.error(`Sync finished with problems: ${r.error}`);
            router.refresh();
          })}>
            <RefreshCw className={syncing ? "animate-spin" : ""} /> {syncing ? "Syncing" : "Sync with Jarvis"}
          </Button>
        )}
        <Button variant="ghost" className="justify-start" asChild>
          <Link href="/settings" onClick={onNavigate}><Settings /> Settings</Link>
        </Button>
        <div className="flex items-center gap-2.5 px-3 pt-2">
          <span className="grid size-7 place-items-center rounded-full bg-muted text-xs font-bold">{user.name.slice(0, 1)}</span>
          <span className="min-w-0 flex-1 leading-tight"><span className="block truncate text-sm font-semibold">{user.name}</span><span className="block text-xs text-muted-foreground capitalize">{user.role}</span></span>
          <form action={logoutAction}><Button variant="ghost" size="icon" className="size-8" aria-label="Sign out"><LogOut /></Button></form>
        </div>
      </div>
    </div>
  );
}


