"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { disconnectMine } from "@/lib/actions";
import { MyMcpServers } from "@/components/my-mcp-servers";

type Row = { provider: "google" | "slack"; label: string; configured: boolean; accounts: { id: number; account: string }[]; does: string };

export function MyConnections({ rows, notice, servers = [], presets = [] }: { rows: Row[]; notice?: { ok: boolean; text: string }; servers?: Parameters<typeof MyMcpServers>[0]["servers"]; presets?: { name: string; url: string; whatsapp?: boolean }[] }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <Card id="connections" className="mt-8">
      <CardHeader className="grid gap-1">
        <CardTitle>My connections</CardTitle>
        <p className="text-sm text-muted-foreground">Connect your own accounts so the AI can work with them for you, in this dashboard and from your own Claude. Only you use them. In your own Claude you can also add Claude&apos;s Gmail, Calendar, Slack and other connectors directly.</p>
      </CardHeader>
      <CardContent className="grid gap-3">
        {notice && <p className={notice.ok ? "text-sm font-semibold text-signal-green" : "text-sm text-destructive"}>{notice.ok ? `Connected: ${notice.text}` : notice.text}</p>}
        {rows.map((r) => (
          <div key={r.provider} className="grid gap-2 rounded-xl border p-3">
            <div className="flex flex-wrap items-center gap-3">
              <div className="min-w-0 flex-1">
                <p className="font-semibold">{r.label}</p>
                <p className="text-sm text-muted-foreground">{r.accounts.length ? `${r.accounts.length} connected. The first one is used unless you name another.` : r.does}</p>
              </div>
              {r.configured
                ? <Button asChild variant={r.accounts.length ? "outline" : "default"}><a href={`/api/connect/${r.provider}/start${r.accounts.length ? "?add=1" : ""}`}>{r.accounts.length ? "Add another" : "Connect"}</a></Button>
                : <span className="text-sm text-muted-foreground">Not set up on the server yet (Ulvi)</span>}
            </div>
            {r.accounts.map((a, i) => (
              <div key={a.id} className="flex items-center gap-3 rounded-lg bg-muted/40 px-3 py-2 text-sm">
                <span className="min-w-0 flex-1 truncate">{a.account}{i === 0 && r.accounts.length > 1 ? <span className="ml-2 text-xs text-muted-foreground">default</span> : null}</span>
                <Button size="sm" variant="ghost" className="text-destructive" disabled={pending} onClick={() => start(async () => {
                  const x = await disconnectMine(r.provider, a.id); if (x.ok) { toast.success("Disconnected"); router.refresh(); } else toast.error(x.error);
                })}>Disconnect</Button>
              </div>
            ))}
          </div>
        ))}
        <MyMcpServers servers={servers} presets={presets} />
      </CardContent>
    </Card>
  );
}
