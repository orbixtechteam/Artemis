import { runSync } from "./lib/sync";

const minutes = Number(process.env.SYNC_MINUTES || 10);
if (minutes > 0) {
  const tick = () => runSync().catch((e) => console.error("sync failed:", e));
  setTimeout(tick, 5000);
  setInterval(tick, minutes * 60_000);
}

const statusMinutes = Number(process.env.STATUS_MINUTES || 15);
if (minutes > 0 && statusMinutes > 0) {
  import("./lib/status").then(({ collectStatus }) => {
    const check = () => collectStatus(false).catch((e) => console.error("status check failed:", e));
    setTimeout(check, 120_000);
    setInterval(check, statusMinutes * 60_000);
  });
}
