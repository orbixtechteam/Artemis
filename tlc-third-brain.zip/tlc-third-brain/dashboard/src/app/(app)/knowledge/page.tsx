import { EntityTable } from "@/components/entity-table";
import { PageHead } from "@/components/page-head";
import { canEdit, deptScope, isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { refs } from "@/lib/queries";

export default async function Page() {
  const u = await requireUser();
  const { deptRefs, pbRefs } = await refs(u);
  const rows = await prisma.knowledge.findMany({ where: deptScope(u), orderBy: { name: "asc" } });
  return (
    <>
      <PageHead title="Knowledge bases" intro="Where each department's protocols, documents and data live. Patient data stays in its source system and is only linked.">
      </PageHead>
      <EntityTable entity="knowledge" rows={rows} departments={deptRefs} playbooks={pbRefs} canEdit={false} canDelete={false} />
    </>
  );
}
