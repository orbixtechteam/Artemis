import { EntityTable } from "@/components/entity-table";
import { PageHead } from "@/components/page-head";
import { canEdit, deptScope, isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { refs } from "@/lib/queries";

export default async function Page() {
  const u = await requireUser();
  const { deptRefs, pbRefs } = await refs(u);
  const rows = await prisma.rule.findMany({ where: deptScope(u), orderBy: [{ ruleDate: "desc" }, { updatedAt: "desc" }] });
  return (
    <>
      <PageHead title="Rules" intro="Every rule has a date, a source and an owner. Only active rules are used; candidates wait for review.">
      </PageHead>
      <EntityTable entity="rules" rows={rows} departments={deptRefs} playbooks={pbRefs} canEdit={false} canDelete={false} />
    </>
  );
}
