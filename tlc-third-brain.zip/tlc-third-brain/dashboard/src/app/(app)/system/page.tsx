import { redirect } from "next/navigation";
import { PageHead } from "@/components/page-head";
import { RunBadge } from "@/components/status";
import { CheckNowButton, RunJobButton } from "@/components/system-controls";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { cachedStatus, type Check, type Level } from "@/lib/status";
import { ago, cn } from "@/lib/utils";

export const metadata = { title: "System · Third Brain" };

const DOT: Record<Level, string> = { ok: "bg-signal-green", warn: "bg-signal-amber", down: "bg-signal-red", unknown: "bg-kind-empty" };
const WORD: Record<Level, string> = { ok: "OK", warn: "Check", down: "Down", unknown: "Unknown" };

export default async function SystemPage() {
  const u = await requireUser();
  if (!isAdmin(u)) redirect("/");
  const [status, jobs] = await Promise.all([cachedStatus(), prisma.automation.findMany({ where: { enabled: true }, orderBy: { name: "asc" } })]);
  const groups = ["Jarvis", "Channels", "Connectors", "Server"] as const;
  const problems = status?.checks.filter((c) => c.level === "down" || c.level === "warn") ?? [];

  return (
    <>
      <PageHead title="System" intro={status ? `Last checked ${ago(status.checkedAt)}. Checked again every 15 minutes.` : "Not checked yet. The first check runs a minute after start, or press Check now."}>
        <CheckNowButton />
      </PageHead>

      {status && (
        <p className={cn("mb-6 rounded-xl border px-4 py-3 text-sm font-semibold", problems.length ? "border-signal-red/30 bg-signal-red/8 text-signal-red" : "border-signal-green/30 bg-signal-green/8 text-signal-green")}>
          {problems.length ? `${problems.length} need${problems.length === 1 ? "s" : ""} attention: ${problems.map((p) => p.name).join(", ")}` : "Everything is running."}
        </p>
      )}

      {groups.map((g) => {
        const items = status?.checks.filter((c) => c.group === g) ?? [];
        if (!items.length) return null;
        return (
          <section key={g} className="mb-8">
            <h2 className="mb-3 text-lg font-bold">{g}</h2>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{items.map((c) => <CheckCard key={c.key} c={c} />)}</div>
          </section>
        );
      })}

      <section className="mb-8">
        <h2 className="mb-3 text-lg font-bold">Jobs</h2>
        <Table>
          <TableHeader><TableRow><TableHead>Job</TableHead><TableHead>When</TableHead><TableHead>Last run</TableHead><TableHead>Status</TableHead><TableHead /></TableRow></TableHeader>
          <TableBody>
            {jobs.map((j) => (
              <TableRow key={j.id}>
                <TableCell className="font-semibold">{j.name}{j.lastError && <div className="mt-1 max-w-[50ch] text-xs font-normal text-muted-foreground">{j.lastError.slice(0, 160)}</div>}</TableCell>
                <TableCell>{j.schedule}</TableCell>
                <TableCell className="num whitespace-nowrap">{ago(j.lastRunAt)}</TableCell>
                <TableCell><RunBadge status={j.lastStatus} /></TableCell>
                <TableCell className="text-right">{j.extId && <RunJobButton job={j.name} />}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </section>
    </>
  );
}

function CheckCard({ c }: { c: Check }) {
  return (
    <Card className="p-4">
      <CardContent className="grid gap-1.5 p-0">
        <span className="flex items-center justify-between gap-2">
          <span className="inline-flex items-center gap-2 font-semibold"><span className={cn("size-2.5 rounded-full", DOT[c.level])} />{c.name}</span>
          <span className={cn("text-xs font-bold", c.level === "ok" ? "text-signal-green" : c.level === "warn" ? "text-signal-amber" : c.level === "down" ? "text-signal-red" : "text-muted-foreground")}>{WORD[c.level]}</span>
        </span>
        <span className="text-sm text-muted-foreground">{c.detail}</span>
      </CardContent>
    </Card>
  );
}
