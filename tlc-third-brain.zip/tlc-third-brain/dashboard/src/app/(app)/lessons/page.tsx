import { EntityTable } from "@/components/entity-table";
import { PageHead } from "@/components/page-head";
import { canEdit, deptScope, isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { refs } from "@/lib/queries";

export default async function Page() {
  const u = await requireUser();
  const { deptRefs, pbRefs } = await refs(u);
  const rows = await prisma.lesson.findMany({ where: deptScope(u), orderBy: [{ lessonDate: "desc" }, { updatedAt: "desc" }] });
  return (
    <>
      <PageHead title="Lessons from errors" intro="Every correction becomes a dated line with its fix, so the same mistake happens only once.">
      </PageHead>
      <EntityTable entity="lessons" rows={rows} departments={deptRefs} playbooks={pbRefs} canEdit={false} canDelete={false} />
    </>
  );
}
