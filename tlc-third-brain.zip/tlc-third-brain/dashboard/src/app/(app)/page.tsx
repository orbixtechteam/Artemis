import Link from "next/link";
import { BrainMap } from "@/components/brain-map";
import { PageHead } from "@/components/page-head";
import { RunsChart } from "@/components/runs-chart";
import { RunBadge } from "@/components/status";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { canEdit, deptScope, isAdmin, requireUser } from "@/lib/auth";
import { meta, prisma } from "@/lib/db";
import { refs, STATUS_ORDER } from "@/lib/queries";
import { cachedStatus } from "@/lib/status";
import { ago, cn, isOk, plural } from "@/lib/utils";

export default async function Overview() {
  const u = await requireUser();
  const admin = isAdmin(u);
  const { departments, playbooks, deptRefs, pbRefs } = await refs(u);
  const sorted = [...playbooks].sort((a, b) => (STATUS_ORDER[a.status] ?? 9) - (STATUS_ORDER[b.status] ?? 9) || a.name.localeCompare(b.name));
  const since = new Date(Date.now() - 14 * 86400_000);
  const [rules, lessons, knowledge, automations, recentLessons, runs, lastSync] = await Promise.all([
    prisma.rule.count({ where: deptScope(u) }),
    prisma.lesson.count({ where: deptScope(u) }),
    prisma.knowledge.count({ where: deptScope(u) }),
    prisma.automation.findMany({ where: { enabled: true } }),
    prisma.lesson.findMany({ where: deptScope(u), orderBy: [{ lessonDate: "desc" }, { updatedAt: "desc" }], take: 5 }),
    admin ? prisma.run.findMany({ where: { runAt: { gte: since } }, orderBy: { runAt: "desc" } }) : Promise.resolve([]),
    meta.get("last_sync"),
  ]);
  const sys = admin ? await cachedStatus() : null;
  const sysProblems = sys?.checks.filter((c) => c.level === "down" || c.level === "warn") ?? [];
  const failingAutos = admin ? automations.filter((a) => a.lastStatus && !isOk(a.lastStatus)) : [];
  const failedRuns = runs.filter((r) => !isOk(r.status) && r.runAt > new Date(Date.now() - 7 * 86400_000)).slice(0, 8);
  const byDay = new Map<string, { d: string; ok: number; bad: number }>();
  for (const r of runs) {
    const d = r.runAt.toISOString().slice(0, 10);
    const e = byDay.get(d) ?? { d, ok: 0, bad: 0 };
    if (isOk(r.status)) e.ok++; else e.bad++;
    byDay.set(d, e);
  }
  const days = [...byDay.values()].sort((a, b) => a.d.localeCompare(b.d));
  const live = playbooks.filter((p) => p.status === "live").length;
  const tested = sorted.filter((p) => p.testsTotal > 0);
  const stats: [number, string][] = [
    [live, `of ${playbooks.length} playbooks live`],
    [automations.length, `${plural(automations.length, "automation", "automations")} running`],
    [rules, plural(rules, "rule", "rules")],
    [lessons, `${plural(lessons, "lesson", "lessons")} from errors`],
    [knowledge, plural(knowledge, "knowledge base", "knowledge bases")],
  ];

  return (
    <>
      <PageHead title="The brain today" intro={`Every department, its playbooks and how far each one runs on its own. ${lastSync ? `Synced with Jarvis ${ago(lastSync)}.` : "Not synced with Jarvis yet."}`}>
      </PageHead>
      <div className="mb-6 flex flex-wrap gap-x-8 gap-y-2 text-foreground/80">
        {stats.map(([n, label]) => <span key={label}><strong className="num mr-1.5 text-2xl font-extrabold text-foreground">{n}</strong>{label}</span>)}
      </div>
      {sys && (
        <Link href="/system" className={cn("mb-4 flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-semibold hover:underline",
          sysProblems.length ? "border-signal-red/30 text-signal-red" : "border-signal-green/30 text-signal-green")}>
          <span className={cn("size-2.5 rounded-full", sysProblems.length ? "bg-signal-red" : "bg-signal-green")} />
          {sysProblems.length ? `System: ${sysProblems.map((p) => p.name).join(", ")} need attention` : `System: WhatsApp, connectors and jobs all running (checked ${ago(sys.checkedAt)})`}
        </Link>
      )}
      <BrainMap departments={departments} playbooks={sorted} />

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Needs attention</CardTitle><Link href="/runs" className="text-sm text-primary hover:underline">All runs</Link></CardHeader>
          <CardContent>
            {failingAutos.length + failedRuns.length === 0 ? <p className="text-muted-foreground">Nothing failed in the last 7 days.</p> : (
              <ul className="divide-y">
                {failingAutos.map((a) => (
                  <li key={`a${a.id}`} className="grid gap-1 py-2.5 first:pt-0">
                    <span className="flex items-center gap-2"><RunBadge status={a.lastStatus} /><strong>{a.name}</strong></span>
                    <span className="text-sm text-muted-foreground">{ago(a.lastRunAt)}{a.lastError ? `: ${a.lastError.slice(0, 160)}` : ""}</span>
                  </li>
                ))}
                {failedRuns.map((r) => (
                  <li key={`r${r.id}`} className="grid gap-1 py-2.5 first:pt-0">
                    <span className="flex items-center gap-2"><RunBadge status={r.status} />{r.job}</span>
                    <span className="num text-sm text-muted-foreground">{r.runAt.toISOString().slice(0, 16).replace("T", " ")} UTC</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Runs, last 14 days</CardTitle><span className="text-sm text-muted-foreground">green ok, red failed</span></CardHeader>
          <CardContent><RunsChart days={days} /></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Latest lessons from errors</CardTitle><Link href="/lessons" className="text-sm text-primary hover:underline">All lessons</Link></CardHeader>
          <CardContent>
            {recentLessons.length ? (
              <ul className="divide-y">
                {recentLessons.map((l) => (
                  <li key={l.id} className="grid gap-1 py-2.5 first:pt-0"><strong>{l.what}</strong>
                    <span className="text-sm text-muted-foreground">{l.lessonDate}{l.fix ? ` · Fix: ${l.fix}` : ""}</span></li>
                ))}
              </ul>
            ) : <p className="text-muted-foreground">No corrections yet. They appear here when someone rejects or edits a draft.</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Tests before go-live</CardTitle><span className="text-sm text-muted-foreground">go live at 9 of 10</span></CardHeader>
          <CardContent>
            {tested.length ? (
              <ul className="grid gap-4">
                {tested.map((p) => {
                  const pct = Math.round((p.testsPassed / p.testsTotal) * 100);
                  return (
                    <li key={p.id} className="grid gap-1.5">
                      <span><Link href={`/playbooks/${p.id}`} className="font-semibold hover:underline">{p.name}</Link> <span className="num text-muted-foreground">{p.testsPassed} of {p.testsTotal}</span></span>
                      <span className="h-1.5 overflow-hidden rounded-full bg-muted"><span className={cn("block h-full", pct >= 90 ? "bg-signal-green" : "bg-signal-amber")} style={{ width: `${pct}%` }} /></span>
                    </li>
                  );
                })}
              </ul>
            ) : <p className="text-muted-foreground">No test sets yet. Mark pass or fail in a test set and run a sync.</p>}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
