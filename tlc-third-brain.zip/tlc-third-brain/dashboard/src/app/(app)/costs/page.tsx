import { redirect } from "next/navigation";
import { PageHead } from "@/components/page-head";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { costFor, pricesConfigured } from "@/lib/usage";
import { cn } from "@/lib/utils";

export const metadata = { title: "Costs · Third Brain" };
const fmt = (n: number) => (n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `${Math.round(n / 1e3)}k` : String(n));
const usd = (n: number) => `$${n < 10 ? n.toFixed(2) : Math.round(n)}`;

export default async function CostsPage() {
  const u = await requireUser();
  if (!isAdmin(u)) redirect("/");
  const since = new Date(Date.now() - 30 * 86400_000);
  const rows = await prisma.usageLog.findMany({ where: { at: { gte: since } }, orderBy: { at: "asc" } });
  const priced = pricesConfigured();
  const budget = Number(process.env.MONTHLY_BUDGET_USD || 0);
  const monthStart = new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), 1));

  const byJob = new Map<string, { source: string; calls: number; input: number; output: number; cost: number }>();
  const byDay = new Map<string, { dashboard: number; jarvis: number }>();
  let monthCost = 0, unpriced = 0;
  for (const r of rows) {
    const c = costFor(r.model, r.inputTokens, r.outputTokens, r.cacheTokens);
    if (c === null) unpriced++;
    const k = `${r.source}|${r.job}`;
    const e = byJob.get(k) ?? { source: r.source, calls: 0, input: 0, output: 0, cost: 0 };
    byJob.set(k, { ...e, calls: e.calls + 1, input: e.input + r.inputTokens, output: e.output + r.outputTokens, cost: e.cost + (c ?? 0) });
    const d = r.at.toISOString().slice(0, 10);
    const day = byDay.get(d) ?? { dashboard: 0, jarvis: 0 };
    const v = priced ? (c ?? 0) : r.inputTokens + r.outputTokens;
    if (r.source === "dashboard") day.dashboard += v; else day.jarvis += v;
    byDay.set(d, day);
    if (r.at >= monthStart) monthCost += c ?? 0;
  }
  const jobs = [...byJob.entries()].map(([k, v]) => ({ job: k.split("|")[1], ...v })).sort((a, b) => (priced ? b.cost - a.cost : b.input + b.output - (a.input + a.output)));
  const totalTokens = rows.reduce((s, r) => s + r.inputTokens + r.outputTokens, 0);
  const totalCost = jobs.reduce((s, j) => s + j.cost, 0);
  const days = [...byDay.entries()].sort((a, b) => a[0].localeCompare(b[0]));

  return (
    <>
      <PageHead title="Costs" intro="AI use over the last 30 days: the dashboard chat and every Jarvis job, from Jarvis's own session logs." />
      {!priced && <p className="mb-5 rounded-xl border border-dashed px-4 py-3 text-sm text-muted-foreground">Showing tokens. Add <code>MODEL_PRICES</code> to <code>.env</code> (price per million tokens, from your Anthropic pricing page) to see dollars, and <code>MONTHLY_BUDGET_USD</code> for the budget bar.</p>}
      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        <Card className="p-4"><span className="text-sm text-muted-foreground">Last 30 days</span><div className="num text-3xl font-extrabold">{priced ? usd(totalCost) : fmt(totalTokens)}</div><span className="text-xs text-muted-foreground">{priced ? `${fmt(totalTokens)} tokens` : "tokens"} · {rows.length} AI calls</span></Card>
        <Card className="p-4"><span className="text-sm text-muted-foreground">Top job</span><div className="truncate text-xl font-bold">{jobs[0]?.job ?? "None yet"}</div><span className="text-xs text-muted-foreground">{jobs[0] ? (priced ? usd(jobs[0].cost) : `${fmt(jobs[0].input + jobs[0].output)} tokens`) : ""}</span></Card>
        <Card className="p-4">
          <span className="text-sm text-muted-foreground">This month{budget ? ` vs budget ${usd(budget)}` : ""}</span>
          <div className="num text-3xl font-extrabold">{priced ? usd(monthCost) : "—"}</div>
          {budget > 0 && priced && <span className="mt-2 block h-2 overflow-hidden rounded-full bg-muted"><span className={cn("block h-full", monthCost / budget > 0.9 ? "bg-signal-red" : monthCost / budget > 0.7 ? "bg-signal-amber" : "bg-signal-green")} style={{ width: `${Math.min(100, (monthCost / budget) * 100)}%` }} /></span>}
        </Card>
      </div>
      <Card className="mb-6">
        <CardHeader><CardTitle>Per day</CardTitle><span className="flex gap-4 text-xs text-muted-foreground"><span className="inline-flex items-center gap-1.5"><span className="size-2.5 rounded-sm bg-primary" />Jarvis</span><span className="inline-flex items-center gap-1.5"><span className="size-2.5 rounded-sm bg-kind-ai" />Dashboard chat</span></span></CardHeader>
        <CardContent>
          {days.length ? (
            <svg viewBox="0 0 900 180" className="h-auto w-full" role="img" aria-label="AI use per day">
              {(() => {
                const max = Math.max(...days.map(([, d]) => d.dashboard + d.jarvis), 1), slot = 900 / Math.max(days.length, 14);
                return days.map(([d, v], i) => {
                  const hj = (v.jarvis / max) * 150, hd = (v.dashboard / max) * 150;
                  return (
                    <g key={d}>
                      <rect x={i * slot + 3} y={160 - hj - hd} width={slot - 6} height={hd} rx={2} className="fill-kind-ai"><title>{`${d}: chat ${priced ? usd(v.dashboard) : fmt(v.dashboard)}`}</title></rect>
                      <rect x={i * slot + 3} y={160 - hj} width={slot - 6} height={hj} rx={2} className="fill-primary"><title>{`${d}: Jarvis ${priced ? usd(v.jarvis) : fmt(v.jarvis)}`}</title></rect>
                      <text x={i * slot + slot / 2} y={176} textAnchor="middle" className="fill-muted-foreground text-[10px]">{d.slice(8)}</text>
                    </g>
                  );
                });
              })()}
            </svg>
          ) : <p className="text-sm text-muted-foreground">No AI calls logged yet. The chat logs every call; Jarvis&apos;s use is read at each sync.</p>}
        </CardContent>
      </Card>
      <Table>
        <TableHeader><TableRow><TableHead>Job</TableHead><TableHead>Source</TableHead><TableHead className="text-right">Calls</TableHead><TableHead className="text-right">Input</TableHead><TableHead className="text-right">Output</TableHead>{priced && <TableHead className="text-right">Cost</TableHead>}</TableRow></TableHeader>
        <TableBody>
          {jobs.map((j) => (
            <TableRow key={`${j.source}${j.job}`}>
              <TableCell className="font-semibold">{j.job}</TableCell>
              <TableCell>{j.source === "dashboard" ? "Dashboard" : "Jarvis"}</TableCell>
              <TableCell className="num text-right">{j.calls}</TableCell>
              <TableCell className="num text-right">{fmt(j.input)}</TableCell>
              <TableCell className="num text-right">{fmt(j.output)}</TableCell>
              {priced && <TableCell className="num text-right font-semibold">{usd(j.cost)}</TableCell>}
            </TableRow>
          ))}
        </TableBody>
      </Table>
      {priced && unpriced > 0 && <p className="mt-2 text-xs text-muted-foreground">{unpriced} calls used a model without a price in MODEL_PRICES and are counted as $0.</p>}
    </>
  );
}
