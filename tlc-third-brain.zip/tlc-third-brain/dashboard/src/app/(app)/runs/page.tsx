import { redirect } from "next/navigation";
import { EntityTable } from "@/components/entity-table";
import { PageHead } from "@/components/page-head";
import { isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

export default async function RunsPage() {
  const u = await requireUser();
  if (!isAdmin(u)) redirect("/");
  const rows = await prisma.run.findMany({ where: { runAt: { gte: new Date(Date.now() - 14 * 86400_000) } }, orderBy: { runAt: "desc" }, take: 2000 });
  return (
    <>
      <PageHead title="Runs" intro="Every run of every scheduled job in the last 14 days, from Jarvis's run log." />
      <EntityTable entity="runs" rows={rows} departments={[]} playbooks={[]} canEdit={false} canDelete={false} />
    </>
  );
}
