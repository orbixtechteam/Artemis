import { ApiTokens } from "@/components/api-tokens";
import { MyConnections } from "@/components/my-connections";
import { WhatsappNumbers } from "@/components/whatsapp-numbers";
import { listConnections, PROVIDERS } from "@/lib/connections";
import { listUserMcp, MCP_PRESETS } from "@/lib/user-mcp";
import { DepartmentsAdmin } from "@/components/departments-admin";
import { PageHead } from "@/components/page-head";
import { PasswordForm } from "@/components/password-form";
import { People } from "@/components/people";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { isAdmin, requireUser } from "@/lib/auth";
import { ROLES } from "@/lib/constants";
import { meta, prisma } from "@/lib/db";
import { ago } from "@/lib/utils";
import { headers } from "next/headers";

export default async function SettingsPage({ searchParams }: { searchParams: Promise<{ connected?: string; connect_error?: string }> }) {
  const u = await requireUser();
  const sp = await searchParams;
  const mine = await listConnections(u.id);
  const myServers = await listUserMcp(u.id);
  const canWhatsApp = !!(await prisma.user.findUnique({ where: { id: u.id } }))?.whatsapp;
  const connRows = (["google", "slack"] as const).map((p) => ({ provider: p, label: PROVIDERS[p].label, configured: PROVIDERS[p].configured(), accounts: mine.filter((m) => m.provider === p).map((m) => ({ id: m.id, account: m.account })),
    does: p === "google" ? "Read and send your email, see your calendar, search and read your Drive." : "Post as you, send DMs, search your Slack." }));
  const admin = isAdmin(u);
  const [users, departments, lastSync, report, tokens] = await Promise.all([
    admin ? prisma.user.findMany({ orderBy: [{ role: "asc" }, { name: "asc" }] }) : Promise.resolve([]),
    prisma.department.findMany({ orderBy: [{ position: "asc" }, { name: "asc" }], include: { _count: { select: { playbooks: true } } } }),
    meta.get("last_sync"), meta.get("last_sync_report"),
    prisma.apiToken.findMany({ where: admin ? {} : { userId: u.id }, orderBy: { createdAt: "desc" } }),
  ]);
  const rep = report ? (JSON.parse(report) as Record<string, number | string[]>) : null;
  const people = users
    .sort((a, b) => Number(b.role === "owner") - Number(a.role === "owner"))
    .map((x) => ({ id: x.id, name: x.name, email: x.email, role: x.role, departments: JSON.parse(x.departments) as number[], active: x.active, whatsapp: x.whatsapp, lastLogin: x.lastLogin }));
  const depts = departments.map((d) => ({
    id: d.id, name: d.name, parentId: d.parentId, owner: d.owner, agent: d.agent, description: d.description, playbooks: d._count.playbooks,
    members: people.filter((p) => (p.role === "editor" || p.role === "viewer") && p.departments.includes(d.id)).map((p) => p.id),
  }));
  const allNames = new Map((admin ? users : []).map((x) => [x.id, x.name]));
  const grants = await prisma.oAuthToken.findMany({ where: admin ? {} : { userId: u.id }, orderBy: { createdAt: "desc" } });
  const clients = await prisma.oAuthClient.findMany({ where: { id: { in: [...new Set(grants.map((g) => g.clientId))] } } });
  const appMap = new Map<string, { clientId: string; name: string; owner: string; lastUsed: Date | null }>();
  for (const g of grants) {
    const key = `${g.clientId}:${g.userId}`;
    const prev = appMap.get(key);
    const last = g.lastUsed ?? g.createdAt;
    if (!prev || (prev.lastUsed ?? new Date(0)) < last) appMap.set(key, { clientId: g.clientId, name: clients.find((c) => c.id === g.clientId)?.name ?? "MCP client", owner: allNames.get(g.userId) ?? u.name, lastUsed: last });
  }
  const tokenRows = tokens.map((t) => ({ id: t.id, name: t.name, owner: allNames.get(t.userId) ?? u.name, createdAt: t.createdAt, lastUsed: t.lastUsed }));

  return (
    <>
      <PageHead title="Settings" intro="Departments, people, your account, the Claude connection and the link with Jarvis. Everything else changes through the AI chat." />
      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader className="grid gap-1"><CardTitle>Your account</CardTitle>
            <p className="text-sm text-muted-foreground">{u.name}, {u.email}, {ROLES[u.role].split(":")[0]}</p></CardHeader>
          <CardContent><PasswordForm /></CardContent>
        </Card>
        {admin && (
          <Card>
            <CardHeader className="grid gap-1"><CardTitle>Link with Jarvis</CardTitle>
              <p className="text-sm text-muted-foreground">Every few minutes the dashboard reads Jarvis&apos;s jobs, run log, rules, lessons, test sets and live playbooks from the server.</p></CardHeader>
            <CardContent className="grid gap-2 text-sm">
              <strong>{lastSync ? `Last sync ${ago(lastSync)}` : "Not synced yet"}</strong>
              {rep && <span className="text-muted-foreground">{Object.entries(rep).filter(([k]) => k !== "errors").map(([k, v]) => `${k}: ${v}`).join(", ")}</span>}
              {Array.isArray(rep?.errors) && rep.errors.map((e) => <span key={e} className="text-destructive">{e}</span>)}
            </CardContent>
          </Card>
        )}
      </div>
      {admin && <DepartmentsAdmin departments={depts} people={people.map((p) => ({ id: p.id, name: p.name, email: p.email, role: p.role }))} />}
      {admin && <People people={people} departments={departments.map((d) => ({ id: d.id, name: d.name }))} meIsOwner={u.role === "owner"} />}
      {admin && <WhatsappNumbers numbers={(await prisma.whatsappNumber.findMany({ orderBy: { label: "asc" } })).map((n) => ({ id: n.id, phone: n.phone, label: n.label, readers: JSON.parse(n.readers), senders: JSON.parse(n.senders) }))}
        people={users.map((x) => ({ id: x.id, name: x.name, role: x.role }))} />}
      <MyConnections rows={connRows} servers={myServers} presets={MCP_PRESETS.filter((p) => !p.whatsapp || u.role === "owner" || canWhatsApp)} notice={sp.connected ? { ok: true, text: sp.connected } : sp.connect_error ? { ok: false, text: sp.connect_error } : undefined} />
      <ApiTokens tokens={tokenRows} apps={[...appMap.values()]} appUrl={await publicUrl()} />
    </>
  );
}

/** The address people reach the dashboard at (APP_URL, else the request's own host). */
async function publicUrl() {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/$/, "");
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "";
  // Behind the Cloudflare tunnel the host can arrive as localhost; fall back to the clinic's address.
  if (!host || /^(localhost|127\.0\.0\.1)/.test(host)) return "https://ai-brain.thelongevityclinic.net";
  return `${h.get("x-forwarded-proto") ?? "https"}://${host}`;
}
