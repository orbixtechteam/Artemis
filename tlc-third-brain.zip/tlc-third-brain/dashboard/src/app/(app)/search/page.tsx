import Link from "next/link";
import { PageHead } from "@/components/page-head";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { deptScope, isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const u = await requireUser();
  const q = ((await searchParams).q ?? "").trim();
  const s = deptScope(u);
  const has = (f: string) => ({ [f]: { contains: q } });
  const [pbs, rules, lessons, kb, autos, steps] = q.length < 2 ? [[], [], [], [], [], []] : await Promise.all([
    prisma.playbook.findMany({ where: { ...s, OR: [has("name"), has("purpose"), has("trigger")] }, take: 20 }),
    prisma.rule.findMany({ where: { ...s, OR: [has("text"), has("source")] }, take: 20 }),
    prisma.lesson.findMany({ where: { ...s, OR: [has("what"), has("reason"), has("fix")] }, take: 20 }),
    prisma.knowledge.findMany({ where: { ...s, OR: [has("name"), has("description")] }, take: 20 }),
    isAdmin(u) ? prisma.automation.findMany({ where: has("name"), take: 20 }) : Promise.resolve([]),
    prisma.step.findMany({ where: { playbook: s, OR: [has("title"), has("tool"), has("role")] }, include: { playbook: true }, take: 30 }),
  ]);
  const results = [
    ...pbs.map((r) => ({ key: `p${r.id}`, type: "playbook", title: r.name, detail: r.purpose, href: `/playbooks/${r.id}` })),
    ...rules.map((r) => ({ key: `r${r.id}`, type: "rule", title: r.text, detail: r.source, href: "/rules" })),
    ...lessons.map((r) => ({ key: `l${r.id}`, type: "lesson", title: r.what, detail: r.fix, href: "/lessons" })),
    ...kb.map((r) => ({ key: `k${r.id}`, type: "knowledge", title: r.name, detail: r.description, href: "/knowledge" })),
    ...autos.map((r) => ({ key: `a${r.id}`, type: "automation", title: r.name, detail: r.schedule, href: "/automations" })),
    ...steps.map((r) => ({ key: `s${r.id}`, type: "step", title: r.title, detail: [r.playbook.name, r.role, r.tool].filter(Boolean).join(" · "), href: `/workflows/${r.playbook.departmentId ?? ""}` })),
  ];
  return (
    <>
      <PageHead title={q ? `Results for “${q}”` : "Search"} intro={`${results.length} found across playbooks, rules, lessons, knowledge and automations.`} />
      {results.length ? (
        <Card><CardContent className="pt-5"><ul className="divide-y">
          {results.map((r) => (
            <li key={r.key} className="grid gap-1 py-3 first:pt-0">
              <span className="flex items-center gap-2"><Badge>{r.type}</Badge><Link href={r.href} className="font-semibold hover:underline">{r.title}</Link></span>
              {r.detail && <span className="text-sm text-muted-foreground">{r.detail}</span>}
            </li>
          ))}
        </ul></CardContent></Card>
      ) : <p className="text-muted-foreground">Nothing found. Try a shorter word.</p>}
    </>
  );
}
