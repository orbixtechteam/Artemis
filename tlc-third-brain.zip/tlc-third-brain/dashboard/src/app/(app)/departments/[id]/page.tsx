import { notFound } from "next/navigation";
import { PlaybookRow } from "@/components/brain-map";
import { PageHead } from "@/components/page-head";
import { StatusBadge } from "@/components/status";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { canEdit, inScope, isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { refs, STATUS_ORDER } from "@/lib/queries";

export default async function DepartmentPage({ params }: { params: Promise<{ id: string }> }) {
  const u = await requireUser();
  const id = Number((await params).id);
  if (!inScope(u, id)) notFound();
  const d = await prisma.department.findUnique({
    where: { id },
    include: { playbooks: true, knowledge: { orderBy: { name: "asc" } }, rules: { orderBy: { updatedAt: "desc" } }, lessons: true },
  });
  if (!d) notFound();
  const { deptRefs, pbRefs } = await refs(u);
  const edit = canEdit(u);
  const pbs = [...d.playbooks].sort((a, b) => (STATUS_ORDER[a.status] ?? 9) - (STATUS_ORDER[b.status] ?? 9));
  const facts: [string, React.ReactNode][] = [
    ["Owner", d.owner || "To confirm"], ["Agent", d.agent || "None yet"],
    ["Playbooks live", `${pbs.filter((p) => p.status === "live").length} of ${pbs.length}`], ["Lessons logged", d.lessons.length],
  ];
  return (
    <>
      <PageHead title={d.name} intro={d.description} crumbs="Department">
      </PageHead>
      <div className="mb-8 grid grid-cols-[repeat(auto-fit,minmax(180px,1fr))] overflow-hidden rounded-xl border bg-card">
        {facts.map(([k, v]) => <div key={k} className="grid gap-1 border-r p-4 last:border-r-0"><span className="text-xs text-muted-foreground">{k}</span><span className="num font-semibold">{v}</span></div>)}
      </div>

      <Block title="Playbooks" >
        {pbs.length ? <div className="grid gap-0.5">{pbs.map((p) => <PlaybookRow key={p.id} p={p} />)}</div> : null}
      </Block>
      <Block title="Knowledge bases" >
        {d.knowledge.length ? (
          <ul className="divide-y">{d.knowledge.map((k) => (
            <li key={k.id} className="grid gap-1 py-3 first:pt-0">
              <span className="flex flex-wrap items-center gap-2"><strong>{k.name}</strong><Badge>{k.kind}</Badge>{k.patientData && <Badge tone="red">patient data</Badge>}</span>
              <span className="text-sm text-muted-foreground">{k.description} {/^https?:\/\//.test(k.link) && <a href={k.link} target="_blank" rel="noopener" className="text-primary hover:underline">Open</a>}</span>
            </li>
          ))}</ul>
        ) : null}
      </Block>
      <Block title="Rules" >
        {d.rules.length ? (
          <ul className="divide-y">{d.rules.map((r) => (
            <li key={r.id} className="grid gap-1 py-3 first:pt-0"><span className="flex items-start gap-2"><StatusBadge status={r.status} />{r.text}</span><span className="text-sm text-muted-foreground">{r.source}</span></li>
          ))}</ul>
        ) : null}
      </Block>
    </>
  );
}

function Block({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section className="mt-8 grid gap-3">
      <div className="flex items-end justify-between gap-3"><h2 className="text-lg font-bold">{title}</h2>{action}</div>
      {children ? <Card><CardContent className="pt-5">{children}</CardContent></Card> : <p className="text-muted-foreground">Nothing here yet.</p>}
    </section>
  );
}
