import { EntityTable } from "@/components/entity-table";
import { PageHead } from "@/components/page-head";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { requireUser } from "@/lib/auth";
import { ActionSchema, describeRule, TriggerSchema } from "@/lib/automations";
import { prisma } from "@/lib/db";
import { refs } from "@/lib/queries";
import { ago } from "@/lib/utils";

export default async function AutomationsPage() {
  const u = await requireUser();
  const { deptRefs, pbRefs } = await refs(u);
  const [rows, rules, people] = await Promise.all([
    prisma.automation.findMany({ orderBy: [{ enabled: "desc" }, { name: "asc" }] }),
    prisma.automationRule.findMany({ orderBy: { createdAt: "desc" } }),
    prisma.user.findMany({ select: { id: true, name: true } }),
  ]);
  return (
    <>
      <PageHead title="Automations" intro="Rules made in the chat (when X, do Y) run every 5 minutes. Jarvis's own jobs appear below after each sync." />
      <section className="mb-10 grid gap-3">
        <h2 className="text-lg font-bold">Rules from the chat</h2>
        {rules.length ? (
          <Table>
            <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Rule</TableHead><TableHead>By</TableHead><TableHead>Last run</TableHead><TableHead>Result</TableHead></TableRow></TableHeader>
            <TableBody>
              {rules.map((r) => {
                let text = "";
                try { const { when, then } = describeRule(TriggerSchema.parse(JSON.parse(r.trigger)), ActionSchema.parse(JSON.parse(r.action))); text = `When ${when}, ${then}.`; } catch { text = "(invalid rule)"; }
                return (
                  <TableRow key={r.id} className={r.enabled ? "" : "opacity-50"}>
                    <TableCell className="font-semibold">{r.name}{!r.enabled && <span className="ml-2 text-xs font-normal text-muted-foreground">paused</span>}</TableCell>
                    <TableCell className="max-w-[60ch]">{text}</TableCell>
                    <TableCell>{people.find((p) => p.id === r.createdBy)?.name ?? ""}</TableCell>
                    <TableCell className="num whitespace-nowrap">{ago(r.lastRunAt)}</TableCell>
                    <TableCell className={r.lastResult.startsWith("error") ? "text-destructive" : "text-muted-foreground"}>{r.lastResult || "not run yet"}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        ) : <p className="rounded-xl border border-dashed p-5 text-sm text-muted-foreground">No rules yet. In Ask the brain, try: &quot;Whenever a payment summary is posted in #sales-payment-made, also send it to Noah&apos;s WhatsApp.&quot;</p>}
      </section>
      <h2 className="mb-3 text-lg font-bold">Jarvis&apos;s jobs</h2>
      <EntityTable entity="automations" rows={rows} departments={deptRefs} playbooks={pbRefs} canEdit={false} canDelete={false} />
    </>
  );
}
