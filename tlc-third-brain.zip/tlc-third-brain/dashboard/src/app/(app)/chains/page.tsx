import { ChainsView } from "@/components/chains-view";
import { PageHead } from "@/components/page-head";
import { deptScope, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

export const metadata = { title: "Event chains · Third Brain" };

export default async function ChainsPage() {
  const u = await requireUser();
  const [links, playbooks] = await Promise.all([
    prisma.playbookLink.findMany(),
    prisma.playbook.findMany({ where: deptScope(u), include: { department: { select: { name: true } } } }),
  ]);
  const ids = new Set(playbooks.map((p) => p.id));
  const visible = links.filter((l) => ids.has(l.fromId) && ids.has(l.toId));
  const used = new Set(visible.flatMap((l) => [l.fromId, l.toId]));
  const nodes = playbooks.filter((p) => used.has(p.id)).map((p) => ({ id: p.id, name: p.name, status: p.status, autonomy: p.autonomy, trigger: p.trigger, department: p.department?.name ?? "" }));
  return (
    <div className="grid h-[calc(100dvh-4rem)] grid-rows-[auto_1fr]">
      <PageHead title="Event chains" intro="Which playbook starts which. One event (a payment, a booking, a finished call) runs through several jobs. Ask the brain to add a link." />
      {nodes.length ? <ChainsView nodes={nodes} links={visible.map((l) => ({ id: l.id, from: l.fromId, to: l.toId, label: l.label }))} />
        : <p className="text-muted-foreground">No chains yet. Example: &quot;link payment summary to pre-call brief: renewal call booked&quot;.</p>}
    </div>
  );
}
