import { redirect } from "next/navigation";
import { PageHead } from "@/components/page-head";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

export default async function ActivityPage() {
  const u = await requireUser();
  if (!isAdmin(u)) redirect("/");
  const rows = await prisma.activity.findMany({ orderBy: { id: "desc" }, take: 300 });
  return (
    <>
      <PageHead title="Activity" intro="Who changed what in the dashboard, newest first." />
      <Table>
        <TableHeader><TableRow><TableHead>When (UTC)</TableHead><TableHead>Person</TableHead><TableHead>Action</TableHead><TableHead>Detail</TableHead></TableRow></TableHeader>
        <TableBody>
          {rows.length ? rows.map((a) => (
            <TableRow key={a.id}>
              <TableCell className="num whitespace-nowrap">{a.at.toISOString().slice(0, 16).replace("T", " ")}</TableCell>
              <TableCell>{a.userName}</TableCell>
              <TableCell>{a.action} {a.entity}</TableCell>
              <TableCell className="max-w-[60ch]">{a.detail}</TableCell>
            </TableRow>
          )) : <TableRow><TableCell colSpan={4} className="py-8 text-center text-muted-foreground">No activity yet.</TableCell></TableRow>}
        </TableBody>
      </Table>
    </>
  );
}
