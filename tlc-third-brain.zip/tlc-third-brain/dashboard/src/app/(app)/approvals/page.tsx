import { OutboxCard } from "@/components/outbox-card";
import { PageHead } from "@/components/page-head";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { ago } from "@/lib/utils";

export const metadata = { title: "Approvals · Third Brain" };

export default async function ApprovalsPage() {
  const u = await requireUser();
  // Noah sees everything; others see emails from their own mailbox, and admins also see Slack posts.
  const mine = u.role === "owner" ? {} : { OR: [{ channel: "gmail", fromUserId: u.id }, ...(isAdmin(u) ? [{ channel: "slack" }] : [])] };
  const [pending, done] = await Promise.all([
    prisma.outbox.findMany({ where: { status: "pending", ...mine }, orderBy: { createdAt: "asc" } }),
    prisma.outbox.findMany({ where: { status: { not: "pending" }, ...mine }, orderBy: { decidedAt: "desc" }, take: 40 }),
  ]);
  return (
    <>
      <PageHead title="Approvals" intro="Emails from your own mailbox and Slack posts waiting for a yes. Nothing is sent until you approve it; you can edit first. A rejection with a reason becomes a lesson for that playbook." />
      {pending.length ? <div className="grid gap-4">{pending.map((m) => <OutboxCard key={m.id} m={m} />)}</div>
        : <p className="rounded-xl border border-dashed p-6 text-muted-foreground">Nothing waiting for approval.</p>}
      {done.length > 0 && (
        <section className="mt-10 grid gap-3">
          <h2 className="text-lg font-bold">Recent decisions</h2>
          <Table>
            <TableHeader><TableRow><TableHead>When</TableHead><TableHead>Channel</TableHead><TableHead>To</TableHead><TableHead>Message</TableHead><TableHead>Result</TableHead><TableHead>By</TableHead></TableRow></TableHeader>
            <TableBody>
              {done.map((m) => (
                <TableRow key={m.id}>
                  <TableCell className="num whitespace-nowrap">{ago(m.decidedAt)}</TableCell>
                  <TableCell>{m.channel === "gmail" ? "Email" : "Slack"}</TableCell>
                  <TableCell className="max-w-[24ch] truncate">{m.channel === "gmail" ? m.toAddr : m.slackChannel}</TableCell>
                  <TableCell className="max-w-[48ch]"><span className="line-clamp-2">{m.subject ? <strong>{m.subject}: </strong> : null}{m.body}</span>{m.error && <span className={m.status === "rejected" ? "block text-xs text-muted-foreground" : "mt-1 block text-xs font-medium text-destructive"}>{m.status === "rejected" ? "Reason: " : "Why it failed: "}{m.error}</span>}</TableCell>
                  <TableCell><Badge tone={m.status === "sent" ? (m.edited ? "amber" : "green") : "red"}>{m.status === "sent" ? (m.edited ? "sent after edits" : "sent as drafted") : m.status}</Badge></TableCell>
                  <TableCell>{m.decidedBy}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </section>
      )}
    </>
  );
}
