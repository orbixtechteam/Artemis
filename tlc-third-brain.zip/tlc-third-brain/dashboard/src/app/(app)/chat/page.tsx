import { ChatView } from "@/components/chat/chat-view";
import { inScope, isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

export default async function NewChatPage({ searchParams }: { searchParams: Promise<{ dept?: string }> }) {
  const u = await requireUser();
  const dept = Number((await searchParams).dept) || null;
  const departments = await prisma.department.findMany({ where: isAdmin(u) ? {} : { id: { in: u.departments } }, orderBy: [{ position: "asc" }, { name: "asc" }], select: { id: true, name: true } });
  return <ChatView key={`new-${dept}`} conversationId={null} departmentId={dept && inScope(u, dept) ? dept : null} departments={departments} initialMessages={[]} userName={u.name} canChooseDept />;
}
