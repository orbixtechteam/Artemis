import { notFound } from "next/navigation";
import { ChatView, type ChatMsg } from "@/components/chat/chat-view";
import { isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

export default async function ChatPage({ params }: { params: Promise<{ id: string }> }) {
  const u = await requireUser();
  const convo = await prisma.conversation.findUnique({ where: { id: Number((await params).id) }, include: { messages: { orderBy: { id: "asc" } } } });
  if (!convo || convo.userId !== u.id) notFound();
  const departments = await prisma.department.findMany({ where: isAdmin(u) ? {} : { id: { in: u.departments } }, orderBy: [{ position: "asc" }, { name: "asc" }], select: { id: true, name: true } });
  const messages: ChatMsg[] = convo.messages.map((m) => ({ id: m.id, role: m.role as ChatMsg["role"], content: m.content, events: JSON.parse(m.events), files: JSON.parse(m.attachments) }));
  return <ChatView key={convo.id} conversationId={convo.id} departmentId={convo.departmentId} departments={departments} initialMessages={messages} userName={u.name} canChooseDept={false} />;
}
