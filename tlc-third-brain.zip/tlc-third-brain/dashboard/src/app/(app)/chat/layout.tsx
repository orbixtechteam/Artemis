import { ChatShell } from "@/components/chat/chat-shell";
import { isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";

export const metadata = { title: "Chat · Third Brain" };

export default async function ChatLayout({ children }: { children: React.ReactNode }) {
  const u = await requireUser();
  const [conversations, departments] = await Promise.all([
    prisma.conversation.findMany({ where: { userId: u.id }, orderBy: { updatedAt: "desc" }, take: 200, select: { id: true, title: true, departmentId: true, updatedAt: true } }),
    prisma.department.findMany({ where: isAdmin(u) ? {} : { id: { in: u.departments } }, orderBy: [{ position: "asc" }, { name: "asc" }], select: { id: true, name: true } }),
  ]);
  return <ChatShell conversations={conversations} departments={departments}>{children}</ChatShell>;
}
