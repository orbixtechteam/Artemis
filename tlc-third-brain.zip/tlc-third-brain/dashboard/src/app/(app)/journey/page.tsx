import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { PageHead } from "@/components/page-head";
import { StatusBadge } from "@/components/status";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { cn } from "@/lib/utils";

export const metadata = { title: "Patient journey · Third Brain" };

export default async function JourneyPage({ searchParams }: { searchParams: Promise<{ program?: string }> }) {
  await requireUser();
  const all = await prisma.journeyStage.findMany({ orderBy: [{ program: "asc" }, { position: "asc" }] });
  const programs = [...new Set(all.map((s) => s.program))];
  const program = (await searchParams).program ?? programs[0];
  const stages = all.filter((s) => s.program === program);
  const pbs = await prisma.playbook.findMany({ where: { id: { in: stages.map((s) => s.playbookId).filter((x): x is number => !!x) } }, select: { id: true, name: true, status: true, autonomy: true } });
  const covered = stages.filter((s) => pbs.find((p) => p.id === s.playbookId && (p.status === "live" || p.status === "testing"))).length;

  return (
    <>
      <PageHead title="Patient journey" intro={stages.length ? `${program}: ${stages.length} stages, ${covered} run by a live or testing playbook. Stages without one are where the team still does the work by hand.` : "No journey stages yet. Ask the brain to add them per program."} />
      {programs.length > 1 && (
        <div className="mb-5 flex flex-wrap gap-2">
          {programs.map((p) => <Link key={p} href={`/journey?program=${encodeURIComponent(p)}`} className={cn("rounded-full border px-3 py-1 text-sm", p === program ? "border-primary bg-accent font-semibold text-accent-foreground" : "hover:bg-muted")}>{p}</Link>)}
        </div>
      )}
      <div className="overflow-x-auto pb-4">
        <ol className="flex min-w-max items-stretch gap-2">
          {stages.map((s, i) => {
            const pb = pbs.find((p) => p.id === s.playbookId);
            const live = pb && (pb.status === "live" || pb.status === "testing");
            return (
              <li key={s.id} className="flex items-stretch gap-2">
                <div className={cn("flex w-60 flex-col gap-2 rounded-xl border bg-card p-4", !pb && "border-dashed")}>
                  <span className="num text-xs font-semibold text-muted-foreground">Stage {i + 1}{s.duration ? ` · ${s.duration}` : ""}</span>
                  <span className="font-bold leading-tight">{s.name}</span>
                  <span className="text-sm text-muted-foreground">{s.description}</span>
                  <span className="mt-auto grid gap-1 pt-2 text-xs">
                    <span className="text-muted-foreground">{s.owner}</span>
                    {pb ? (
                      <Link href={`/playbooks/${pb.id}`} className="flex items-center gap-1.5 font-semibold hover:underline">
                        <span className={cn("size-2 rounded-full", pb.autonomy === "green" ? "bg-signal-green" : pb.autonomy === "red" ? "bg-signal-red" : "bg-signal-amber")} />{pb.name} <StatusBadge status={pb.status} />
                      </Link>
                    ) : <span className="font-semibold text-signal-amber">No playbook: done by hand</span>}
                    {pb && !live && <span className="text-signal-amber">Playbook not live yet</span>}
                  </span>
                </div>
                {i < stages.length - 1 && <ArrowRight className="size-5 shrink-0 self-center text-muted-foreground" aria-hidden />}
              </li>
            );
          })}
        </ol>
      </div>
      <p className="text-xs text-muted-foreground">Ask the brain to add a program, a stage or link a stage to a playbook (e.g. &quot;add an HRT+ journey with these stages…&quot;).</p>
    </>
  );
}
