import { AppShell } from "@/components/app-shell";
import { isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { refs } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const { departments, playbooks } = await refs(user);
  const visible = new Set(departments.map((d) => d.id));
  const ordered: { d: (typeof departments)[number]; depth: number }[] = [];
  const add = (parent: number | null, depth: number) => departments
    .filter((d) => (parent === null ? !d.parentId || !visible.has(d.parentId) : d.parentId === parent))
    .forEach((d) => { if (ordered.some((o) => o.d.id === d.id)) return; ordered.push({ d, depth }); if (depth < 4) add(d.id, depth + 1); });
  add(null, 0);
  const nav = ordered.map(({ d, depth }) => ({ id: d.id, name: d.name, depth, statuses: playbooks.filter((p) => p.departmentId === d.id).map((p) => p.status) }));
  const toolRows = await prisma.step.groupBy({ by: ["tool"], where: { tool: { not: "" }, playbookId: { in: playbooks.map((p) => p.id) } }, _count: { _all: true } });
  const tools = toolRows.map((t) => ({ name: t.tool, count: t._count._all })).sort((a, b) => b.count - a.count);
  const pending = await prisma.outbox.count({ where: { status: "pending", ...(user.role === "owner" ? {} : { OR: [{ channel: "gmail", fromUserId: user.id }, ...(isAdmin(user) ? [{ channel: "slack" }] : [])] }) } });
  return <AppShell user={{ name: user.name, role: user.role }} departments={nav} tools={tools} admin={isAdmin(user)} pendingApprovals={pending}>{children}</AppShell>;
}
