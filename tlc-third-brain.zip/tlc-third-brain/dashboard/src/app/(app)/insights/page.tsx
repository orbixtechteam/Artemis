import Link from "next/link";
import { PageHead } from "@/components/page-head";
import { StatusBadge } from "@/components/status";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { requireUser } from "@/lib/auth";
import { autonomyBoard, qualityTrend, STREAK_TARGET, timeSinks } from "@/lib/insights";
import { cn } from "@/lib/utils";
import { Pareto, WeekBars } from "@/components/insight-charts";

export const metadata = { title: "Insights · Third Brain" };

const LEVELS = [
  { key: "green", title: "Green: AI does it alone", bar: "bg-signal-green" },
  { key: "amber", title: "Amber: AI drafts, a person approves", bar: "bg-signal-amber" },
  { key: "red", title: "Red: never alone", bar: "bg-signal-red" },
] as const;

export default async function InsightsPage() {
  const u = await requireUser();
  const [board, sinks, quality] = await Promise.all([autonomyBoard(u), timeSinks(u), qualityTrend(u)]);
  const ready = board.filter((b) => b.ready);
  const byDept = Object.entries(sinks.rows.reduce<Record<string, number>>((m, r) => ({ ...m, [r.department]: (m[r.department] ?? 0) + r.hours }), {})).sort((a, b) => b[1] - a[1]);
  const top = sinks.rows.filter((r) => r.top);

  return (
    <>
      <PageHead title="Insights" intro="How far each job runs on its own, where the team's time goes, and whether the brain is getting better." />

      {/* ---------- autonomy ---------- */}
      <section className="mb-10">
        <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
          <div>
            <h2 className="text-xl font-bold">Autonomy map</h2>
            <p className="max-w-[75ch] text-sm text-muted-foreground">Live and testing playbooks by autonomy level. An amber job is ready for green after {STREAK_TARGET} clean runs since its last correction, no failures and tests at 9 of 10 or better (Road to autonomy, steps 1 and 2).</p>
          </div>
          {ready.length > 0 && <span className="rounded-full bg-signal-green/12 px-3 py-1 text-sm font-semibold text-signal-green">{ready.length} ready to move to green</span>}
        </div>
        <div className="grid gap-4 lg:grid-cols-3">
          {LEVELS.map((lv) => {
            const items = board.filter((b) => b.autonomy === lv.key);
            return (
              <Card key={lv.key} className="overflow-hidden">
                <div className={cn("h-1", lv.bar)} />
                <CardHeader><CardTitle>{lv.title}</CardTitle><span className="num text-sm text-muted-foreground">{items.length}</span></CardHeader>
                <CardContent className="grid gap-3">
                  {items.length ? items.map((b) => {
                    const pct = Math.min(100, ((b.usesApprovals ? b.approvedStreak : b.cleanRuns) / STREAK_TARGET) * 100);
                    return (
                      <Link key={b.id} href={`/playbooks/${b.id}`} className="grid gap-2 rounded-xl border bg-background p-3 hover:border-foreground/30">
                        <span className="flex items-start justify-between gap-2">
                          <span className="font-semibold leading-tight">{b.name}<span className="block text-xs font-normal text-muted-foreground">{b.department}</span></span>
                          {b.ready ? <span className="shrink-0 rounded-full bg-signal-green/12 px-2 py-0.5 text-xs font-semibold text-signal-green">ready for green</span> : <StatusBadge status={b.status} />}
                        </span>
                        {lv.key !== "red" && b.usesApprovals ? (
                          <span className="grid gap-1">
                            <span className="h-1.5 overflow-hidden rounded-full bg-muted"><span className={cn("block h-full", pct >= 100 ? "bg-signal-green" : "bg-signal-amber")} style={{ width: `${pct}%` }} /></span>
                            <span className="num text-xs text-muted-foreground">{b.approvedStreak} approved without edits in a row (target {STREAK_TARGET})</span>
                          </span>
                        ) : lv.key !== "red" && (b.hasRuns ? (
                          <span className="grid gap-1">
                            <span className="h-1.5 overflow-hidden rounded-full bg-muted"><span className={cn("block h-full", b.failedRuns ? "bg-signal-red" : pct >= 100 ? "bg-signal-green" : "bg-signal-amber")} style={{ width: `${pct}%` }} /></span>
                            <span className="num text-xs text-muted-foreground">{b.cleanRuns} clean run{b.cleanRuns === 1 ? "" : "s"}{b.failedRuns ? `, ${b.failedRuns} failed` : ""} since {b.lastCorrection ? `last correction (${b.lastCorrection})` : "start"}</span>
                          </span>
                        ) : <span className="text-xs text-muted-foreground">Runs on request; no run log yet. Corrections: {b.corrections}</span>)}
                        {b.tests && <span className="num text-xs text-muted-foreground">Tests {b.tests}</span>}
                      </Link>
                    );
                  }) : <p className="text-sm text-muted-foreground">Nothing here.</p>}
                </CardContent>
              </Card>
            );
          })}
        </div>
        <p className="mt-2 text-xs text-muted-foreground">Clean runs come from Jarvis&apos;s run log and corrections from each playbook&apos;s notes.md. Jobs whose drafts go through Approvals count &quot;approved without edits in a row&quot; instead.</p>
      </section>

      {/* ---------- 20/80 ---------- */}
      <section className="mb-10">
        <h2 className="text-xl font-bold">Where the time goes</h2>
        <p className="mb-3 max-w-[75ch] text-sm text-muted-foreground">
          Recurring jobs by estimated team hours a week ({Math.round(sinks.total)} h in total). The {top.length} highlighted jobs take 80% of the time; those without a playbook are the first candidates to automate.
        </p>
        {sinks.rows.length ? (
          <div className="grid gap-5 xl:grid-cols-[2fr_1fr]">
            <Card><CardContent className="pt-5"><Pareto rows={sinks.rows} /></CardContent></Card>
            <Card>
              <CardHeader><CardTitle>Hours a week by department</CardTitle></CardHeader>
              <CardContent className="grid gap-3">
                {byDept.map(([d, h]) => (
                  <div key={d} className="grid gap-1">
                    <span className="flex justify-between text-sm"><span className="font-semibold">{d}</span><span className="num text-muted-foreground">{h.toFixed(1)} h</span></span>
                    <span className="h-2 overflow-hidden rounded-full bg-muted"><span className="block h-full bg-primary" style={{ width: `${(h / byDept[0][1]) * 100}%` }} /></span>
                  </div>
                ))}
              </CardContent>
            </Card>
            <Card className="xl:col-span-2">
              <CardContent className="overflow-x-auto pt-5">
                <table className="w-full text-sm">
                  <thead><tr className="border-b text-left text-xs text-muted-foreground"><th className="py-2 pr-3">#</th><th className="pr-3">Job</th><th className="pr-3">Department</th><th className="pr-3 text-right">h/week</th><th className="pr-3">Where it gets stuck</th><th>Playbook</th></tr></thead>
                  <tbody>
                    {sinks.rows.map((r, i) => (
                      <tr key={r.id} className={cn("border-b last:border-0 align-top", r.top && "bg-primary/5")}>
                        <td className="num py-2.5 pr-3 text-muted-foreground">{i + 1}</td>
                        <td className="max-w-[42ch] py-2.5 pr-3"><span className="font-semibold">{r.task}</span><span className="block text-xs text-muted-foreground">{r.owner}{r.frequency ? ` · ${r.frequency}` : ""}</span></td>
                        <td className="py-2.5 pr-3 whitespace-nowrap">{r.department}</td>
                        <td className="num py-2.5 pr-3 text-right font-semibold">{r.hours}</td>
                        <td className="max-w-[40ch] py-2.5 pr-3 text-muted-foreground">{r.stuck}</td>
                        <td className="py-2.5 whitespace-nowrap">{r.playbook ? <Link href={`/playbooks/${r.playbook.id}`} className="inline-flex items-center gap-1.5 hover:underline">{r.playbook.name} <StatusBadge status={r.playbook.status} /></Link> : <span className="font-semibold text-signal-amber">No playbook yet</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <p className="mt-3 text-xs text-muted-foreground">Source: {sinks.rows[0]?.source}. Ask the brain to update a number, add a job or link it to a playbook.</p>
              </CardContent>
            </Card>
          </div>
        ) : <p className="text-muted-foreground">No time data yet. Run <code>pnpm db:seed</code> to load the Phase 0 analysis, or ask the brain to add jobs.</p>}
      </section>

      {/* ---------- quality ---------- */}
      <section className="mb-10 grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader className="grid gap-1"><CardTitle>Corrections per week</CardTitle><p className="text-sm text-muted-foreground">Lessons from errors logged in the last 8 weeks. Fewer over time means the playbooks are learning.</p></CardHeader>
          <CardContent><WeekBars weeks={quality.weeks} /></CardContent>
        </Card>
        <Card>
          <CardHeader className="grid gap-1"><CardTitle>Tests before go-live</CardTitle><p className="text-sm text-muted-foreground">Go live at 9 of 10 or better.</p></CardHeader>
          <CardContent>
            {quality.tests.length ? (
              <ul className="grid gap-4">
                {quality.tests.map((t) => {
                  const pct = Math.round((t.testsPassed / t.testsTotal) * 100);
                  return (
                    <li key={t.id} className="grid gap-1.5">
                      <span className="flex justify-between text-sm"><Link href={`/playbooks/${t.id}`} className="font-semibold hover:underline">{t.name}</Link><span className="num text-muted-foreground">{t.testsPassed} of {t.testsTotal}</span></span>
                      <span className="relative h-2 overflow-hidden rounded-full bg-muted"><span className={cn("block h-full", pct >= 90 ? "bg-signal-green" : "bg-signal-amber")} style={{ width: `${pct}%` }} /><span className="absolute inset-y-0 left-[90%] w-px bg-foreground/40" /></span>
                    </li>
                  );
                })}
              </ul>
            ) : <p className="text-sm text-muted-foreground">No marked test sets yet.</p>}
          </CardContent>
        </Card>
      </section>
    </>
  );
}
