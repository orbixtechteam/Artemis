import Link from "next/link";
import { SkillEditor } from "@/components/skill-editor";
import { notFound } from "next/navigation";
import { PageHead } from "@/components/page-head";
import { AutonomyLabel, RunBadge, StatusBadge } from "@/components/status";
import { Card, CardContent } from "@/components/ui/card";
import { canEdit, inScope, isAdmin, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { refs } from "@/lib/queries";
import { ago, cn, isOk } from "@/lib/utils";

export default async function PlaybookPage({ params }: { params: Promise<{ id: string }> }) {
  const u = await requireUser();
  const p = await prisma.playbook.findUnique({
    where: { id: Number((await params).id) },
    include: { department: true, rules: { orderBy: { updatedAt: "desc" } }, lessons: { orderBy: [{ lessonDate: "desc" }] }, automations: true },
  });
  if (!p || !inScope(u, p.departmentId)) notFound();
  const { deptRefs, pbRefs } = await refs(u);
  const edit = canEdit(u);
  const pct = p.testsTotal ? Math.round((p.testsPassed / p.testsTotal) * 100) : 0;
  const facts: [string, React.ReactNode][] = [
    ["Status", <StatusBadge key="s" status={p.status} />],
    ["Autonomy", <AutonomyLabel key="a" level={p.autonomy} />],
    ["Owner", p.owner || "To confirm"],
    ["What starts it", p.trigger || "Not set"],
    ["Tests", p.testsTotal ? (
      <span key="t" className="grid gap-1.5"><span className="num">{p.testsPassed} of {p.testsTotal} passed</span>
        <span className="h-1.5 overflow-hidden rounded-full bg-muted"><span className={cn("block h-full", pct >= 90 ? "bg-signal-green" : "bg-signal-amber")} style={{ width: `${pct}%` }} /></span></span>
    ) : "No test set yet"],
    ["Last run", <span key="r" className="inline-flex items-center gap-2">{ago(p.lastRunAt)}{p.lastRunStatus && !isOk(p.lastRunStatus) && <RunBadge status={p.lastRunStatus} />}</span>],
    ["SKILL.md", /^https?:\/\//.test(p.driveLink) ? <a key="l" href={p.driveLink} target="_blank" rel="noopener" className="text-primary hover:underline">Open in Drive</a> : "No link"],
  ];
  const { id: _omit, department: _d, rules: _r, lessons: _l, automations: _a, ...editable } = p;
  void _omit; void _d; void _r; void _l; void _a;

  return (
    <>
      <PageHead title={p.name} intro={p.purpose || "No description yet."}
        crumbs={<><Link href="/playbooks" className="hover:underline">Playbooks</Link> / {p.department ? <Link href={`/departments/${p.department.id}`} className="hover:underline">{p.department.name}</Link> : "No department"}</>}>
      </PageHead>
      <div className="mb-8 grid grid-cols-[repeat(auto-fit,minmax(180px,1fr))] overflow-hidden rounded-xl border bg-card">
        {facts.map(([k, v]) => (
          <div key={k} className="grid content-start gap-1 border-r border-b p-4 last:border-r-0"><span className="text-xs text-muted-foreground">{k}</span><span className="font-semibold">{v}</span></div>
        ))}
      </div>

      <SkillEditor playbookId={p.id} clinical={/medical|doctor|clinical/i.test(p.department?.name ?? "") || /blood|dose|prescri|lab/i.test(p.name)} />
      <div className="h-8" />

      <Section title="Rules" >
        {p.rules.length ? p.rules.map((r) => (
          <li key={r.id} className="grid gap-1 py-3 first:pt-0"><span className="flex items-start gap-2"><StatusBadge status={r.status} />{r.text}</span>
            <span className="text-sm text-muted-foreground">{[r.kind, r.source, r.ruleDate].filter(Boolean).join(" · ")}</span></li>
        )) : null}
      </Section>
      <Section title="Lessons from errors" >
        {p.lessons.length ? p.lessons.map((l) => (
          <li key={l.id} className="grid gap-1 py-3 first:pt-0"><strong>{l.what}</strong>
            <span className="text-sm text-muted-foreground">{[l.lessonDate, l.reason].filter(Boolean).join(" · ")}</span>
            {l.fix && <span className="text-sm">Fix: {l.fix}</span>}</li>
        )) : null}
      </Section>
      <Section title="Automations">
        {p.automations.length ? p.automations.map((a) => (
          <li key={a.id} className="grid gap-1 py-3 first:pt-0"><span className="flex items-center gap-2"><strong>{a.name}</strong><RunBadge status={a.lastStatus} /></span>
            <span className="text-sm text-muted-foreground">{a.schedule} · ran {ago(a.lastRunAt)}</span></li>
        )) : null}
      </Section>
    </>
  );
}

function Section({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) {
  const items = Array.isArray(children) ? children.filter(Boolean) : children;
  const empty = !items || (Array.isArray(items) && items.length === 0);
  return (
    <section className="mt-8 grid gap-3">
      <div className="flex items-end justify-between gap-3"><h2 className="text-lg font-bold">{title}</h2>{action}</div>
      {empty ? <p className="text-muted-foreground">Nothing here yet.</p> : <Card><CardContent className="pt-5"><ul className="divide-y">{items}</ul></CardContent></Card>}
    </section>
  );
}
