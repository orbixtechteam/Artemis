import { EntityTable } from "@/components/entity-table";
import { PageHead } from "@/components/page-head";
import { canEdit, isAdmin, requireUser } from "@/lib/auth";
import { refs } from "@/lib/queries";

export default async function PlaybooksPage() {
  const u = await requireUser();
  const { playbooks, deptRefs, pbRefs } = await refs(u);
  return (
    <>
      <PageHead title="Playbooks" intro="One playbook per recurring job: what starts it, what it produces, who owns it and how much it runs on its own.">
      </PageHead>
      <EntityTable entity="playbooks" rows={playbooks} departments={deptRefs} playbooks={pbRefs} canEdit={false} canDelete={false} />
    </>
  );
}
