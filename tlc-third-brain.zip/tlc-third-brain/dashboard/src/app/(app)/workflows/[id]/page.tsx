import { notFound } from "next/navigation";
import { WorkflowView } from "@/components/workflow-view";
import { canEdit, inScope, requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { STATUS_ORDER } from "@/lib/queries";

export const metadata = { title: "Workflow · Third Brain" };

export default async function WorkflowPage({ params }: { params: Promise<{ id: string }> }) {
  const u = await requireUser();
  const id = Number((await params).id);
  if (!inScope(u, id)) notFound();
  const department = await prisma.department.findUnique({
    where: { id },
    include: { playbooks: { include: { steps: { orderBy: [{ x: "asc" }, { y: "asc" }] } } } },
  });
  if (!department) notFound();
  const sections = [...department.playbooks]
    .sort((a, b) => (STATUS_ORDER[a.status] ?? 9) - (STATUS_ORDER[b.status] ?? 9) || a.name.localeCompare(b.name))
    .map((p) => ({ id: p.id, name: p.name, status: p.status, autonomy: p.autonomy, canvasX: p.canvasX, canvasY: p.canvasY,
      steps: p.steps.map((s) => ({ id: s.id, playbookId: s.playbookId, title: s.title, kind: s.kind, role: s.role, tool: s.tool, note: s.note, source: s.source, x: s.x, y: s.y })) }));
  const stepIds = sections.flatMap((s) => s.steps.map((st) => st.id));
  const connections = await prisma.connection.findMany({ where: { fromId: { in: stepIds } }, select: { id: true, fromId: true, toId: true, label: true } });
  const allSteps = await prisma.step.findMany({ select: { role: true, tool: true } });
  const roles = [...new Set(allSteps.map((s) => s.role).filter(Boolean))].sort();
  const tools = [...new Set(sections.flatMap((s) => s.steps.map((st) => st.tool)).filter(Boolean))].sort();
  const allTools = [...new Set(allSteps.map((s) => s.tool).filter(Boolean))].sort();

  return (
    <div className="h-dvh">
      <WorkflowView department={{ id: department.id, name: department.name }} sections={sections} connections={connections}
        roles={roles} tools={tools} allTools={allTools} canEdit={false} />
    </div>
  );
}
