import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { refs } from "@/lib/queries";

export default async function WorkflowsIndex() {
  const u = await requireUser();
  const { departments } = await refs(u);
  if (!departments.length) return <p className="p-8 text-muted-foreground">No departments you can see yet.</p>;
  redirect(`/workflows/${departments[0].id}`);
}
