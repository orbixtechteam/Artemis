import { SetPasswordForm } from "@/components/set-password-form";
import { checkPasswordLink } from "@/lib/invites";

export const metadata = { title: "Set your password · Third Brain" };
export const dynamic = "force-dynamic";

export default async function SetPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const token = (await searchParams).token ?? "";
  const t = await checkPasswordLink(token);
  return (
    <main className="grid min-h-screen place-items-center p-6">
      <div className="grid w-full max-w-sm gap-5 rounded-xl border bg-card p-8 shadow-sm">
        <div className="grid gap-1.5">
          <h1 className="text-3xl font-extrabold tracking-tight">Third Brain</h1>
          {t ? <p className="text-muted-foreground">Hi {t.user.name.split(" ")[0]}, choose your password to {t.purpose === "invite" ? "start" : "sign in again"}. Your email is <strong className="text-foreground">{t.user.email}</strong>.</p>
             : <p className="text-muted-foreground">This link has expired or was already used. Ask Noah or Ulvi for a new one.</p>}
        </div>
        {t && <SetPasswordForm token={token} />}
      </div>
    </main>
  );
}
