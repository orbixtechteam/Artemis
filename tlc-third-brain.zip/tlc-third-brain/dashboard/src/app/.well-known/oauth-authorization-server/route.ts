import { authServerMetadata, baseUrl, cors } from "@/lib/oauth";
export const dynamic = "force-dynamic";
export const GET = (req: Request) => Response.json(authServerMetadata(baseUrl(req)), { headers: cors });
export const OPTIONS = () => new Response(null, { status: 204, headers: cors });
