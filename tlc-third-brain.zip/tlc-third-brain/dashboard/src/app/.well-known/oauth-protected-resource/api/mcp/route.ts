import { baseUrl, cors, resourceMetadata } from "@/lib/oauth";
export const dynamic = "force-dynamic";
export const GET = (req: Request) => Response.json(resourceMetadata(baseUrl(req)), { headers: cors });
export const OPTIONS = () => new Response(null, { status: 204, headers: cors });
