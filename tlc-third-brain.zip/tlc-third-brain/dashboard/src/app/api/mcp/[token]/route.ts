import { rememberAppUrl } from "@/lib/appurl";
import { NextResponse } from "next/server";
import { handleMcp, userForToken } from "@/lib/mcp";

export const dynamic = "force-dynamic";

async function serve(req: Request, token: string) {
  rememberAppUrl(req);
  const bearer = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  const u = await userForToken(token === "auth" ? bearer : token);
  if (!u) return NextResponse.json({ jsonrpc: "2.0", id: null, error: { code: -32001, message: "Invalid or revoked token. Create one in Settings → API tokens." } }, { status: 401 });
  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ jsonrpc: "2.0", id: null, error: { code: -32700, message: "Parse error" } }, { status: 400 });
  if (Array.isArray(body)) {
    const out = (await Promise.all(body.map((m) => handleMcp(u, m)))).filter(Boolean);
    return out.length ? NextResponse.json(out) : new NextResponse(null, { status: 202 });
  }
  const out = await handleMcp(u, body);
  return out ? NextResponse.json(out) : new NextResponse(null, { status: 202 });
}

export async function POST(req: Request, { params }: { params: Promise<{ token: string }> }) {
  return serve(req, (await params).token);
}
export async function GET() {
  return new NextResponse("Method not allowed. This MCP server answers POST requests.", { status: 405, headers: { Allow: "POST" } });
}
export async function DELETE() {
  return new NextResponse(null, { status: 204 });
}
