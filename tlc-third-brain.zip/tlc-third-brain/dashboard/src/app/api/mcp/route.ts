import { rememberAppUrl } from "@/lib/appurl";
import { handleMcp, userForToken } from "@/lib/mcp";
import { baseUrl, cors } from "@/lib/oauth";

export const dynamic = "force-dynamic";
export const OPTIONS = () => new Response(null, { status: 204, headers: cors });

/** MCP endpoint for OAuth clients (Claude "Connect"): Bearer access token, 401 with discovery metadata otherwise. */
export async function POST(req: Request) {
  rememberAppUrl(req);
  const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  const u = await userForToken(token);
  if (!u) {
    return Response.json({ jsonrpc: "2.0", id: null, error: { code: -32001, message: "Sign in required." } }, {
      status: 401,
      headers: { ...cors, "www-authenticate": `Bearer realm="third-brain", resource_metadata="${baseUrl(req)}/.well-known/oauth-protected-resource"` },
    });
  }
  const body = await req.json().catch(() => null);
  if (!body) return Response.json({ jsonrpc: "2.0", id: null, error: { code: -32700, message: "Parse error" } }, { status: 400, headers: cors });
  if (Array.isArray(body)) {
    const out = (await Promise.all(body.map((m) => handleMcp(u, m)))).filter(Boolean);
    return out.length ? Response.json(out, { headers: cors }) : new Response(null, { status: 202, headers: cors });
  }
  const out = await handleMcp(u, body);
  return out ? Response.json(out, { headers: cors }) : new Response(null, { status: 202, headers: cors });
}

export async function GET(req: Request) {
  return new Response("Method not allowed", { status: 405, headers: { ...cors, allow: "POST", "www-authenticate": `Bearer resource_metadata="${baseUrl(req)}/.well-known/oauth-protected-resource"` } });
}
export const DELETE = () => new Response(null, { status: 204, headers: cors });
