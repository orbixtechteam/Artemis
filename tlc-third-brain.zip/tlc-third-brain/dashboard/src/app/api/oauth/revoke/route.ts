import { prisma } from "@/lib/db";
import { cors, sha256 } from "@/lib/oauth";

export const dynamic = "force-dynamic";
export const OPTIONS = () => new Response(null, { status: 204, headers: cors });

export async function POST(req: Request) {
  const token = new URLSearchParams(await req.text()).get("token") ?? "";
  const h = sha256(token);
  await prisma.oAuthToken.deleteMany({ where: { OR: [{ accessHash: h }, { refreshHash: h }] } });
  return new Response(null, { status: 200, headers: cors });
}
