import { prisma } from "@/lib/db";
import { cors, issueTokens, sha256, verifyPkce } from "@/lib/oauth";

export const dynamic = "force-dynamic";
export const OPTIONS = () => new Response(null, { status: 204, headers: cors });
const err = (error: string, description: string, status = 400) => Response.json({ error, error_description: description }, { status, headers: { ...cors, "cache-control": "no-store" } });

export async function POST(req: Request) {
  const ct = req.headers.get("content-type") ?? "";
  const form = ct.includes("application/json") ? new URLSearchParams(Object.entries(await req.json().catch(() => ({}))).map(([k, v]) => [k, String(v)])) : new URLSearchParams(await req.text());
  const grant = form.get("grant_type");

  if (grant === "authorization_code") {
    const code = form.get("code") ?? "", verifier = form.get("code_verifier") ?? "", clientId = form.get("client_id") ?? "", redirect = form.get("redirect_uri") ?? "";
    const row = await prisma.oAuthCode.findUnique({ where: { codeHash: sha256(code) } });
    if (row) await prisma.oAuthCode.delete({ where: { codeHash: row.codeHash } }); // one use only
    if (!row || row.expiresAt < new Date()) return err("invalid_grant", "The code is invalid or expired.");
    if (row.clientId !== clientId || (redirect && row.redirectUri !== redirect)) return err("invalid_grant", "The code was issued to another client.");
    if (!verifier || !verifyPkce(verifier, row.codeChallenge)) return err("invalid_grant", "PKCE check failed.");
    const user = await prisma.user.findUnique({ where: { id: row.userId } });
    if (!user?.active) return err("invalid_grant", "This person no longer has access.");
    return Response.json(await issueTokens(clientId, row.userId), { headers: { ...cors, "cache-control": "no-store" } });
  }

  if (grant === "refresh_token") {
    const t = await prisma.oAuthToken.findUnique({ where: { refreshHash: sha256(form.get("refresh_token") ?? "") } });
    if (!t || t.refreshExpiresAt < new Date()) return err("invalid_grant", "The refresh token is invalid or expired.");
    if (form.get("client_id") && form.get("client_id") !== t.clientId) return err("invalid_grant", "Wrong client.");
    await prisma.oAuthToken.delete({ where: { id: t.id } }); // rotate
    const user = await prisma.user.findUnique({ where: { id: t.userId } });
    if (!user?.active) return err("invalid_grant", "This person no longer has access.");
    return Response.json(await issueTokens(t.clientId, t.userId), { headers: { ...cors, "cache-control": "no-store" } });
  }
  return err("unsupported_grant_type", "Use authorization_code or refresh_token.");
}
