import crypto from "node:crypto";
import { prisma } from "@/lib/db";
import { cors } from "@/lib/oauth";

export const dynamic = "force-dynamic";
export const OPTIONS = () => new Response(null, { status: 204, headers: cors });

/** Dynamic client registration (RFC 7591) for public MCP clients such as Claude. */
export async function POST(req: Request) {
  const b = (await req.json().catch(() => ({}))) as { redirect_uris?: string[]; client_name?: string };
  const uris = (b.redirect_uris ?? []).filter((u) => { try { const x = new URL(u); return x.protocol === "https:" || x.hostname === "localhost" || x.hostname === "127.0.0.1"; } catch { return false; } });
  if (!uris.length) return Response.json({ error: "invalid_redirect_uri", error_description: "Give at least one https (or localhost) redirect URI." }, { status: 400, headers: cors });
  const id = `tbc_${crypto.randomBytes(16).toString("hex")}`;
  const name = String(b.client_name ?? "MCP client").slice(0, 80);
  await prisma.oAuthClient.create({ data: { id, name, redirectUris: JSON.stringify(uris) } });
  return Response.json({
    client_id: id, client_name: name, redirect_uris: uris, client_id_issued_at: Math.floor(Date.now() / 1000),
    grant_types: ["authorization_code", "refresh_token"], response_types: ["code"], token_endpoint_auth_method: "none",
  }, { status: 201, headers: cors });
}
