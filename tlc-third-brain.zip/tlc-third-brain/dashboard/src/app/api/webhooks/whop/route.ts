import { handleWebhook, verifyWebhook } from "@/lib/whop";

export const dynamic = "force-dynamic";

/** Whop → brain: payment succeeded / failed. Signed with WHOP_WEBHOOK_SECRET; anything unsigned is refused. */
export async function POST(req: Request) {
  const body = await req.text();
  if (!verifyWebhook(body, req.headers)) return new Response("Invalid signature", { status: 401 });
  const result = await handleWebhook(JSON.parse(body));
  return Response.json(result);
}
