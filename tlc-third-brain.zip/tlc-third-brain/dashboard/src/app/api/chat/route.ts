import { rememberAppUrl } from "@/lib/appurl";
import { currentUser, inScope } from "@/lib/auth";
import { chat, type ChatTurn } from "@/lib/assistant";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

type FileRef = { id: number; name: string; mime: string; size: number };

/**
 * Streams NDJSON lines: {type:"conversation",id} once, {type:"tool",...} per step, then {type:"reply",text} and {type:"done"}.
 * Messages are saved, so the history survives reloads.
 */
export async function POST(req: Request) {
  rememberAppUrl(req);
  const u = await currentUser();
  if (!u) return Response.json({ error: "Sign in to continue." }, { status: 401 });
  const body = (await req.json().catch(() => ({}))) as { conversationId?: number; departmentId?: number | null; message?: string; attachments?: FileRef[] };
  const text = String(body.message ?? "").trim();
  const files = (body.attachments ?? []).filter((f) => Number.isInteger(f?.id)).slice(0, 10);
  if (!text && !files.length) return Response.json({ error: "Write a message first." }, { status: 400 });

  let convo = body.conversationId ? await prisma.conversation.findUnique({ where: { id: body.conversationId } }) : null;
  if (convo && convo.userId !== u.id) return Response.json({ error: "Not your conversation." }, { status: 403 });
  if (!convo) {
    const deptId = body.departmentId ?? null;
    if (deptId !== null && !inScope(u, deptId)) return Response.json({ error: "You can't open a chat for that department." }, { status: 403 });
    const title = (text || files[0]?.name || "New chat").replace(/\s+/g, " ").slice(0, 70);
    convo = await prisma.conversation.create({ data: { userId: u.id, departmentId: deptId, title } });
  }
  const department = convo.departmentId ? await prisma.department.findUnique({ where: { id: convo.departmentId }, select: { id: true, name: true } }) : null;

  await prisma.chatMessage.create({ data: { conversationId: convo.id, role: "user", content: text, attachments: JSON.stringify(files) } });
  const history = await prisma.chatMessage.findMany({ where: { conversationId: convo.id }, orderBy: { id: "desc" }, take: 24 });
  const turns: ChatTurn[] = history.reverse().map((m) => ({
    role: m.role as "user" | "assistant", content: m.content,
    attachments: (JSON.parse(m.attachments) as FileRef[]).map((f) => f.id),
  }));
  const conversationId = convo.id;

  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (o: unknown) => controller.enqueue(enc.encode(`${JSON.stringify(o)}\n`));
      send({ type: "conversation", id: conversationId });
      try {
        const r = await chat(u, turns, { department, onEvent: (e) => send({ type: "tool", ...e }) });
        await prisma.chatMessage.create({ data: { conversationId, role: "assistant", content: r.reply, events: JSON.stringify(r.events) } });
        await prisma.conversation.update({ where: { id: conversationId }, data: { updatedAt: new Date() } });
        send({ type: "reply", text: r.reply, wrote: r.events.some((e) => e.ok && e.write) });
      } catch (e) {
        send({ type: "reply", text: `Something went wrong: ${(e as Error).message}`, wrote: false });
      }
      send({ type: "done" });
      controller.close();
    },
  });
  return new Response(stream, { headers: { "content-type": "application/x-ndjson; charset=utf-8", "cache-control": "no-cache, no-transform", "x-accel-buffering": "no" } });
}
