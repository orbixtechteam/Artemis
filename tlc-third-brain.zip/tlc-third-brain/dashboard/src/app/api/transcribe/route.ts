import { execFile } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { currentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const maxDuration = 180;

const BIN = process.env.TRANSCRIBE_BIN || "/usr/local/bin/transcribe"; // the same local Whisper Jarvis uses for voice notes
const MAX = 20 * 1024 * 1024;

/** Speech to text on the server: the audio never leaves it. */
export async function POST(req: Request) {
  const u = await currentUser();
  if (!u) return Response.json({ error: "Sign in to continue." }, { status: 401 });
  if (!fs.existsSync(BIN)) return Response.json({ error: "Voice isn't set up on this server." }, { status: 501 });
  const form = await req.formData().catch(() => null);
  const audio = form?.get("audio");
  if (!(audio instanceof File) || !audio.size) return Response.json({ error: "No audio received." }, { status: 400 });
  if (audio.size > MAX) return Response.json({ error: "Recording is too long." }, { status: 413 });
  const ext = /mp4|m4a|aac/.test(audio.type) ? "m4a" : /ogg/.test(audio.type) ? "ogg" : /wav/.test(audio.type) ? "wav" : "webm";
  const file = path.join(os.tmpdir(), `voice-${crypto.randomBytes(8).toString("hex")}.${ext}`);
  fs.writeFileSync(file, Buffer.from(await audio.arrayBuffer()), { mode: 0o600 });
  try {
    const text = await new Promise<string>((resolve, reject) =>
      execFile(BIN, [file], { timeout: 150_000, maxBuffer: 4 * 1024 * 1024 }, (err, out, errOut) =>
        err ? reject(new Error((errOut || err.message).slice(-200))) : resolve(out)));
    let out = text.trim();
    if (out.startsWith("{")) { try { out = String(JSON.parse(out).text ?? out); } catch { /* plain text after all */ } }
    return Response.json({ text: out.replace(/\s+/g, " ").trim() });
  } catch (e) {
    return Response.json({ error: `Couldn't transcribe: ${(e as Error).message}` }, { status: 500 });
  } finally {
    fs.rmSync(file, { force: true });
  }
}
