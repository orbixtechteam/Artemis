import fs from "node:fs";
import { currentUser, isAdmin } from "@/lib/auth";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

/** Download a file made or attached in the chat: the person's own files, or anyone's for Noah and admins. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const u = await currentUser();
  if (!u) return new Response("Sign in to continue.", { status: 401 });
  const a = await prisma.attachment.findUnique({ where: { id: Number((await params).id) } });
  if (!a || (a.userId !== u.id && !isAdmin(u))) return new Response("Not found.", { status: 404 });
  if (!fs.existsSync(a.path)) return new Response("The file is no longer on the server.", { status: 410 });
  return new Response(new Uint8Array(fs.readFileSync(a.path)), { headers: {
    "content-type": a.mime || "application/octet-stream",
    "content-disposition": `attachment; filename*=UTF-8''${encodeURIComponent(a.name)}`,
  } });
}
