import { runAutomations } from "@/lib/automations";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/** Called by the server's "Brain automations" job every 5 minutes, with the shared key. Plain-text answer: what goes to Noah's WhatsApp, or NO_REPLY. */
export async function POST(req: Request) {
  const key = process.env.AUTOMATION_KEY;
  if (!key || req.headers.get("x-brain-key") !== key) return new Response("Forbidden", { status: 403 });
  const { whatsapp } = await runAutomations();
  return new Response(whatsapp || "NO_REPLY", { headers: { "content-type": "text/plain; charset=utf-8" } });
}
