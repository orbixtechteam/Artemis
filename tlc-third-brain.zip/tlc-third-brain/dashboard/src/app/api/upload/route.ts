import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { MAX_BYTES, saveUpload } from "@/lib/files";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const u = await currentUser();
  if (!u) return NextResponse.json({ error: "Sign in to continue." }, { status: 401 });
  const form = await req.formData().catch(() => null);
  const files = (form?.getAll("files") ?? []).filter((f): f is File => f instanceof File);
  if (!files.length) return NextResponse.json({ error: "No file received." }, { status: 400 });
  const out = [];
  for (const f of files) {
    if (f.size > MAX_BYTES) return NextResponse.json({ error: `${f.name} is larger than 25 MB.` }, { status: 413 });
    const a = await saveUpload(u.id, f.name || "pasted-file", f.type, Buffer.from(await f.arrayBuffer()));
    out.push({ id: a.id, name: a.name, mime: a.mime, size: a.size });
  }
  return NextResponse.json({ files: out });
}
