import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { appUrl, rememberAppUrl } from "@/lib/appurl";
import { startOAuth } from "@/lib/user-mcp";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  rememberAppUrl(req);
  const u = await currentUser();
  if (!u) return NextResponse.redirect(`${appUrl()}/login?next=/settings`);
  const id = Number(new URL(req.url).searchParams.get("id"));
  const s = await prisma.userMcpServer.findUnique({ where: { id } });
  if (!s || s.userId !== u.id) return NextResponse.redirect(`${appUrl()}/settings?connect_error=${encodeURIComponent("Server not found.")}#connections`);
  try {
    return NextResponse.redirect(await startOAuth(id));
  } catch (e) {
    await prisma.userMcpServer.update({ where: { id }, data: { status: "error", lastError: (e as Error).message.slice(0, 300) } });
    return NextResponse.redirect(`${appUrl()}/settings?connect_error=${encodeURIComponent(`${s.name}: ${(e as Error).message}`)}#connections`);
  }
}
