import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { logActivity } from "@/lib/db";
import { appUrl } from "@/lib/appurl";
import { finishOAuth } from "@/lib/user-mcp";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const u = await currentUser();
  if (!u) return NextResponse.redirect(`${appUrl()}/login?next=/settings`);
  const q = new URL(req.url).searchParams;
  const back = (key: string, msg: string) => NextResponse.redirect(`${appUrl()}/settings?${key}=${encodeURIComponent(msg)}#connections`);
  if (q.get("error")) return back("connect_error", `Sign-in cancelled or failed: ${q.get("error")}`);
  try {
    const name = await finishOAuth(u.id, q.get("state") ?? "", q.get("code") ?? "");
    await logActivity(u.name, "connected MCP server", "connections", null, name);
    return back("connected", name);
  } catch (e) {
    return back("connect_error", (e as Error).message);
  }
}
