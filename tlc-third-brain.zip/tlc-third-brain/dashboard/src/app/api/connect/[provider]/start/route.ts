import crypto from "node:crypto";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { PROVIDERS, type Provider } from "@/lib/connections";
import { appUrl, rememberAppUrl } from "@/lib/appurl";

export const dynamic = "force-dynamic";

export async function GET(req: Request, { params }: { params: Promise<{ provider: string }> }) {
  rememberAppUrl(req);
  const provider = (await params).provider as Provider;
  const u = await currentUser();
  if (!u) return NextResponse.redirect(`${appUrl()}/login?next=/settings`);
  if (!(provider in PROVIDERS)) return NextResponse.json({ error: "Unknown connection." }, { status: 404 });
  if (!PROVIDERS[provider].configured()) return NextResponse.redirect(`${appUrl()}/settings?connect_error=${encodeURIComponent(`${PROVIDERS[provider].label} isn't set up on the server yet. Ask Ulvi.`)}`);
  const state = crypto.randomBytes(16).toString("hex");
  (await cookies()).set(`connect_${provider}`, state, { httpOnly: true, sameSite: "lax", secure: appUrl().startsWith("https"), maxAge: 600, path: "/" });
  // ?add=1: connecting another account, so let them pick it instead of pre-filling their own email
  const another = new URL(req.url).searchParams.get("add") === "1";
  return NextResponse.redirect(PROVIDERS[provider].authUrl(state, another ? "" : u.email));
}
