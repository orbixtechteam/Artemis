import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { currentUser } from "@/lib/auth";
import { logActivity } from "@/lib/db";
import { finishConnect, PROVIDERS, type Provider } from "@/lib/connections";
import { appUrl } from "@/lib/appurl";

export const dynamic = "force-dynamic";

export async function GET(req: Request, { params }: { params: Promise<{ provider: string }> }) {
  const provider = (await params).provider as Provider;
  const url = new URL(req.url);
  const back = (msg: string, ok = false) => NextResponse.redirect(`${appUrl()}/settings?${ok ? "connected" : "connect_error"}=${encodeURIComponent(msg)}#connections`);
  const u = await currentUser();
  if (!u) return NextResponse.redirect(`${appUrl()}/login?next=/settings`);
  if (!(provider in PROVIDERS)) return back("Unknown connection.");
  const jar = await cookies();
  const expected = jar.get(`connect_${provider}`)?.value;
  jar.delete(`connect_${provider}`);
  if (url.searchParams.get("error")) return back(`You cancelled or the sign-in failed: ${url.searchParams.get("error")}`);
  if (!expected || expected !== url.searchParams.get("state")) return back("The sign-in link expired. Try again.");
  try {
    await finishConnect(provider, u.id, url.searchParams.get("code") ?? "");
    await logActivity(u.name, "connected", "connections", null, PROVIDERS[provider].label);
    return back(PROVIDERS[provider].label, true);
  } catch (e) {
    return back((e as Error).message);
  }
}
