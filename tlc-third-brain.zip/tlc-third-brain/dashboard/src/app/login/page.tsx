"use client";

import { Suspense, useActionState } from "react";
import { useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { loginAction } from "@/lib/actions";

export default function LoginPage() {
  return <Suspense><LoginForm /></Suspense>;
}

function LoginForm() {
  const next = useSearchParams().get("next") ?? "";
  const [state, action, pending] = useActionState(loginAction, null);
  return (
    <main className="grid min-h-screen place-items-center p-6">
      <form action={action} className="grid w-full max-w-sm gap-5 rounded-xl border bg-card p-8 shadow-sm">
        <input type="hidden" name="next" value={next} />
        <div className="grid gap-1.5">
          <h1 className="text-4xl font-extrabold tracking-tight">Third Brain</h1>
          <p className="text-muted-foreground">The Longevity Clinic&apos;s map of departments, playbooks, rules and knowledge.</p>
        </div>
        <div className="grid gap-2"><Label htmlFor="email">Email</Label><Input id="email" name="email" type="email" autoComplete="username" required /></div>
        <div className="grid gap-2"><Label htmlFor="password">Password</Label><Input id="password" name="password" type="password" autoComplete="current-password" required /></div>
        {state?.error && <p role="alert" className="text-sm text-destructive">{state.error}</p>}
        <Button type="submit" disabled={pending}>{pending ? "Signing in" : "Sign in"}</Button>
      </form>
    </main>
  );
}
