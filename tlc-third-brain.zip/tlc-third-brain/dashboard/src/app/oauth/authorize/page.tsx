import { redirect } from "next/navigation";
import { ConsentForm } from "@/components/consent-form";
import { currentUser } from "@/lib/auth";
import { ROLES } from "@/lib/constants";
import { prisma } from "@/lib/db";

export const metadata = { title: "Connect an app · Third Brain" };
type P = Record<string, string | undefined>;

export default async function AuthorizePage({ searchParams }: { searchParams: Promise<P> }) {
  const q = await searchParams;
  const u = await currentUser();
  if (!u) redirect(`/login?next=${encodeURIComponent(`/oauth/authorize?${new URLSearchParams(q as Record<string, string>)}`)}`);
  const client = q.client_id ? await prisma.oAuthClient.findUnique({ where: { id: q.client_id } }) : null;
  const uris = client ? (JSON.parse(client.redirectUris) as string[]) : [];
  const problem =
    q.response_type !== "code" ? "This request is not an authorization code request."
    : !client ? "This app isn't registered. Remove the connector and add it again."
    : !q.redirect_uri || !uris.includes(q.redirect_uri) ? "The app's return address doesn't match its registration."
    : !q.code_challenge || (q.code_challenge_method ?? "S256") !== "S256" ? "The app didn't use a secure (PKCE S256) request."
    : null;

  return (
    <main className="grid min-h-screen place-items-center p-6">
      <div className="grid w-full max-w-md gap-5 rounded-xl border bg-card p-8 shadow-sm">
        <div className="grid gap-1.5">
          <h1 className="text-3xl font-extrabold tracking-tight">Connect {client?.name ?? "an app"}</h1>
          <p className="text-muted-foreground">to Third Brain as <strong className="text-foreground">{u.name}</strong> ({ROLES[u.role].split(":")[0].toLowerCase()}).</p>
        </div>
        {problem ? <p role="alert" className="text-sm text-destructive">{problem}</p> : (
          <>
            <ul className="grid gap-2 text-sm">
              <li>It can read and change what you can: departments, playbooks, rules, lessons, knowledge, workflows, files and, for admins, people and Jarvis&apos;s memory.</li>
              <li>It works with your permissions only, and deleting anything always asks you first.</li>
              <li>You can disconnect it any time in Settings.</li>
            </ul>
            <ConsentForm params={{ client_id: q.client_id!, redirect_uri: q.redirect_uri!, code_challenge: q.code_challenge!, state: q.state ?? "", scope: q.scope ?? "mcp", resource: q.resource ?? "" }} />
          </>
        )}
      </div>
    </main>
  );
}
