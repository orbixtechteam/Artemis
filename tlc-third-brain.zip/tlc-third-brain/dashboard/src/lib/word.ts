import "server-only";
import { AlignmentType, BorderStyle, Document, Footer, HeadingLevel, LevelFormat, Packer, PageNumber, Paragraph, ShadingType, Table, TableCell, TableRow, TextRun, WidthType } from "docx";

/**
 * Markdown-ish text → a clean Word document: # / ## / ### headings, - bullets, 1. numbered lists,
 * | tables |, **bold**, and paragraphs. A4, Arial, page numbers.
 */
const FONT = "Arial";
const BRAND = "2F5D50";

function runs(text: string, base: { bold?: boolean; size?: number; color?: string } = {}) {
  return text.split(/(\*\*[^*]+\*\*)/g).filter(Boolean).map((part) =>
    part.startsWith("**") && part.endsWith("**")
      ? new TextRun({ text: part.slice(2, -2), bold: true, font: FONT, size: base.size, color: base.color })
      : new TextRun({ text: part, bold: base.bold, font: FONT, size: base.size, color: base.color }));
}

function table(rows: string[][]) {
  const cols = Math.max(...rows.map((r) => r.length));
  const width = 9026; // A4 with 1" margins, in twentieths of a point
  const colW = Math.floor(width / cols);
  const border = { style: BorderStyle.SINGLE, size: 4, color: "C9D3CF" };
  return new Table({
    width: { size: width, type: WidthType.DXA },
    columnWidths: Array(cols).fill(colW),
    rows: rows.map((r, i) => new TableRow({
      tableHeader: i === 0,
      children: Array.from({ length: cols }, (_, j) => new TableCell({
        width: { size: colW, type: WidthType.DXA },
        borders: { top: border, bottom: border, left: border, right: border },
        margins: { top: 80, bottom: 80, left: 120, right: 120 },
        shading: i === 0 ? { fill: "E8EFEC", type: ShadingType.CLEAR, color: "auto" } : undefined,
        children: [new Paragraph({ children: runs(r[j] ?? "", { bold: i === 0, size: 20 }) })],
      })),
    })),
  });
}

export async function buildWord(title: string, markdown: string, subtitle?: string): Promise<Buffer> {
  const body: (Paragraph | Table)[] = [
    new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun({ text: title, font: FONT, size: 44, bold: true, color: BRAND })], spacing: { after: 120 } }),
  ];
  if (subtitle) body.push(new Paragraph({ children: [new TextRun({ text: subtitle, font: FONT, size: 22, color: "6B7672" })], spacing: { after: 360 } }));
  const lines = markdown.replace(/\r/g, "").split("\n");
  let tbl: string[][] = [];
  const flushTable = () => { if (tbl.length) { body.push(table(tbl)); body.push(new Paragraph({ children: [] })); tbl = []; } };
  for (const raw of lines) {
    const line = raw.trimEnd();
    if (/^\s*\|.*\|\s*$/.test(line)) {
      if (/^\s*\|[\s:|-]+\|\s*$/.test(line)) continue; // separator row
      tbl.push(line.trim().slice(1, -1).split("|").map((c) => c.trim()));
      continue;
    }
    flushTable();
    if (!line.trim()) continue;
    const h = line.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      const level = [HeadingLevel.HEADING_1, HeadingLevel.HEADING_2, HeadingLevel.HEADING_3][h[1].length - 1];
      body.push(new Paragraph({ heading: level, children: runs(h[2], { bold: true, size: [32, 26, 23][h[1].length - 1], color: h[1].length === 1 ? BRAND : undefined }),
        spacing: { before: h[1].length === 1 ? 360 : 240, after: 120 } }));
      continue;
    }
    const b = line.match(/^\s*[-*•]\s+(.*)$/);
    if (b) { body.push(new Paragraph({ numbering: { reference: "bullets", level: 0 }, children: runs(b[1], { size: 22 }), spacing: { after: 60 } })); continue; }
    const n = line.match(/^\s*\d+[.)]\s+(.*)$/);
    if (n) { body.push(new Paragraph({ numbering: { reference: "numbers", level: 0 }, children: runs(n[1], { size: 22 }), spacing: { after: 60 } })); continue; }
    body.push(new Paragraph({ children: runs(line, { size: 22 }), spacing: { after: 140, line: 300 } }));
  }
  flushTable();
  const doc = new Document({
    creator: "Third Brain", title,
    styles: { default: { document: { run: { font: FONT, size: 22 } } } },
    numbering: { config: [
      { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
      { reference: "numbers", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
    ] },
    sections: [{
      properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
        new TextRun({ text: "The Longevity Clinic · ", font: FONT, size: 16, color: "8A938F" }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: "8A938F" })] })] }) },
      children: body,
    }],
  });
  return Packer.toBuffer(doc);
}
