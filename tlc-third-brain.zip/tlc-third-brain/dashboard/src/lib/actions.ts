"use server";

import crypto from "node:crypto";
import { revalidatePath } from "next/cache";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";
import { prisma, logActivity } from "./db";
import {
  canEdit, checkPassword, createSession, currentUser, destroySession, hashPassword, inScope, isAdmin, randomPassword,
} from "./auth";
import { SCHEMAS } from "./schemas";
import type { EntityKey } from "./fields";
import { slugify } from "./utils";
import { runSync } from "./sync";

export type ActionResult = { ok: boolean; error?: string; password?: string | null; link?: string };

// ---------- sign in / out ----------
const attempts = new Map<string, number[]>();

export async function loginAction(_: ActionResult | null, form: FormData): Promise<ActionResult> {
  const ip = (await headers()).get("x-forwarded-for") ?? "local";
  const now = Date.now();
  const recent = (attempts.get(ip) ?? []).filter((t) => now - t < 15 * 60_000);
  if (recent.length >= 10) return { ok: false, error: "Too many attempts. Try again in 15 minutes." };

  const email = String(form.get("email") ?? "").toLowerCase().trim();
  const password = String(form.get("password") ?? "");
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !user.active || !(await checkPassword(password, user.passwordHash))) {
    attempts.set(ip, [...recent, now]);
    return { ok: false, error: "Email or password is wrong." };
  }
  attempts.delete(ip);
  await createSession(user.id);
  await prisma.user.update({ where: { id: user.id }, data: { lastLogin: new Date() } });
  if (!user.lastLogin) { const { notifyFirstLogin } = await import("./invites"); void notifyFirstLogin(user.name, user.email); }
  await logActivity(user.name, "signed in");
  const next = String(form.get("next") ?? "");
  redirect(next.startsWith("/") && !next.startsWith("//") ? next : "/");
}

export async function logoutAction() {
  await destroySession();
  redirect("/login");
}

// ---------- generic CRUD ----------
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const model = (e: EntityKey): any => ({
  departments: prisma.department, playbooks: prisma.playbook, rules: prisma.rule,
  lessons: prisma.lesson, knowledge: prisma.knowledge, automations: prisma.automation,
}[e]);

const titleOf = (r: Record<string, unknown>) => String(r.name ?? r.text ?? r.what ?? "");

export async function saveEntity(entity: EntityKey, id: number | null, values: Record<string, unknown>): Promise<ActionResult> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  if (!canEdit(u)) return { ok: false, error: "Your role can only view." };
  if (entity === "departments" && !isAdmin(u)) return { ok: false, error: "Only admins change departments." };
  if (entity === "automations" && !isAdmin(u)) return { ok: false, error: "Only admins change automations." };

  const parsed = SCHEMAS[entity].safeParse(values);
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? "Check the fields." };
  const data = parsed.data as Record<string, unknown>;

  if ("departmentId" in data && !inScope(u, data.departmentId as number | null)) return { ok: false, error: "Choose one of your departments." };

  try {
    if (id) {
      const row = await model(entity).findUnique({ where: { id } });
      if (!row) return { ok: false, error: "Not found." };
      if ("departmentId" in row && !inScope(u, row.departmentId)) return { ok: false, error: "This belongs to a department you can't edit." };
      await model(entity).update({ where: { id }, data });
      await logActivity(u.name, "updated", entity, id, titleOf(data));
    } else {
      if (entity === "playbooks") data.slug = `${slugify(String(data.name))}-${Math.random().toString(16).slice(2, 6)}`;
      const row = await model(entity).create({ data });
      await logActivity(u.name, "created", entity, row.id, titleOf(data));
    }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message.split("\n").pop() : "Couldn't save." };
  }
  revalidatePath("/", "layout");
  return { ok: true };
}

export async function deleteEntity(entity: EntityKey, id: number): Promise<ActionResult> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins delete." };
  const row = await model(entity).findUnique({ where: { id } });
  if (!row) return { ok: false, error: "Not found." };
  await model(entity).delete({ where: { id } });
  await logActivity(u.name, "deleted", entity, id, titleOf(row));
  revalidatePath("/", "layout");
  return { ok: true };
}

// ---------- account ----------
export async function changePassword(current: string, next: string): Promise<ActionResult> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  const row = await prisma.user.findUniqueOrThrow({ where: { id: u.id } });
  if (!(await checkPassword(current, row.passwordHash))) return { ok: false, error: "Current password is wrong." };
  if (next.length < 10) return { ok: false, error: "Use at least 10 characters." };
  await prisma.user.update({ where: { id: u.id }, data: { passwordHash: await hashPassword(next) } });
  await logActivity(u.name, "changed password");
  return { ok: true };
}

// ---------- people ----------
const personSchema = z.object({
  id: z.number().int().optional(),
  name: z.string().trim().min(1, "Fill in the name."),
  email: z.string().trim().toLowerCase().email("Use a valid email.").optional(),
  role: z.enum(["owner", "admin", "editor", "viewer"]).optional(),
  departments: z.array(z.number().int()).default([]),
  active: z.boolean().optional(),
  password: z.string().optional(),
  whatsapp: z.boolean().optional(),
});

export async function savePerson(input: z.input<typeof personSchema>): Promise<ActionResult> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins manage people." };
  const p = personSchema.safeParse(input);
  if (!p.success) return { ok: false, error: p.error.issues[0]?.message };
  const d = p.data;

  if (!d.id) {
    if (!d.email) return { ok: false, error: "Email is required." };
    if (!d.role || d.role === "owner") return { ok: false, error: "Choose admin, editor or viewer." };
    const pw = randomPassword(); // always generated; never typed by an admin
    try {
      const created = await prisma.user.create({ data: {
        name: d.name, email: d.email, role: d.role, departments: JSON.stringify(d.departments), passwordHash: await hashPassword(pw),
        whatsapp: u.role === "owner" ? !!d.whatsapp : false,
      } });
      await logActivity(u.name, "added person", "users", created.id, `${d.name} (${d.role})`);
      const { createPasswordLink } = await import("./invites");
      const link = await createPasswordLink(created.id, "invite");
      revalidatePath("/settings");
      return { ok: true, link };
    } catch {
      return { ok: false, error: "Someone already uses this email." };
    }
  }

  const target = await prisma.user.findUnique({ where: { id: d.id } });
  if (!target) return { ok: false, error: "Not found." };
  if (target.role === "owner") {
    if (u.role !== "owner") return { ok: false, error: "Only the owner edits the owner." };
    await prisma.user.update({ where: { id: d.id }, data: { name: d.name } });
  } else {
    if (d.role === "owner") return { ok: false, error: "There is one owner." };
    await prisma.user.update({ where: { id: d.id }, data: {
      name: d.name, role: d.role ?? target.role, departments: JSON.stringify(d.departments), active: d.active ?? target.active,
      ...(u.role === "owner" && d.whatsapp !== undefined ? { whatsapp: d.whatsapp } : {}),
    } });
    if (d.active === false) await prisma.session.deleteMany({ where: { userId: d.id } });
  }
  await logActivity(u.name, "updated person", "users", d.id, d.name);
  revalidatePath("/settings");
  return { ok: true };
}

export async function resetPassword(id: number): Promise<ActionResult> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins reset passwords." };
  const target = await prisma.user.findUnique({ where: { id } });
  if (!target) return { ok: false, error: "Not found." };
  if (target.role === "owner" && u.role !== "owner") return { ok: false, error: "Only the owner resets the owner." };
  // The old password stops working; they choose a new one through a one-time link.
  await prisma.user.update({ where: { id }, data: { passwordHash: await hashPassword(randomPassword()) } });
  await prisma.session.deleteMany({ where: { userId: id } });
  const { createPasswordLink } = await import("./invites");
  const link = await createPasswordLink(id, "reset");
  await logActivity(u.name, "sent a new password link", "users", id, target.name);
  return { ok: true, link };
}

// ---------- sync ----------
export async function runSyncAction(): Promise<ActionResult & { report?: unknown }> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins run a sync." };
  const report = await runSync(u.name);
  revalidatePath("/", "layout");
  return { ok: !report.errors.length, error: report.errors.join("; ") || undefined, report };
}

// ---------- departments (Settings) ----------
const deptSchema = z.object({
  id: z.number().int().optional(),
  name: z.string().trim().min(1, "Fill in the name."),
  owner: z.string().trim().default(""),
  agent: z.string().trim().default(""),
  description: z.string().trim().default(""),
  parentId: z.number().int().nullable().optional(),
  members: z.array(z.number().int()).default([]),
});

export async function saveDepartment(input: z.input<typeof deptSchema>): Promise<ActionResult> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins manage departments." };
  const p = deptSchema.safeParse(input);
  if (!p.success) return { ok: false, error: p.error.issues[0]?.message };
  const { id, members, parentId, ...rest } = p.data;
  if (id && parentId === id) return { ok: false, error: "A department can't be its own parent." };
  const data = { ...rest, parentId: parentId ?? null };
  const dept = id
    ? await prisma.department.update({ where: { id }, data })
    : await prisma.department.create({ data: { ...data, position: ((await prisma.department.aggregate({ _max: { position: true } }))._max.position ?? 0) + 1 } });
  for (const x of await prisma.user.findMany({ where: { role: { in: ["editor", "viewer"] } } })) {
    const set = new Set<number>(JSON.parse(x.departments));
    const want = members.includes(x.id);
    if (want === set.has(dept.id)) continue;
    if (want) set.add(dept.id); else set.delete(dept.id);
    await prisma.user.update({ where: { id: x.id }, data: { departments: JSON.stringify([...set]) } });
  }
  await logActivity(u.name, id ? "updated" : "created", "departments", dept.id, dept.name);
  revalidatePath("/", "layout");
  return { ok: true };
}

export async function removeDepartment(id: number): Promise<ActionResult> {
  return deleteEntity("departments", id);
}

// ---------- API tokens for the MCP server ----------
export async function createApiToken(name: string): Promise<ActionResult & { token?: string }> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  const clean = name.trim() || "Claude";
  const token = `tb_${crypto.randomBytes(24).toString("base64url")}`;
  const { hashToken } = await import("./mcp");
  await prisma.apiToken.create({ data: { userId: u.id, name: clean, tokenHash: hashToken(token) } });
  await logActivity(u.name, "created API token", "tokens", null, clean);
  revalidatePath("/settings");
  return { ok: true, token };
}

export async function revokeApiToken(id: number): Promise<ActionResult> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  const t = await prisma.apiToken.findUnique({ where: { id } });
  if (!t || (t.userId !== u.id && !isAdmin(u))) return { ok: false, error: "Not found." };
  await prisma.apiToken.delete({ where: { id } });
  await logActivity(u.name, "revoked API token", "tokens", id, t.name);
  revalidatePath("/settings");
  return { ok: true };
}

// ---------- system status ----------
export async function refreshStatusAction(): Promise<ActionResult> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins check the system." };
  const { collectStatus } = await import("./status");
  await collectStatus(true);
  revalidatePath("/system");
  return { ok: true };
}

export async function runJobAction(ref: string): Promise<ActionResult> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins run jobs." };
  const { runJobNow } = await import("./status");
  const r = await runJobNow(ref);
  await logActivity(u.name, "ran job now", "automations", null, ref);
  return { ok: r.ok, error: r.ok ? undefined : r.message };
}

// ---------- chat history ----------
export async function renameConversation(id: number, title: string): Promise<ActionResult> {
  const u = await currentUser();
  const c = u ? await prisma.conversation.findUnique({ where: { id } }) : null;
  if (!u || !c || c.userId !== u.id) return { ok: false, error: "Not found." };
  await prisma.conversation.update({ where: { id }, data: { title: title.trim().slice(0, 80) || c.title } });
  revalidatePath("/chat", "layout");
  return { ok: true };
}

export async function deleteConversation(id: number): Promise<ActionResult> {
  const u = await currentUser();
  const c = u ? await prisma.conversation.findUnique({ where: { id } }) : null;
  if (!u || !c || c.userId !== u.id) return { ok: false, error: "Not found." };
  await prisma.conversation.delete({ where: { id } });
  revalidatePath("/chat", "layout");
  return { ok: true };
}

// ---------- approvals (outbox) ----------
const outboxEdit = z.object({ toAddr: z.string().optional(), cc: z.string().optional(), subject: z.string().optional(), body: z.string().min(1).optional(), sendAs: z.enum(["bot", "me"]).optional() });

/** Who may decide on a queued message: emails → the mailbox's owner or Noah; Slack → admins. Never the AI. */
async function mayDecide(u: { id: number; role: string }, m: { channel: string; fromUserId: number | null }) {
  if (u.role === "owner") return true;
  if (m.channel === "gmail") return m.fromUserId === u.id;
  return u.role === "admin";
}

export async function approveOutbox(id: number, edits: z.input<typeof outboxEdit>): Promise<ActionResult> {
  const u = await currentUser();
  const m = await prisma.outbox.findUnique({ where: { id } });
  if (!u || !m) return { ok: false, error: "Not found." };
  if (!(await mayDecide(u, m))) return { ok: false, error: m.channel === "gmail" ? "Only the person whose mailbox this is (or Noah) can send it." : "Only an admin approves Slack posts." };
  if (m.status !== "pending") return { ok: false, error: "This message is no longer waiting." };
  const e = outboxEdit.parse(edits);
  const next = { toAddr: e.toAddr ?? m.toAddr, cc: e.cc ?? m.cc, subject: e.subject ?? m.subject, body: e.body ?? m.body };
  const edited = next.toAddr !== m.toAddr || next.cc !== m.cc || next.subject !== m.subject || next.body.trim() !== m.body.trim();
  const { sendGmail, sendSlack } = await import("./send");
  try {
    if (m.channel === "gmail") {
      const owner = await prisma.user.findFirst({ where: { role: "owner" } });
      const sender = m.fromUserId ?? owner?.id ?? u.id;
      const { listConnections, myEmailSend } = await import("./connections");
      if ((await listConnections(sender)).some((c) => c.provider === "google")) await myEmailSend(sender, { to: next.toAddr, cc: next.cc, subject: next.subject, body: next.body, threadId: m.threadId || undefined });
      else if (sender === owner?.id) await sendGmail({ to: next.toAddr, cc: next.cc, subject: next.subject, body: next.body, threadId: m.threadId || undefined });
      else throw new Error("This person hasn't connected their Google account (Settings → My connections).");
    }
    else if (edits.sendAs === "me") {
      const { mySlackSend } = await import("./connections");
      await mySlackSend(u.id, m.slackChannel, next.body, m.slackThreadTs || undefined);
    } else await sendSlack({ channel: m.slackChannel, text: next.body, threadTs: m.slackThreadTs || undefined });
  } catch (err) {
    await prisma.outbox.update({ where: { id }, data: { ...next, edited, status: "failed", error: (err as Error).message.slice(0, 500), decidedBy: u.name, decidedAt: new Date() } });
    revalidatePath("/approvals");
    return { ok: false, error: (err as Error).message };
  }
  await prisma.outbox.update({ where: { id }, data: { ...next, edited, status: "sent", error: "", decidedBy: u.name, decidedAt: new Date() } });
  await logActivity(u.name, edited ? "edited and sent" : "approved and sent", "outbox", id, `${m.channel}: ${next.subject || next.body.slice(0, 60)}`);
  revalidatePath("/approvals");
  return { ok: true };
}

export async function rejectOutbox(id: number, reason: string): Promise<ActionResult> {
  const u = await currentUser();
  const m = await prisma.outbox.findUnique({ where: { id } });
  if (!u || !m) return { ok: false, error: "Not found." };
  if (!(await mayDecide(u, m))) return { ok: false, error: "You can't decide on this message." };
  if (m.status !== "pending") return { ok: false, error: "This message is no longer waiting." };
  await prisma.outbox.update({ where: { id }, data: { status: "rejected", error: reason.slice(0, 500), decidedBy: u.name, decidedAt: new Date() } });
  if (m.playbook && reason.trim()) {
    const { runTool } = await import("./ops");
    await runTool(u, "create_lesson", { playbook: m.playbook, what: `Draft ${m.channel === "gmail" ? "email" : "Slack message"} rejected: ${(m.subject || m.body).slice(0, 80)}`, reason: reason.trim(), fix: "" });
  }
  await logActivity(u.name, "rejected", "outbox", id, reason);
  revalidatePath("/approvals");
  return { ok: true };
}

// ---------- OAuth consent (Claude "Connect") ----------
export async function oauthDecision(params: { client_id: string; redirect_uri: string; code_challenge: string; state: string; scope: string; resource: string }, allow: boolean): Promise<ActionResult & { redirect?: string }> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in first." };
  const client = await prisma.oAuthClient.findUnique({ where: { id: params.client_id } });
  if (!client || !(JSON.parse(client.redirectUris) as string[]).includes(params.redirect_uri)) return { ok: false, error: "Unknown app or redirect address." };
  const url = new URL(params.redirect_uri);
  if (params.state) url.searchParams.set("state", params.state);
  if (!allow) { url.searchParams.set("error", "access_denied"); return { ok: true, redirect: url.toString() }; }
  const { randomToken, sha256 } = await import("./oauth");
  const code = randomToken("tbx");
  await prisma.oAuthCode.create({ data: { codeHash: sha256(code), clientId: client.id, userId: u.id, redirectUri: params.redirect_uri, codeChallenge: params.code_challenge, scope: params.scope || "mcp", resource: params.resource, expiresAt: new Date(Date.now() + 5 * 60_000) } });
  await logActivity(u.name, "connected app", "oauth", null, client.name);
  url.searchParams.set("code", code);
  return { ok: true, redirect: url.toString() };
}

export async function revokeOAuthClient(clientId: string): Promise<ActionResult> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  await prisma.oAuthToken.deleteMany({ where: { clientId, ...(isAdmin(u) ? {} : { userId: u.id }) } });
  await logActivity(u.name, "disconnected app", "oauth", null, clientId);
  revalidatePath("/settings");
  return { ok: true };
}

export async function getOutboxItem(id: number) {
  const u = await currentUser();
  if (!u) return null;
  const m = await prisma.outbox.findUnique({ where: { id } });
  if (!m) return null;
  return { id: m.id, channel: m.channel, toAddr: m.toAddr, cc: m.cc, subject: m.subject, body: m.body, slackChannel: m.slackChannel,
    status: m.status, decidedBy: m.decidedBy, error: m.error, canDecide: await mayDecide(u, m) };
}

export async function disconnectMine(provider: "google" | "slack", id?: number): Promise<ActionResult> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  const { disconnect } = await import("./connections");
  await disconnect(u.id, provider, id);
  await logActivity(u.name, "disconnected", "connections", null, provider);
  revalidatePath("/settings");
  return { ok: true };
}

// ---------- set-your-own-password links ----------
export async function setPasswordWithLink(token: string, password: string, again: string): Promise<ActionResult> {
  const { checkPasswordLink, usePasswordLink, notifyFirstLogin } = await import("./invites");
  const t = await checkPasswordLink(token);
  if (!t) return { ok: false, error: "This link has expired or was already used. Ask for a new one." };
  if (password.length < 10) return { ok: false, error: "Use at least 10 characters." };
  if (password !== again) return { ok: false, error: "The two passwords don't match." };
  await prisma.user.update({ where: { id: t.user.id }, data: { passwordHash: await hashPassword(password), lastLogin: new Date() } });
  await prisma.session.deleteMany({ where: { userId: t.user.id } });
  await usePasswordLink(token);
  await createSession(t.user.id);
  await logActivity(t.user.name, t.purpose === "invite" ? "set their password and signed in" : "reset their password", "users", t.user.id, t.user.email);
  if (!t.user.lastLogin) void notifyFirstLogin(t.user.name, t.user.email);
  redirect("/");
}

/** Settings: a fresh one-time link for someone (instead of a password). */
export async function passwordLinkFor(id: number): Promise<ActionResult & { link?: string; name?: string; email?: string }> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins send access links." };
  const target = await prisma.user.findUnique({ where: { id } });
  if (!target) return { ok: false, error: "Not found." };
  if (target.role === "owner" && u.role !== "owner") return { ok: false, error: "Only the owner resets the owner." };
  const { createPasswordLink } = await import("./invites");
  const link = await createPasswordLink(id, target.lastLogin ? "reset" : "invite");
  await logActivity(u.name, "created access link", "users", id, target.email);
  return { ok: true, link, name: target.name, email: target.email };
}

// ---------- personal MCP servers ----------
export async function addMcpServer(name: string, url: string, apiKey?: string, client?: { id: string; secret?: string }): Promise<ActionResult & { signIn?: string }> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  if (!name.trim() || !url.trim()) return { ok: false, error: "Give it a name and an address." };
  try {
    const { addUserMcp } = await import("./user-mcp");
    const r = await addUserMcp(u.id, name, url.trim(), apiKey?.trim() || undefined, client?.id ? client : undefined);
    await logActivity(u.name, "added MCP server", "connections", r.id, name);
    revalidatePath("/settings");
    return { ok: true, signIn: r.signIn };
  } catch (e) {
    return { ok: false, error: (e as Error).message };
  }
}

export async function removeMcpServer(id: number): Promise<ActionResult> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  await prisma.userMcpServer.deleteMany({ where: { id, userId: u.id } });
  revalidatePath("/settings");
  return { ok: true };
}

// ---------- WhatsApp numbers (owner only) ----------
const NOAH_WHATSAPP = () => (process.env.NOAH_WHATSAPP || "+34673555075").replace(/[^\d+]/g, "");

export async function saveWhatsappNumber(input: { id?: number; phone: string; label: string; readers: number[]; senders: number[] }): Promise<ActionResult> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins and Noah assign WhatsApp numbers." };
  const phone = input.phone.replace(/[^\d+]/g, "");
  const before = input.id ? await prisma.whatsappNumber.findUnique({ where: { id: input.id } }) : null;
  if (u.role !== "owner" && (phone === NOAH_WHATSAPP() || before?.phone === NOAH_WHATSAPP())) return { ok: false, error: "Only Noah decides who uses his own number." };
  if (phone.length < 6 || !input.label.trim()) return { ok: false, error: "Give the number and a label." };
  const data = { phone, label: input.label.trim(), readers: JSON.stringify(input.readers), senders: JSON.stringify(input.senders) };
  try {
    if (input.id) await prisma.whatsappNumber.update({ where: { id: input.id }, data });
    else await prisma.whatsappNumber.create({ data });
  } catch { return { ok: false, error: "That number already exists." }; }
  await logActivity(u.name, "saved WhatsApp number", "whatsapp", input.id ?? null, `${data.label} ${phone}`);
  revalidatePath("/settings");
  return { ok: true };
}

export async function deleteWhatsappNumber(id: number): Promise<ActionResult> {
  const u = await currentUser();
  if (!u || !isAdmin(u)) return { ok: false, error: "Only admins and Noah manage WhatsApp numbers." };
  const n = await prisma.whatsappNumber.findUnique({ where: { id } });
  if (u.role !== "owner" && n?.phone === NOAH_WHATSAPP()) return { ok: false, error: "Only Noah can remove his own number." };
  await prisma.whatsappNumber.delete({ where: { id } }).catch(() => null);
  revalidatePath("/settings");
  return { ok: true };
}

// ---------- SKILL.md editor on the playbook page (same rules as the chat tools) ----------
export async function skillFor(playbookId: number): Promise<{ ok: boolean; error?: string; approved?: string | null; proposed?: string | null; canEdit?: boolean }> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  const { runTool } = await import("./ops");
  const r = await runTool(u, "read_skill", { playbook: playbookId });
  const edit = canEdit(u) && inScope(u, (await prisma.playbook.findUnique({ where: { id: playbookId } }))?.departmentId ?? null);
  if (!r.ok) return { ok: true, approved: null, proposed: null, canEdit: edit };
  const x = r.result as { approved: string | null; proposed: string | null };
  return { ok: true, approved: x.approved, proposed: x.proposed, canEdit: edit };
}

export async function saveSkill(playbookId: number, content: string, reason: string): Promise<ActionResult> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  const { runTool } = await import("./ops");
  const r = await runTool(u, "update_skill", { playbook: playbookId, content, reason: reason || "Edited in the dashboard" });
  revalidatePath(`/playbooks/${playbookId}`);
  return r.ok ? { ok: true } : { ok: false, error: r.error };
}

export async function approveSkill(playbookId: number): Promise<ActionResult> {
  const u = await currentUser();
  if (!u) return { ok: false, error: "Sign in to continue." };
  const { runTool } = await import("./ops");
  const r = await runTool(u, "approve_playbook", { playbook: playbookId, confirmed: true });
  revalidatePath(`/playbooks/${playbookId}`);
  return r.ok ? { ok: true } : { ok: false, error: r.error };
}
