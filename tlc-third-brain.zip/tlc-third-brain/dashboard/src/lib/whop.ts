import "server-only";
import crypto from "node:crypto";
import { prisma, logActivity } from "./db";

/**
 * Whop (v1 API): payment links, plan edits, payments, and the payment webhook.
 * Keys live only in .env: WHOP_API_KEY (Account API key), WHOP_COMPANY_ID (biz_...), WHOP_WEBHOOK_SECRET (ws_...).
 */
const API = process.env.WHOP_API_BASE || "https://api.whop.com/api/v1";

export function whopReady() {
  return !!process.env.WHOP_API_KEY;
}

async function whop(method: string, path: string, body?: unknown) {
  if (!process.env.WHOP_API_KEY) throw new Error("Whop isn't connected yet (WHOP_API_KEY on the server).");
  for (let i = 0; i < 3; i++) {
    const r = await fetch(`${API}${path}`, { method, headers: { authorization: `Bearer ${process.env.WHOP_API_KEY}`, "content-type": "application/json" },
      ...(body ? { body: JSON.stringify(body) } : {}) });
    if ((r.status === 429 || r.status >= 500) && i < 2) { await new Promise((res) => setTimeout(res, 1500 * (i + 1))); continue; }
    const text = await r.text();
    const data = text ? JSON.parse(text) : {};
    if (!r.ok) throw new Error(`Whop ${r.status}: ${(data.error?.message ?? data.message ?? text).toString().slice(0, 300)}`);
    return data;
  }
}

const company = () => (process.env.WHOP_COMPANY_ID ? { company_id: process.env.WHOP_COMPANY_ID } : {});

export type LinkInput = {
  title: string; amount: number; currency: string; product_id?: string;
  kind: "one_time" | "instalments"; instalments?: number; every_days?: number;
  client?: string; invoice_ref?: string; createdBy: string;
};

/** Creates a plan inline and a checkout link for it; saves it so the webhook can match payments back. */
export async function createLink(x: LinkInput) {
  const row = await prisma.paymentLink.create({ data: {
    title: x.title, amount: x.amount, currency: x.currency.toLowerCase(), productId: x.product_id ?? "", kind: x.kind,
    instalments: x.kind === "instalments" ? x.instalments ?? 2 : 1, client: x.client ?? "", invoiceRef: x.invoice_ref ?? "", createdBy: x.createdBy } });
  const each = x.kind === "instalments" ? Math.round((x.amount / (x.instalments ?? 2)) * 100) / 100 : x.amount;
  const plan = x.kind === "one_time"
    ? { title: x.title, plan_type: "one_time", initial_price: x.amount, currency: x.currency.toLowerCase(), ...(x.product_id ? { product_id: x.product_id } : {}), ...company() }
    : { title: x.title, plan_type: "renewal", initial_price: each, renewal_price: each, billing_period: x.every_days ?? 30,
        split_pay_required_payments: x.instalments ?? 2, currency: x.currency.toLowerCase(), ...(x.product_id ? { product_id: x.product_id } : {}), ...company() };
  try {
    const c = await whop("POST", "/checkout_configurations", { plan, metadata: { brain_link_id: String(row.id), invoice_ref: x.invoice_ref ?? "", client: x.client ?? "" }, ...company() });
    const planId = c.plan?.id ?? c.plan_id ?? "";
    const updated = await prisma.paymentLink.update({ where: { id: row.id }, data: { checkoutId: c.id ?? "", planId, url: c.purchase_url ?? c.url ?? "" } });
    return updated;
  } catch (e) {
    await prisma.paymentLink.delete({ where: { id: row.id } });
    throw e;
  }
}

/** Changes the price or title of a link's plan. */
export async function updateLink(id: number, change: { amount?: number; title?: string }) {
  const l = await prisma.paymentLink.findUnique({ where: { id } });
  if (!l?.planId) throw new Error("Link not found or it has no Whop plan.");
  const each = change.amount !== undefined ? (l.kind === "instalments" ? Math.round((change.amount / l.instalments) * 100) / 100 : change.amount) : undefined;
  await whop("PATCH", `/plans/${l.planId}`, { ...(each !== undefined ? { initial_price: each, ...(l.kind === "instalments" ? { renewal_price: each } : {}) } : {}), ...(change.title ? { title: change.title } : {}) });
  return prisma.paymentLink.update({ where: { id }, data: { ...(change.amount !== undefined ? { amount: change.amount } : {}), ...(change.title ? { title: change.title } : {}) } });
}

/** Stops a link from taking payments (its plan is hidden and archived in Whop). */
export async function deactivateLink(id: number) {
  const l = await prisma.paymentLink.findUnique({ where: { id } });
  if (!l?.planId) throw new Error("Link not found or it has no Whop plan.");
  await whop("PATCH", `/plans/${l.planId}`, { visibility: "archived" }).catch(() => whop("PATCH", `/plans/${l.planId}`, { visibility: "hidden" }));
  return prisma.paymentLink.update({ where: { id }, data: { status: "deactivated" } });
}

export async function listPayments(q: { since?: string; email?: string; limit?: number }) {
  const params = new URLSearchParams({ ...(process.env.WHOP_COMPANY_ID ? { company_id: process.env.WHOP_COMPANY_ID } : {}), first: String(Math.min(q.limit ?? 25, 100)),
    ...(q.since ? { created_after: new Date(q.since).toISOString() } : {}) });
  const d = await whop("GET", `/payments?${params}`);
  const items = (d.data ?? d.items ?? []) as Record<string, any>[]; // eslint-disable-line @typescript-eslint/no-explicit-any
  return items
    .map((p) => ({ id: p.id, status: p.status, amount: money(typeof p.currency === "string" ? p.currency : "", p.total, p.final_amount, p.amount, p.subtotal, p.usd_total), currency: p.currency, email: p.user?.email ?? p.billing_address?.email ?? "",
      name: p.user?.name ?? p.billing_address?.name ?? "", plan: p.plan?.id ?? p.plan_id, product: p.product?.title ?? "", paidAt: p.paid_at ?? p.created_at, metadata: p.metadata ?? {} }))
    .filter((p) => !q.email || (p.email ?? "").toLowerCase() === q.email.toLowerCase());
}

// ---------- money ----------
/** Whop sends amounts as numbers, strings, or objects ({ amount, value, currency, … }); returns a readable "1.00 USD". */
export function money(...candidates: unknown[]): string {
  let currency = "";
  for (const c of candidates) {
    if (c === null || c === undefined || c === "") continue;
    if (typeof c === "number") return `${c.toFixed(2)}${currency ? ` ${currency}` : ""}`;
    if (typeof c === "string" && /^-?\d+(\.\d+)?$/.test(c)) return `${Number(c).toFixed(2)}${currency ? ` ${currency}` : ""}`;
    if (typeof c === "string" && /^[a-z]{3}$/i.test(c)) { currency = c.toUpperCase(); continue; }
    if (typeof c === "object") {
      const o = c as Record<string, unknown>;
      const cur = typeof o.currency === "string" ? o.currency.toUpperCase() : currency;
      const cents = o.amount_cents ?? o.cents ?? o.in_cents;
      if (typeof cents === "number") return `${(cents / 100).toFixed(2)} ${cur}`.trim();
      for (const k of ["amount", "value", "total", "usd", "formatted"]) {
        const v = o[k];
        if (typeof v === "number") return `${v.toFixed(2)} ${cur}`.trim();
        if (typeof v === "string" && v.trim()) return /^-?\d+(\.\d+)?$/.test(v) ? `${Number(v).toFixed(2)} ${cur}`.trim() : v;
      }
    }
  }
  return "unknown amount";
}

// ---------- webhook ----------
/** Standard Webhooks signature, as Whop signs it (key = the ws_ secret as given). */
export function verifyWebhook(body: string, h: Headers) {
  const secret = process.env.WHOP_WEBHOOK_SECRET;
  if (!secret) return false;
  const id = h.get("webhook-id") ?? "", ts = h.get("webhook-timestamp") ?? "", sigs = h.get("webhook-signature") ?? "";
  if (!id || !ts || Math.abs(Date.now() / 1000 - Number(ts)) > 600) return false;
  const expected = crypto.createHmac("sha256", Buffer.from(secret, "utf8")).update(`${id}.${ts}.${body}`).digest("base64");
  return sigs.split(" ").some((s) => {
    const v = s.split(",")[1] ?? "";
    return v.length === expected.length && crypto.timingSafeEqual(Buffer.from(v), Buffer.from(expected));
  });
}

export async function handleWebhook(event: { type?: string; data?: Record<string, any> }) { // eslint-disable-line @typescript-eslint/no-explicit-any
  const p = event.data ?? {};
  const ok = event.type === "payment.succeeded", failed = event.type === "payment.failed";
  if (!ok && !failed) return { ignored: event.type };
  const linkId = Number(p.metadata?.brain_link_id ?? 0);
  const link = linkId ? await prisma.paymentLink.findUnique({ where: { id: linkId } })
    : p.plan?.id || p.plan_id ? await prisma.paymentLink.findFirst({ where: { planId: p.plan?.id ?? p.plan_id } }) : null;
  if (link) await prisma.paymentLink.update({ where: { id: link.id }, data: { status: ok ? "paid" : "failed", paymentId: p.id ?? "" } });
  const who = p.user?.name || p.billing_address?.name || p.user?.email || link?.client || "Someone";
  const cur = typeof p.currency === "string" ? p.currency : link?.currency ?? "";
  const amount = money(cur, p.total, p.final_amount, p.amount, p.subtotal, p.usd_total, link?.amount);
  console.log("whop webhook amounts", JSON.stringify({ type: event.type, total: p.total, final_amount: p.final_amount, amount: p.amount, subtotal: p.subtotal, usd_total: p.usd_total, currency: p.currency }));
  const text = ok
    ? `✅ Payment received: ${who} paid ${amount}${link ? ` for "${link.title}"` : ""}${link?.invoiceRef ? ` (invoice ${link.invoiceRef})` : ""}. Whop payment ${p.id ?? ""}.`
    : `⚠️ Payment failed: ${who}, ${amount}${link ? ` for "${link.title}"` : ""}${link?.invoiceRef ? ` (invoice ${link.invoiceRef})` : ""}. Whop payment ${p.id ?? ""}.`;
  try {
    const { sendSlack } = await import("./send");
    await sendSlack({ channel: process.env.WHOP_SLACK_CHANNEL || "#finance-payments-invoices", text });
  } catch { /* posting must not break the webhook */ }
  await logActivity("Whop", ok ? "payment succeeded" : "payment failed", "payments", link?.id ?? null, text.slice(0, 200));
  return { handled: event.type, link: link?.id ?? null };
}
