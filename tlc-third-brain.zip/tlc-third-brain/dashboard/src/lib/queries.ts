import "server-only";
import { prisma } from "./db";
import { deptScope, isAdmin, type CurrentUser } from "./auth";

export async function refs(u: CurrentUser) {
  const [departments, playbooks] = await Promise.all([
    prisma.department.findMany({ where: isAdmin(u) ? {} : { id: { in: u.departments } }, orderBy: [{ position: "asc" }, { name: "asc" }] }),
    prisma.playbook.findMany({ where: deptScope(u), orderBy: { name: "asc" } }),
  ]);
  return {
    departments, playbooks,
    deptRefs: departments.map((d) => ({ id: d.id, name: d.name })),
    pbRefs: playbooks.map((p) => ({ id: p.id, name: p.name })),
  };
}

export const STATUS_ORDER: Record<string, number> = { live: 0, testing: 1, draft: 2, idea: 3, paused: 4 };
