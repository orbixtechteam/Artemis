import "server-only";
import crypto from "node:crypto";
import { prisma } from "./db";

export const ACCESS_TTL = 60 * 60;            // 1 hour
export const REFRESH_TTL = 60 * 60 * 24 * 30; // 30 days
export const sha256 = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
export const randomToken = (prefix: string) => `${prefix}_${crypto.randomBytes(32).toString("base64url")}`;

export function baseUrl(req?: Request) {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/$/, "");
  if (!req) return "http://localhost:3900";
  const h = req.headers;
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3900";
  return `${h.get("x-forwarded-proto") ?? "http"}://${host}`;
}

export const cors = { "access-control-allow-origin": "*", "access-control-allow-headers": "authorization, content-type, mcp-protocol-version", "access-control-allow-methods": "GET, POST, OPTIONS" };

export function authServerMetadata(base: string) {
  return {
    issuer: base,
    authorization_endpoint: `${base}/oauth/authorize`,
    token_endpoint: `${base}/api/oauth/token`,
    registration_endpoint: `${base}/api/oauth/register`,
    revocation_endpoint: `${base}/api/oauth/revoke`,
    response_types_supported: ["code"],
    grant_types_supported: ["authorization_code", "refresh_token"],
    code_challenge_methods_supported: ["S256"],
    token_endpoint_auth_methods_supported: ["none"],
    scopes_supported: ["mcp"],
  };
}

export function resourceMetadata(base: string) {
  return { resource: `${base}/api/mcp`, authorization_servers: [base], scopes_supported: ["mcp"], bearer_methods_supported: ["header"], resource_name: "Third Brain (The Longevity Clinic)" };
}

export async function issueTokens(clientId: string, userId: number) {
  const access = randomToken("tba"), refresh = randomToken("tbr");
  await prisma.oAuthToken.create({ data: {
    clientId, userId, accessHash: sha256(access), refreshHash: sha256(refresh),
    expiresAt: new Date(Date.now() + ACCESS_TTL * 1000), refreshExpiresAt: new Date(Date.now() + REFRESH_TTL * 1000),
  } });
  return { access_token: access, token_type: "Bearer", expires_in: ACCESS_TTL, refresh_token: refresh, scope: "mcp" };
}

/** Returns the user id for a valid, unexpired OAuth access token. */
export async function userIdForAccessToken(token: string): Promise<number | null> {
  const t = await prisma.oAuthToken.findUnique({ where: { accessHash: sha256(token) } });
  if (!t || t.expiresAt < new Date()) return null;
  await prisma.oAuthToken.update({ where: { id: t.id }, data: { lastUsed: new Date() } });
  return t.userId;
}

export function verifyPkce(verifier: string, challenge: string) {
  const computed = crypto.createHash("sha256").update(verifier).digest("base64url");
  return computed.length === challenge.length && crypto.timingSafeEqual(Buffer.from(computed), Buffer.from(challenge));
}
