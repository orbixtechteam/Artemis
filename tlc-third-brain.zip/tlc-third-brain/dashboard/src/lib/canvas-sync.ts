import fs from "node:fs";
import path from "node:path";
import { prisma } from "./db";
import { slugify } from "./utils";

export type CronJob = {
  id: string; name?: string; displayName?: string; enabled?: boolean; declarationKey?: string; command?: string;
  schedule?: { kind?: string; expr?: string; tz?: string; everyMs?: number; at?: string };
  payload?: { kind?: string; message?: string; command?: string; text?: string; argv?: string[] };
  delivery?: { mode?: string; channel?: string; to?: string };
  state?: { lastRunAtMs?: number; lastRunStatus?: string; lastError?: string; lastDiagnosticSummary?: string };
};

type StepSpec = { title: string; kind: "person" | "automation" | "ai_agent" | "empty"; role: string; tool: string; note?: string };

const PEOPLE: Record<string, string> = {
  "+34673555075": "Noah", "949832775": "Noah", "8619174084": "Ulvi",
};

const TOOL_WORDS: [RegExp, string][] = [
  [/periskope|inbox_updates|whatsapp_draft/i, "Periskope"], [/zoom/i, "Zoom"], [/fathom/i, "Fathom"],
  [/gmail|e-?mail/i, "Gmail"], [/slack|sales-payment-made/i, "Slack"], [/asana/i, "Asana"],
  [/drive|playbooks-live|patients\//i, "Google Drive"], [/calendar/i, "Google Calendar"],
  [/run-log|run log/i, "Run log"], [/notes\.md|rules\.md/i, "Playbook notes"], [/meeting ai summary/i, "Call summary sheet"],
];
const toolsIn = (text: string) => [...new Set(TOOL_WORDS.filter(([re]) => re.test(text)).map(([, t]) => t))];

/** What each server script really does (they are ours, in /usr/local/bin). */
const SCRIPTS: Record<string, { steps: StepSpec[] }> = {
  "jarvis-calendar-briefs": { steps: [
    { title: "Check Noah's calendar for new, moved or cancelled calls", kind: "automation", role: "Server script", tool: "Google Calendar" },
    { title: "Jarvis writes the pre-call brief", kind: "ai_agent", role: "Jarvis", tool: "Gmail" },
    { title: "Graphite Context block at the same time, with a time check", kind: "automation", role: "Server script", tool: "Google Calendar" },
  ] },
  "jarvis-payment-summaries": { steps: [
    { title: "New payment message in #sales-payment-made", kind: "automation", role: "Server script", tool: "Slack" },
    { title: "Jarvis finds the client's last call and writes the summary", kind: "ai_agent", role: "Jarvis", tool: "Zoom" },
    { title: "Summary posted in the payment's thread", kind: "automation", role: "Server script", tool: "Slack" },
    { title: "Program payment: 5-month upsell check scheduled", kind: "automation", role: "Server script", tool: "Jarvis cron" },
  ] },
  "jarvis-zoom-drive": { steps: [
    { title: "List new recordings of every Zoom user", kind: "automation", role: "Server script", tool: "Zoom" },
    { title: "Skip [private] and internal 1:1 calls", kind: "automation", role: "Server script", tool: "Zoom" },
    { title: "Save transcript and summary to Drive: Jarvis/Zoom calls", kind: "automation", role: "Server script", tool: "Google Drive" },
  ] },
  "jarvis-run-monitor": { steps: [
    { title: "Check every scheduled job: failed, late or not delivered", kind: "automation", role: "Server script", tool: "Run log" },
    { title: "Write each run to the run log", kind: "automation", role: "Server script", tool: "Run log" },
  ] },
  "jarvis-playbooks-sync": { steps: [
    { title: "Copy the live Playbooks folder from Drive", kind: "automation", role: "Server script", tool: "Google Drive" },
    { title: "Save changes with history (git)", kind: "automation", role: "Server script", tool: "Git" },
  ] },
  "check-google": { steps: [{ title: "Check the Google connection", kind: "automation", role: "Server script", tool: "Google" }] },
  "check-whatsapp": { steps: [{ title: "Check the WhatsApp connection, recheck after 1 minute", kind: "automation", role: "Server script", tool: "WhatsApp" }] },
};

const pad = (n: string) => n.padStart(2, "0");
export function humanSchedule(s: CronJob["schedule"] = {}): string {
  if (s.kind === "every") return `Every ${Math.round((s.everyMs ?? 0) / 60000)} minutes`;
  if (s.kind === "at") return `Once on ${String(s.at).slice(0, 16).replace("T", " ")} UTC`;
  const e = (s.expr ?? "").trim().split(/\s+/);
  if (e.length !== 5) return s.expr ?? "";
  const [m, h, dom, mon, dow] = e;
  const days: Record<string, string> = { "0": "Sundays", "1": "Mondays", "2": "Tuesdays", "3": "Wednesdays", "4": "Thursdays", "5": "Fridays", "6": "Saturdays", "7": "Sundays" };
  const tz = s.tz ? ` (${s.tz.split("/").pop()?.replace("_", " ")})` : "";
  if (dom !== "*" || mon !== "*") return `${s.expr}${tz}`;
  if (m.startsWith("*/") && h === "*") return `Every ${m.slice(2)} minutes`;
  if (/^\d+$/.test(m) && h === "*") return `Every hour at :${pad(m)}`;
  if (/^\d+$/.test(m) && /^\d+-\d+$/.test(h)) { const [a, b] = h.split("-"); return `Every hour ${pad(a)}:${pad(m)} to ${pad(b)}:${pad(m)}${tz}`; }
  if (/^\d+$/.test(m) && /^\d+$/.test(h)) return `${dow === "*" ? "Every day" : days[dow] ?? `Days ${dow}`} ${pad(h)}:${pad(m)}${tz}`;
  return `${s.expr}${tz}`;
}

function sentences(msg: string): string[] {
  return msg.replace(/\s+/g, " ").split(/(?<=[.!?])\s+(?=[A-Z])/).map((x) => x.trim()).filter((x) => x.length > 12);
}
const short = (t: string, n = 110) => (t.length > n ? `${t.slice(0, n - 1).trimEnd()}…` : t);

function delivery(j: CronJob, command: boolean): StepSpec | null {
  const d = j.delivery ?? {};
  if (!d.mode || d.mode === "none" || !d.channel) return null;
  const who = PEOPLE[d.to ?? ""] ?? d.to ?? "";
  const channel = d.channel === "whatsapp" ? "WhatsApp" : d.channel === "telegram" ? "Telegram" : d.channel;
  return command
    ? { title: `Alert ${who || "the team"} on ${channel}, only if something is wrong`, kind: "automation", role: "Jarvis", tool: channel }
    : { title: `Sent to ${who || "the team"} on ${channel}`, kind: "person", role: who || "Team", tool: channel };
}

export function stepsFor(j: CronJob): StepSpec[] {
  const schedule = humanSchedule(j.schedule);
  const status = j.state?.lastRunStatus;
  const trigger: StepSpec = { title: schedule || "On schedule", kind: "automation", role: "Jarvis", tool: "Jarvis cron", note: status ? `Last run: ${status}` : "" };
  const argv = j.payload?.argv;
  const fromArgv = argv?.length ? (/^(ba)?sh$/.test(argv[0]) && argv[1]?.startsWith("-") ? argv[argv.length - 1] : argv.join(" ")) : undefined;
  const command = j.payload?.command ?? j.command ?? fromArgv ?? (j.payload?.kind === "command" ? j.payload?.text : undefined);
  if (command) {
    const script = path.basename(command.split(/\s+/)[0]);
    const known = SCRIPTS[script]?.steps ?? [{ title: `Run ${script}`, kind: "automation" as const, role: "Server script", tool: "Server" }];
    return [trigger, ...known, ...(delivery(j, true) ? [delivery(j, true)!] : [])];
  }
  const msg = j.payload?.message ?? j.payload?.text ?? "";
  const SKIP = /^(if it returns no|reply exactly|never |do not |don't |jarvis never|skip newsletters|short lines|as the very last step|under \d+ lines)/i;
  const TOOL_CALLS: [RegExp, string][] = [
    [/inbox_updates/i, "Read new WhatsApp inbox messages (archived chats skipped)"],
    [/list_new_recordings/i, "List new Zoom recordings"],
    [/create_whatsapp_draft/i, "Draft replies with wa.me links"],
  ];
  const body = sentences(msg).filter((x) => !SKIP.test(x) && !/confirm_digest_done|no_reply/i.test(x)).slice(0, 3).map<StepSpec>((x) => {
    const call = TOOL_CALLS.find(([re]) => re.test(x) && /^call the /i.test(x));
    let text = call ? call[1] : x.replace(/^(otherwise|then|next),?\s+/i, "");
    text = text.charAt(0).toUpperCase() + text.slice(1);
    const colon = text.indexOf(":");
    const title = colon > 15 && colon < 110 ? text.slice(0, colon) : text;
    const note = colon > 15 && colon < 110 ? text.slice(colon + 1).trim() : "";
    return { title: short(title.replace(/ following section \d+ of AGENTS\.md/i, "")), kind: "ai_agent", role: "Jarvis", tool: toolsIn(x)[0] ?? toolsIn(msg)[0] ?? "Jarvis", note: short(note, 90) };
  });
  const out = delivery(j, false);
  return [trigger, ...body, ...(out ? [out] : [])];
}

const MAP: [string, string][] = [
  ["calendar brief", "pre-call-brief"], ["payment", "payment-summary"], ["whatsapp digest", "whatsapp-replies"],
  ["morning brief", "morning-brief"], ["week plan", "week-plan"], ["monday review", "monday-review"], ["patient summar", "patient-summary"],
];

async function sectionFor(name: string, enabled: boolean, trigger: string) {
  const hit = MAP.find(([k]) => name.toLowerCase().includes(k));
  if (hit) {
    const pb = await prisma.playbook.findUnique({ where: { slug: hit[1] } });
    if (pb) return pb.id;
  }
  const slug = `job-${slugify(name)}`;
  const existing = await prisma.playbook.findUnique({ where: { slug } });
  if (existing) return existing.id;
  const company = await prisma.department.findFirst({ where: { name: "Company" } }) ?? await prisma.department.findFirst();
  return (await prisma.playbook.create({ data: {
    slug, name, departmentId: company?.id ?? null, owner: "Ulvi", status: enabled ? "live" : "paused", autonomy: "green", trigger,
    purpose: "System job from Jarvis.",
  } })).id;
}

async function writeSteps(playbookId: number, keyPrefix: string, row: number, steps: StepSpec[], source: "jarvis" | "skill", keep: Set<string>) {
  const ids: number[] = [];
  for (const [i, s] of steps.entries()) {
    const extKey = `${keyPrefix}:${i}`;
    keep.add(extKey);
    const data = { playbookId, title: s.title, kind: s.kind, role: s.role, tool: s.tool, note: s.note ?? "", source };
    const st = await prisma.step.upsert({
      where: { extKey }, update: data,
      create: { ...data, extKey, x: 24 + i * 210, y: 64 + row * 130 },
    });
    ids.push(st.id);
  }
  for (let i = 1; i < ids.length; i++)
    await prisma.connection.upsert({ where: { fromId_toId: { fromId: ids[i - 1], toId: ids[i] } }, update: {}, create: { fromId: ids[i - 1], toId: ids[i] } });
}

/** Steps from Jarvis's real scheduled jobs. Positions people dragged are kept; manual steps are never touched. */
export async function syncCanvasFromJobs(jobs: CronJob[]) {
  const keep = new Set<string>();
  const rows = new Map<number, number>();
  for (const j of jobs) {
    if (j.declarationKey || /^heartbeat|memory dreaming/i.test(j.name ?? j.displayName ?? "")) continue;
    const name = j.displayName || j.name || j.id;
    const pbId = await sectionFor(name, j.enabled !== false, humanSchedule(j.schedule));
    const row = rows.get(pbId) ?? 0;
    rows.set(pbId, row + 1);
    await writeSteps(pbId, `job:${j.id}`, row, stepsFor(j), "jarvis", keep);
  }
  const stale = await prisma.step.findMany({ where: { source: "jarvis" }, select: { id: true, extKey: true } });
  const gone = stale.filter((s) => s.extKey && !keep.has(s.extKey)).map((s) => s.id);
  if (gone.length) await prisma.step.deleteMany({ where: { id: { in: gone } } });
  return { steps: keep.size, removed: gone.length };
}

/** Steps listed under a "Steps" heading in each live SKILL.md. */
export async function syncSkillSteps(workspace: string) {
  const roots = ["playbooks-live", "playbooks-approved"].map((r) => path.join(workspace, r)).filter((r) => fs.existsSync(r));
  if (!roots.length) return 0;
  const keep = new Set<string>();
  const walk = async (d: string) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { await walk(p); continue; }
      if (!/^skill\.md$/i.test(e.name)) continue;
      const slug = slugify(path.basename(path.dirname(p)));
      const pb = await prisma.playbook.findUnique({ where: { slug }, include: { steps: { where: { source: "jarvis" }, select: { y: true } } } });
      if (!pb) continue;
      const lines = fs.readFileSync(p, "utf8").split("\n");
      const start = lines.findIndex((l) => /^#+\s*steps\b/i.test(l));
      if (start < 0) continue;
      const items: string[] = [];
      for (const l of lines.slice(start + 1)) {
        if (/^#+\s/.test(l)) break;
        const m = l.match(/^\s*(?:\d+[.)]|[-*])\s+(.+)/);
        if (m) items.push(m[1].replace(/\*\*/g, "").trim());
      }
      const row = pb.steps.length ? Math.max(...pb.steps.map((s) => Math.round((s.y - 64) / 130))) + 1 : 0;
      await writeSteps(pb.id, `skill:${slug}`, row, items.slice(0, 12).map((t) => ({
        title: short(t), kind: /\b(noah|approve|owner|doctor|coach|review)\b/i.test(t) ? "person" : "ai_agent",
        role: /\bnoah\b/i.test(t) ? "Noah" : "Jarvis", tool: toolsIn(t)[0] ?? "",
      })), "skill", keep);
    }
  };
  for (const r of roots) await walk(r);
  const stale = await prisma.step.findMany({ where: { source: "skill" }, select: { id: true, extKey: true } });
  const gone = stale.filter((s) => s.extKey && !keep.has(s.extKey)).map((s) => s.id);
  if (gone.length) await prisma.step.deleteMany({ where: { id: { in: gone } } });
  return keep.size;
}
