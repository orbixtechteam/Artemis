import { runSync } from "./sync";
import { prisma } from "./db";

runSync("cli").then(async (r) => {
  console.log(JSON.stringify(r, null, 2));
  await prisma.$disconnect();
});
