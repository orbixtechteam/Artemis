import "server-only";
import { execFile } from "node:child_process";
import { z } from "zod/v4";
import { prisma, logActivity } from "./db";

/**
 * "When X happens, do Y" rules. A single OpenClaw job calls /api/automations/run every 5 minutes;
 * whatever must reach Noah's WhatsApp is returned as text (the job delivers it there), every other
 * action is done here. Only these trigger and action types exist: no shell, no arbitrary code.
 */

export const TriggerSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("slack_bot_reply"), channel: z.string().min(2).describe("Slack channel name, e.g. sales-payment-made"), min_length: z.number().int().default(80) })
    .describe("The clinic's bot posts a reply in a thread of this channel (e.g. a payment summary)"),
  z.object({ type: z.literal("slack_message"), channel: z.string().min(2), keywords: z.array(z.string()).default([]).describe("Only messages containing one of these words; empty = all") })
    .describe("A new message is posted in this channel"),
  z.object({ type: z.literal("schedule"), every_minutes: z.number().int().min(5).optional(), daily_at: z.string().regex(/^\d{2}:\d{2}$/).optional().describe("HH:MM, Madrid time"),
    weekdays: z.array(z.number().int().min(0).max(6)).optional().describe("0=Sunday … 6=Saturday; empty = every day") })
    .describe("On a schedule"),
]);
export const ActionSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("whatsapp_noah"), prefix: z.string().default("") }).describe("Send to Noah's own WhatsApp (self-chat)"),
  z.object({ type: z.literal("slack"), to: z.string().min(2).describe("#channel or a person's email for a DM"), prefix: z.string().default("") }).describe("Post with the clinic's Slack bot"),
  z.object({ type: z.literal("jarvis"), prompt: z.string().min(5).describe("What Jarvis should do; for a trigger the event text is appended"),
    deliver: z.enum(["whatsapp_noah", "slack", "none"]).default("whatsapp_noah"), to: z.string().default("") }).describe("Give Jarvis a task and deliver its answer"),
]);
export type Trigger = z.infer<typeof TriggerSchema>;
export type Action = z.infer<typeof ActionSchema>;

type Event = { text: string; link?: string; title?: string };
type State = { seen?: string[]; since?: string; lastDue?: string };

// ---------- time helpers (Madrid) ----------
function madridNow() {
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Madrid", hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", weekday: "short" })
    .formatToParts(new Date()).map((p) => [p.type, p.value]));
  const days = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 } as Record<string, number>;
  return { date: `${parts.year}-${parts.month}-${parts.day}`, hm: `${parts.hour}:${parts.minute}`, weekday: days[parts.weekday] ?? 0 };
}

// ---------- triggers ----------
async function collect(trigger: Trigger, state: State, lastRunAt: Date | null): Promise<{ events: Event[]; state: State; init?: boolean }> {
  const send = await import("./send");
  if (trigger.type === "schedule") {
    const now = madridNow();
    if (trigger.every_minutes) {
      const due = !lastRunAt || Date.now() - lastRunAt.getTime() >= trigger.every_minutes * 60_000 - 30_000;
      return { events: due ? [{ text: "" }] : [], state };
    }
    const at = trigger.daily_at ?? "09:00";
    const dayOk = !trigger.weekdays?.length || trigger.weekdays.includes(now.weekday);
    const key = `${now.date} ${at}`;
    const due = dayOk && now.hm >= at && state.lastDue !== key;
    return { events: due ? [{ text: "" }] : [], state: due ? { ...state, lastDue: key } : state };
  }

  const channel = await send.slackChannelId(trigger.channel);
  const seen = new Set(state.seen ?? []);
  const firstRun = !state.since;
  const since = state.since ?? String(Date.now() / 1000 - 3 * 86400);
  const events: Event[] = [];
  const fresh: string[] = [];

  if (trigger.type === "slack_message") {
    for (const m of (await send.slackHistory(channel, since)).reverse()) {
      if (seen.has(m.ts) || !m.text) continue;
      fresh.push(m.ts);
      const words = trigger.keywords.map((k) => k.toLowerCase());
      if (words.length && !words.some((w) => m.text!.toLowerCase().includes(w))) continue;
      events.push({ text: m.text, link: await send.slackPermalink(channel, m.ts) });
    }
  } else {
    const bot = await send.slackBotUserId();
    for (const m of (await send.slackHistory(channel, String(Date.now() / 1000 - 3 * 86400))).reverse()) {
      if (!m.reply_count) continue;
      for (const r of await send.slackReplies(channel, m.ts)) {
        if (seen.has(r.ts) || r.user !== bot || (r.text ?? "").length < trigger.min_length) continue;
        fresh.push(r.ts);
        events.push({ title: (m.text ?? "").split("\n")[0].slice(0, 120), text: r.text ?? "", link: await send.slackPermalink(channel, r.ts) });
      }
    }
  }
  const nextSeen = [...seen, ...fresh].slice(-3000);
  // On the first run only remember what exists, so old messages don't flood anyone.
  return { events: firstRun ? [] : events, state: { seen: nextSeen, since: String(Date.now() / 1000 - 3600) }, init: firstRun };
}

// ---------- actions ----------
const plain = (t: string) => t.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").trim();
function format(rule: string, e: Event, prefix: string) {
  return [prefix || `🔔 ${rule}`, e.title ? `*${plain(e.title)}*` : "", plain(e.text), e.link ?? ""].filter(Boolean).join("\n\n");
}

async function askJarvis(prompt: string, key: string, whatsappAllowed: boolean) {
  const bin = process.env.OPENCLAW_BIN || "openclaw";
  const guard = whatsappAllowed ? "" : " Do not read or use WhatsApp for this task.";
  const message = `Automation from the Third Brain dashboard.${guard} Answer with the result only; do not message anyone yourself.\n\n${prompt}`;
  return new Promise<string>((resolve) => execFile(bin, ["agent", "--agent", "main", "--session-key", `agent:main:automation-${key}`, "--message", message],
    { timeout: 300_000, maxBuffer: 8 * 1024 * 1024 }, (err, out, errOut) => resolve(err ? `(Jarvis didn't answer: ${(errOut || err.message).slice(-200)})` : out.trim())));
}

/** Runs every enabled rule once. Returns the text meant for Noah's WhatsApp (empty = nothing). */
export async function runAutomations(): Promise<{ whatsapp: string; report: string[] }> {
  const rules = await prisma.automationRule.findMany({ where: { enabled: true } });
  const owner = await prisma.user.findFirst({ where: { role: "owner" } });
  const forNoah: string[] = [];
  const report: string[] = [];
  for (const r of rules) {
    try {
      const trigger = TriggerSchema.parse(JSON.parse(r.trigger));
      const action = ActionSchema.parse(JSON.parse(r.action));
      if (action.type === "jarvis") {
        const { jarvisRunsDepartment, SALES_WORK } = await import("./jarvis-scope");
        const pb = r.playbookId ? await prisma.playbook.findUnique({ where: { id: r.playbookId } }) : null;
        if (SALES_WORK.test(`${r.name} ${action.prompt}`) || (pb && !(await jarvisRunsDepartment(pb.departmentId)))) {
          await prisma.automationRule.update({ where: { id: r.id }, data: { enabled: false, lastRunAt: new Date(), lastResult: "switched off: Jarvis doesn't do this department's work (sales belongs to the Sales department)" } });
          report.push(`${r.name}: switched off (not Jarvis's work)`);
          continue;
        }
      }
      const creator = await prisma.user.findUnique({ where: { id: r.createdBy } });
      const whatsappAllowed = creator?.role === "owner" || !!creator?.whatsapp;
      const { events, state, init } = await collect(trigger, JSON.parse(r.state || "{}"), r.lastRunAt);
      let done = 0;
      for (const e of events.slice(0, 5)) {
        let text = "", target = action.type === "jarvis" ? action.deliver : action.type, to = "to" in action ? action.to : "";
        if (action.type === "jarvis") text = await askJarvis(`${action.prompt}${e.text ? `\n\nEvent:\n${plain(e.text)}${e.link ? `\n${e.link}` : ""}` : ""}`, String(r.id), whatsappAllowed);
        else text = format(r.name, e, action.prefix);
        if (!text) continue;
        if (target === "whatsapp_noah") { if (whatsappAllowed && owner) forNoah.push(text); }
        else if (target === "slack" && to) { const { sendSlack } = await import("./send"); await sendSlack({ channel: to, text }); }
        done++;
      }
      await prisma.automationRule.update({ where: { id: r.id }, data: { state: JSON.stringify(state), lastRunAt: new Date(), lastResult: init ? "ready (existing messages skipped)" : `ok, ${done} sent` } });
      if (done) report.push(`${r.name}: ${done}`);
    } catch (e) {
      await prisma.automationRule.update({ where: { id: r.id }, data: { lastRunAt: new Date(), lastResult: `error: ${(e as Error).message.slice(0, 200)}` } });
      report.push(`${r.name}: error`);
    }
  }
  if (report.length) await logActivity("Automations", "ran", "automations", null, report.join("; "));
  return { whatsapp: forNoah.join("\n\n———\n\n"), report };
}

export function describeRule(trigger: Trigger, action: Action) {
  const when = trigger.type === "schedule"
    ? trigger.every_minutes ? `every ${trigger.every_minutes} minutes` : `${trigger.weekdays?.length ? `on ${trigger.weekdays.map((d) => ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][d]).join(", ")}` : "every day"} at ${trigger.daily_at ?? "09:00"} (Madrid)`
    : trigger.type === "slack_message" ? `a new message in #${trigger.channel.replace(/^#/, "")}${trigger.keywords.length ? ` mentioning ${trigger.keywords.join(" / ")}` : ""}`
    : `the bot replies in a thread of #${trigger.channel.replace(/^#/, "")}`;
  const then = action.type === "whatsapp_noah" ? "send it to Noah's WhatsApp"
    : action.type === "slack" ? `post it to ${action.to}`
    : `ask Jarvis: "${action.prompt.slice(0, 80)}" and ${action.deliver === "none" ? "keep the answer" : action.deliver === "slack" ? `post the answer to ${action.to}` : "send the answer to Noah's WhatsApp"}`;
  return { when, then };
}
