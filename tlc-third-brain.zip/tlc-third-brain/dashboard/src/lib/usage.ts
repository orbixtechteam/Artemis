import "server-only";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { meta, prisma } from "./db";

/** Prices per million tokens from MODEL_PRICES, e.g. {"claude-sonnet-5-5":{"in":3,"out":15,"cache":0.3}}. No prices: tokens only. */
type Price = { in: number; out: number; cache?: number };
function prices(): Record<string, Price> {
  try { return JSON.parse(process.env.MODEL_PRICES || "{}"); } catch { return {}; }
}
export function costFor(model: string, input: number, output: number, cache = 0): number | null {
  const p = prices();
  const key = Object.keys(p).find((k) => model.toLowerCase().includes(k.toLowerCase()));
  if (!key) return null;
  const x = p[key];
  return (input * x.in + output * x.out + cache * (x.cache ?? 0)) / 1_000_000;
}
export const pricesConfigured = () => Object.keys(prices()).length > 0;

export async function logUsage(d: { source: string; job: string; model: string; input: number; output: number; cache?: number; userId?: number }) {
  await prisma.usageLog.create({ data: { at: new Date(), source: d.source, job: d.job, model: d.model, inputTokens: d.input, outputTokens: d.output, cacheTokens: d.cache ?? 0, userId: d.userId ?? null } }).catch(() => undefined);
}

// ---------- Jarvis usage from OpenClaw session logs ----------
const OPENCLAW_HOME = process.env.OPENCLAW_HOME || "/root/.openclaw";

type U = { input: number; output: number; cache: number };
function findUsage(o: unknown, depth = 0): U | null {
  if (!o || typeof o !== "object" || depth > 6) return null;
  const r = o as Record<string, unknown>;
  const n = (k: string[]) => k.map((x) => r[x]).find((v) => typeof v === "number") as number | undefined;
  const input = n(["input_tokens", "inputTokens", "input", "promptTokens", "prompt_tokens"]);
  const output = n(["output_tokens", "outputTokens", "output", "completionTokens", "completion_tokens"]);
  if (input !== undefined && output !== undefined) {
    const cache = (n(["cache_read_input_tokens", "cacheRead", "cacheReadTokens"]) ?? 0) + (n(["cache_creation_input_tokens", "cacheWrite", "cacheWriteTokens"]) ?? 0);
    return { input, output, cache };
  }
  if (r.usage && typeof r.usage === "object") { const u = findUsage(r.usage, depth + 1); if (u) return u; }
  for (const v of Object.values(r)) if (v && typeof v === "object") { const u = findUsage(v, depth + 1); if (u) return u; }
  return null;
}
function findString(o: unknown, keys: string[], depth = 0): string | undefined {
  if (!o || typeof o !== "object" || depth > 5) return undefined;
  const r = o as Record<string, unknown>;
  for (const k of keys) if (typeof r[k] === "string") return r[k] as string;
  for (const v of Object.values(r)) if (v && typeof v === "object") { const s = findString(v, keys, depth + 1); if (s) return s; }
  return undefined;
}

function jobLabel(key: string, jobs: Map<string, string>): string {
  const cron = key.match(/cron:([\w-]+)/)?.[1];
  if (cron) return jobs.get(cron) ?? `Job ${cron.slice(0, 8)}`;
  if (/calbrief/.test(key)) return "Calendar briefs";
  if (/payment-/.test(key)) return "Payment summaries";
  if (/patient-/.test(key)) return "Patient summaries";
  if (/test-/.test(key)) return "Test sets";
  if (/agent:research/.test(key)) return "Research agent";
  if (/agent:main:main|whatsapp|telegram/.test(key)) return "Jarvis chat";
  return key.split(":").slice(0, 3).join(":") || "Jarvis";
}

/** Reads new lines of the session logs since the last sync and records token use per job. */
export async function syncJarvisUsage(): Promise<number> {
  const agentsDir = path.join(OPENCLAW_HOME, "agents");
  if (!fs.existsSync(agentsDir)) return 0;
  const offsets = JSON.parse((await meta.get("usage_offsets")) ?? "{}") as Record<string, number>;
  const jobs = new Map((await prisma.automation.findMany({ select: { extId: true, name: true } })).filter((a) => a.extId).map((a) => [a.extId!, a.name]));
  let added = 0;
  for (const agent of fs.readdirSync(agentsDir)) {
    const dir = path.join(agentsDir, agent, "sessions");
    if (!fs.existsSync(dir)) continue;
    let keyById = new Map<string, string>();
    try {
      const idx = JSON.parse(fs.readFileSync(path.join(dir, "sessions.json"), "utf8")) as Record<string, { sessionId?: string }>;
      keyById = new Map(Object.entries(idx).map(([k, v]) => [String(v?.sessionId ?? ""), k]));
    } catch { /* no index */ }
    for (const f of fs.readdirSync(dir).filter((x) => x.endsWith(".jsonl"))) {
      const file = path.join(dir, f);
      const size = fs.statSync(file).size;
      const from = offsets[file] ?? 0;
      if (size <= from) continue;
      const fd = fs.openSync(file, "r");
      const buf = Buffer.alloc(Math.min(size - from, 20 * 1024 * 1024));
      fs.readSync(fd, buf, 0, buf.length, from);
      fs.closeSync(fd);
      const text = buf.toString("utf8");
      const end = text.lastIndexOf("\n") + 1;
      const sessionId = f.replace(/\.jsonl$/, "");
      const job = `${agent === "main" ? "" : `${agent}: `}${jobLabel(keyById.get(sessionId) ?? `agent:${agent}:${sessionId}`, jobs)}`;
      const rows = [];
      let pos = from;
      for (const line of text.slice(0, end).split("\n")) {
        const at = pos; pos += Buffer.byteLength(line) + 1;
        if (!line.includes("token")) continue;
        let o: unknown; try { o = JSON.parse(line); } catch { continue; }
        const u = findUsage(o);
        if (!u || (u.input === 0 && u.output === 0)) continue;
        const ts = findString(o, ["timestamp", "ts", "createdAt", "time"]);
        const when = ts && !Number.isNaN(Date.parse(ts)) ? new Date(ts) : fs.statSync(file).mtime;
        rows.push({ at: when, source: "jarvis", job, model: findString(o, ["model", "modelId"]) ?? "", inputTokens: u.input, outputTokens: u.output, cacheTokens: u.cache,
          extKey: crypto.createHash("sha1").update(`${file}:${at}`).digest("hex").slice(0, 24) });
      }
      if (rows.length) {
        const known = new Set((await prisma.usageLog.findMany({ where: { extKey: { in: rows.map((r) => r.extKey) } }, select: { extKey: true } })).map((r) => r.extKey));
        const fresh = rows.filter((r) => !known.has(r.extKey));
        if (fresh.length) await prisma.usageLog.createMany({ data: fresh });
        added += fresh.length;
      }
      offsets[file] = from + Buffer.byteLength(text.slice(0, end));
    }
  }
  await meta.set("usage_offsets", JSON.stringify(offsets));
  return added;
}
