import "server-only";
import { prisma } from "./db";
import { deptScope, isAdmin, type CurrentUser } from "./auth";
import { isOk } from "./utils";

export const STREAK_TARGET = 20;

export async function autonomyBoard(u: CurrentUser) {
  const playbooks = await prisma.playbook.findMany({
    where: { ...deptScope(u), status: { in: ["live", "testing"] } },
    include: { department: { select: { name: true } }, automations: { select: { name: true } }, lessons: { select: { lessonDate: true, updatedAt: true } } },
    orderBy: { name: "asc" },
  });
  const jobNames = [...new Set(playbooks.flatMap((p) => p.automations.map((a) => a.name)))];
  const runs = jobNames.length ? await prisma.run.findMany({ where: { job: { in: jobNames } }, select: { job: true, runAt: true, status: true } }) : [];
  const outbox = await prisma.outbox.findMany({ where: { playbook: { in: playbooks.map((p) => p.slug) }, status: { in: ["sent", "rejected"] } }, orderBy: { decidedAt: "desc" }, select: { playbook: true, status: true, edited: true } });
  return playbooks.map((p) => {
    const last = p.lessons.map((l) => (l.lessonDate ? new Date(`${l.lessonDate}T23:59:59Z`) : l.updatedAt)).sort((a, b) => b.getTime() - a.getTime())[0] ?? null;
    const names = new Set(p.automations.map((a) => a.name));
    const mine = runs.filter((r) => names.has(r.job) && (!last || r.runAt > last));
    const clean = mine.filter((r) => isOk(r.status)).length;
    const failed = mine.length - clean;
    const testsOk = !p.testsTotal || p.testsPassed / p.testsTotal >= 0.9;
    // Approved without edits in a row, newest first (Road to autonomy step 2).
    const decided = outbox.filter((o) => o.playbook === p.slug);
    let approvedStreak = 0;
    for (const o of decided) { if (o.status === "sent" && !o.edited) approvedStreak++; else break; }
    const usesApprovals = decided.length > 0;
    return {
      id: p.id, name: p.name, department: p.department?.name ?? "", status: p.status, autonomy: p.autonomy,
      lastCorrection: last?.toISOString().slice(0, 10) ?? null, corrections: p.lessons.length,
      cleanRuns: clean, failedRuns: failed, hasRuns: names.size > 0,
      tests: p.testsTotal ? `${p.testsPassed}/${p.testsTotal}` : null,
      approvedStreak, usesApprovals,
      ready: p.autonomy === "amber" && p.status === "live" && testsOk && (usesApprovals ? approvedStreak >= STREAK_TARGET : clean >= STREAK_TARGET && failed === 0),
    };
  });
}

export async function timeSinks(u: CurrentUser) {
  const rows = await prisma.timeSink.findMany({ where: isAdmin(u) ? {} : { departmentId: { in: u.departments } }, include: { department: { select: { name: true } } }, orderBy: { hoursPerWeek: "desc" } });
  const pbs = await prisma.playbook.findMany({ where: { id: { in: rows.map((r) => r.playbookId).filter((x): x is number => !!x) } }, select: { id: true, name: true, status: true } });
  const total = rows.reduce((s, r) => s + r.hoursPerWeek, 0);
  let cum = 0;
  return {
    total,
    rows: rows.map((r) => {
      cum += r.hoursPerWeek;
      const pb = pbs.find((p) => p.id === r.playbookId) ?? null;
      return { id: r.id, task: r.task, department: r.department?.name ?? "No department", owner: r.owner, hours: r.hoursPerWeek, frequency: r.frequency, stuck: r.stuck, source: r.source,
        cumulative: total ? cum / total : 0, top: total ? cum - r.hoursPerWeek < total * 0.8 : false, playbook: pb };
    }),
  };
}

export async function qualityTrend(u: CurrentUser) {
  const since = new Date(Date.now() - 8 * 7 * 86400_000);
  const lessons = await prisma.lesson.findMany({ where: { ...deptScope(u), updatedAt: { gte: since } }, select: { lessonDate: true, updatedAt: true } });
  const weeks: { label: string; start: Date; n: number }[] = [];
  const monday = (d: Date) => { const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())); x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7)); return x; };
  for (let i = 7; i >= 0; i--) { const s = monday(new Date(Date.now() - i * 7 * 86400_000)); weeks.push({ label: s.toISOString().slice(5, 10), start: s, n: 0 }); }
  for (const l of lessons) {
    const d = l.lessonDate ? new Date(`${l.lessonDate}T12:00:00Z`) : l.updatedAt;
    const w = [...weeks].reverse().find((x) => d >= x.start);
    if (w) w.n++;
  }
  const tests = await prisma.playbook.findMany({ where: { ...deptScope(u), testsTotal: { gt: 0 } }, select: { id: true, name: true, testsPassed: true, testsTotal: true } });
  return { weeks: weeks.map(({ label, n }) => ({ label, n })), tests };
}
