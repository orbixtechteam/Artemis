"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma, logActivity } from "./db";
import { canEdit, currentUser, inScope } from "./auth";
import type { ActionResult } from "./actions";
import { STEP_KINDS } from "./constants";

async function editorFor(playbookId: number) {
  const u = await currentUser();
  if (!u) return { error: "Sign in to continue." };
  if (!canEdit(u)) return { error: "Your role can only view." };
  const pb = await prisma.playbook.findUnique({ where: { id: playbookId } });
  if (!pb) return { error: "Section not found." };
  if (!inScope(u, pb.departmentId)) return { error: "This belongs to a department you can't edit." };
  return { u, pb };
}

const stepSchema = z.object({
  id: z.number().int().optional(),
  playbookId: z.number().int(),
  title: z.string().trim().min(1, "Give the step a name."),
  kind: z.enum(STEP_KINDS),
  role: z.string().trim().default(""),
  tool: z.string().trim().default(""),
  note: z.string().trim().default(""),
  x: z.number().optional(),
  y: z.number().optional(),
});

export async function saveStep(input: z.input<typeof stepSchema>): Promise<ActionResult> {
  const p = stepSchema.safeParse(input);
  if (!p.success) return { ok: false, error: p.error.issues[0]?.message };
  const d = p.data;
  const ctx = await editorFor(d.playbookId);
  if ("error" in ctx) return { ok: false, error: ctx.error };
  if (d.id) {
    const old = await prisma.step.findUnique({ where: { id: d.id }, include: { playbook: true } });
    if (!old || !inScope(ctx.u, old.playbook.departmentId)) return { ok: false, error: "Step not found." };
    await prisma.step.update({ where: { id: d.id }, data: { playbookId: d.playbookId, title: d.title, kind: d.kind, role: d.role, tool: d.tool, note: d.note } });
    await logActivity(ctx.u.name, "updated step", "steps", d.id, d.title);
  } else {
    const last = await prisma.step.findFirst({ where: { playbookId: d.playbookId }, orderBy: { x: "desc" } });
    const s = await prisma.step.create({ data: {
      playbookId: d.playbookId, title: d.title, kind: d.kind, role: d.role, tool: d.tool, note: d.note,
      x: d.x ?? (last ? last.x + 210 : 24), y: d.y ?? (last ? last.y : 64),
    } });
    await logActivity(ctx.u.name, "added step", "steps", s.id, d.title);
  }
  revalidatePath("/workflows", "layout");
  return { ok: true };
}

export async function deleteStep(id: number): Promise<ActionResult> {
  const s = await prisma.step.findUnique({ where: { id } });
  if (!s) return { ok: false, error: "Step not found." };
  const ctx = await editorFor(s.playbookId);
  if ("error" in ctx) return { ok: false, error: ctx.error };
  await prisma.step.delete({ where: { id } });
  await logActivity(ctx.u.name, "deleted step", "steps", id, s.title);
  revalidatePath("/workflows", "layout");
  return { ok: true };
}

export async function moveStep(id: number, x: number, y: number): Promise<ActionResult> {
  const s = await prisma.step.findUnique({ where: { id } });
  if (!s) return { ok: false, error: "Step not found." };
  const ctx = await editorFor(s.playbookId);
  if ("error" in ctx) return { ok: false, error: ctx.error };
  await prisma.step.update({ where: { id }, data: { x: Math.max(8, Math.round(x)), y: Math.max(48, Math.round(y)) } });
  return { ok: true };
}

export async function moveSection(playbookId: number, x: number, y: number): Promise<ActionResult> {
  const ctx = await editorFor(playbookId);
  if ("error" in ctx) return { ok: false, error: ctx.error };
  await prisma.playbook.update({ where: { id: playbookId }, data: { canvasX: Math.round(x), canvasY: Math.round(y) } });
  return { ok: true };
}

export async function connectSteps(fromId: number, toId: number): Promise<ActionResult> {
  if (fromId === toId) return { ok: false, error: "A step can't connect to itself." };
  const [a, b] = await Promise.all([prisma.step.findUnique({ where: { id: fromId } }), prisma.step.findUnique({ where: { id: toId } })]);
  if (!a || !b) return { ok: false, error: "Step not found." };
  for (const s of [a, b]) {
    const ctx = await editorFor(s.playbookId);
    if ("error" in ctx) return { ok: false, error: ctx.error };
  }
  await prisma.connection.upsert({ where: { fromId_toId: { fromId, toId } }, update: {}, create: { fromId, toId } });
  revalidatePath("/workflows", "layout");
  return { ok: true };
}

export async function deleteConnection(id: number): Promise<ActionResult> {
  const c = await prisma.connection.findUnique({ where: { id }, include: { from: true } });
  if (!c) return { ok: true };
  const ctx = await editorFor(c.from.playbookId);
  if ("error" in ctx) return { ok: false, error: ctx.error };
  await prisma.connection.delete({ where: { id } });
  revalidatePath("/workflows", "layout");
  return { ok: true };
}
