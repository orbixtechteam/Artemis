import { z } from "zod";
import { AUTOMATION_KINDS, KNOWLEDGE_KINDS, RULE_KINDS, RULE_STATUSES, STATUSES } from "./constants";
import type { EntityKey } from "./fields";

const id = z.preprocess((v) => (v === "" || v == null ? null : Number(v)), z.number().int().nullable());
const str = z.string().trim().default("");
const date = z.preprocess((v) => (v === "" ? null : v), z.string().nullable().optional());
const int = z.preprocess((v) => Number(v || 0), z.number().int().min(0));
const bool = z.preprocess((v) => v === true || v === "on" || v === "true" || v === 1, z.boolean());

export const SCHEMAS: Record<EntityKey, z.ZodTypeAny> = {
  departments: z.object({ name: z.string().trim().min(1, "Fill in the name."), owner: str, agent: str, description: str, position: int }),
  playbooks: z.object({
    name: z.string().trim().min(1, "Fill in the name."), departmentId: id, owner: str,
    status: z.enum(STATUSES), autonomy: z.enum(["green", "amber", "red"]),
    trigger: str, purpose: str, driveLink: str, testsPassed: int, testsTotal: int,
  }),
  rules: z.object({
    text: z.string().trim().min(1, "Write the rule."), departmentId: id, playbookId: id,
    kind: z.enum(RULE_KINDS), status: z.enum(RULE_STATUSES), source: str, owner: str, ruleDate: date,
  }),
  lessons: z.object({
    what: z.string().trim().min(1, "Describe what went wrong."), reason: str, fix: str,
    departmentId: id, playbookId: id, owner: str, lessonDate: date,
  }),
  knowledge: z.object({
    name: z.string().trim().min(1, "Fill in the name."), departmentId: id, kind: z.enum(KNOWLEDGE_KINDS),
    link: str, owner: str, description: str, patientData: bool, reviewedAt: date,
  }),
  automations: z.object({
    name: z.string().trim().min(1, "Fill in the name."), kind: z.enum(AUTOMATION_KINDS), schedule: str,
    playbookId: id, delivery: str, enabled: bool, notes: str,
  }),
};
