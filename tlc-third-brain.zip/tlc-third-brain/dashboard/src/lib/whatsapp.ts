import "server-only";
import fs from "node:fs";
import { prisma } from "./db";
import type { CurrentUser } from "./auth";

const API = "https://api.periskope.app/v1";
const CONFIG = process.env.OPENCLAW_CONFIG || "/root/.openclaw/openclaw.json";

/** The org's Periskope API key: PERISKOPE_API_KEY, else the one Jarvis already uses. */
function apiKey(): string {
  if (process.env.PERISKOPE_API_KEY) return process.env.PERISKOPE_API_KEY;
  try { const k = JSON.parse(fs.readFileSync(CONFIG, "utf8")).mcp?.servers?.periskope?.env?.PERISKOPE_API_KEY; if (k) return k; } catch { /* no config here */ }
  throw new Error("Periskope isn't set up on this server (PERISKOPE_API_KEY).");
}

async function call(phone: string, path: string, init?: RequestInit) {
  for (let i = 0; i < 3; i++) {
    const r = await fetch(`${API}${path}`, { ...init, headers: { authorization: `Bearer ${apiKey()}`, "x-phone": phone, "content-type": "application/json", ...(init?.headers ?? {}) } });
    if ((r.status === 429 || r.status >= 500) && i < 2) { await new Promise((res) => setTimeout(res, 1500 * (i + 1))); continue; }
    const t = await r.text();
    if (!r.ok) throw new Error(`Periskope ${r.status}: ${t.slice(0, 200)}`);
    try { return JSON.parse(t); } catch { return t; }
  }
}

const ids = (s: string) => JSON.parse(s || "[]") as number[];

/** Numbers this person may use, with their rights. The owner can use all of them. */
export async function myNumbers(u: CurrentUser) {
  const all = await prisma.whatsappNumber.findMany({ orderBy: { label: "asc" } });
  return all
    .map((n) => ({ id: n.id, phone: n.phone, label: n.label, read: u.role === "owner" || ids(n.readers).includes(u.id) || ids(n.senders).includes(u.id), send: u.role === "owner" || ids(n.senders).includes(u.id) }))
    .filter((n) => n.read);
}

async function pick(u: CurrentUser, number: string | undefined, need: "read" | "send") {
  const mine = await myNumbers(u);
  if (!mine.length) throw new Error("You don't have access to any WhatsApp number. Noah gives access in Settings → WhatsApp numbers.");
  const q = (number ?? "").toLowerCase().replace(/[^\da-z+]/g, "");
  const n = number ? mine.find((x) => x.phone.replace(/[^\d+]/g, "") === q || x.label.toLowerCase().replace(/[^\da-z]/g, "").includes(q.replace(/\+/g, ""))) : mine.length === 1 ? mine[0] : undefined;
  if (!n) throw new Error(number ? `You have no access to the WhatsApp number "${number}". Yours: ${mine.map((x) => x.label).join(", ")}.` : `Which number? You can use: ${mine.map((x) => `${x.label} (${x.phone})`).join(", ")}.`);
  if (need === "send" && !n.send) throw new Error(`You can read ${n.label} but not send from it. Noah can change that in Settings.`);
  return n;
}

type Chat = { chat_id?: string; chat_name?: string; name?: string; is_archived?: boolean; archived?: boolean; unread_count?: number; latest_message?: { body?: string; timestamp?: string; from_me?: boolean }; updated_at?: string };

export async function inbox(u: CurrentUser, number: string | undefined, limit = 20) {
  const n = await pick(u, number, "read");
  const d = await call(n.phone, `/chats?offset=0&limit=${Math.min(limit * 2, 100)}`);
  const chats: Chat[] = Array.isArray(d) ? d : d?.chats ?? d?.data ?? [];
  return { number: n.label, chats: chats.filter((c) => !(c.is_archived ?? c.archived)).slice(0, limit).map((c) => ({
    chat_id: c.chat_id, name: c.chat_name ?? c.name, unread: c.unread_count ?? 0,
    last: (c.latest_message?.body ?? "").slice(0, 160), lastFromMe: c.latest_message?.from_me ?? null, at: c.latest_message?.timestamp ?? c.updated_at,
  })) };
}

export async function findChat(u: CurrentUser, number: string | undefined, name: string) {
  const n = await pick(u, number, "read");
  const words = name.toLowerCase().split(/\s+/).filter(Boolean);
  const hits: { chat_id?: string; name?: string }[] = [];
  for (let offset = 0; offset < 1000 && hits.length < 10; offset += 100) {
    const d = await call(n.phone, `/chats?offset=${offset}&limit=100`);
    const chats: Chat[] = Array.isArray(d) ? d : d?.chats ?? d?.data ?? [];
    for (const c of chats) if (!(c.is_archived ?? c.archived) && words.every((w) => `${c.chat_name ?? c.name ?? ""} ${c.chat_id ?? ""}`.toLowerCase().includes(w))) hits.push({ chat_id: c.chat_id, name: c.chat_name ?? c.name });
    if (chats.length < 100) break;
  }
  return { number: n.label, chats: hits };
}

export async function messages(u: CurrentUser, number: string | undefined, chatId: string, limit = 30) {
  const n = await pick(u, number, "read");
  const meta = await call(n.phone, `/chats/${encodeURIComponent(chatId)}`).catch(() => null) as Chat | null;
  if (meta && (meta.is_archived ?? meta.archived)) throw new Error("That chat is archived and not available.");
  const d = await call(n.phone, `/chats/${encodeURIComponent(chatId)}/messages?offset=0&limit=${Math.min(limit, 100)}`);
  const list: { body?: string; from_me?: boolean; sender_name?: string; timestamp?: string; message_type?: string }[] = Array.isArray(d) ? d : d?.messages ?? d?.data ?? [];
  return { number: n.label, chat: meta?.chat_name ?? chatId, messages: list.map((m) => ({ from: m.from_me ? "us" : m.sender_name ?? "them", at: m.timestamp, text: (m.body ?? `[${m.message_type ?? "media"}]`).slice(0, 2000) })) };
}

const mediaType = (mime: string) => (mime.startsWith("image/") ? "image" : mime.startsWith("video/") ? "video" : mime.startsWith("audio/") ? "audio" : "document");

/** Text, and optionally files: the first file carries the text as its caption, the rest follow on their own. */
export async function sendMessage(u: CurrentUser, number: string | undefined, chatId: string, text: string, files: { name: string; mime: string; data: Buffer }[] = []) {
  const n = await pick(u, number, "send");
  if (!files.length) {
    await call(n.phone, `/message/send`, { method: "POST", body: JSON.stringify({ chat_id: chatId, message: text }) });
  } else {
    for (const [i, f] of files.entries()) {
      await call(n.phone, `/message/send`, { method: "POST", body: JSON.stringify({
        chat_id: chatId, ...(i === 0 && text ? { message: text } : {}),
        media: { type: mediaType(f.mime), filename: f.name, mimetype: f.mime, filedata: f.data.toString("base64") } }) });
    }
  }
  return { sent: true, from: n.label, to: chatId, files: files.map((f) => f.name) };
}
