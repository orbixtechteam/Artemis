import "server-only";
import crypto from "node:crypto";
import { prisma } from "./db";
import type { CurrentUser } from "./auth";
import type { Role } from "./constants";
import { runTool, toolSchemas } from "./ops";
import { userIdForAccessToken } from "./oauth";

export const hashToken = (t: string) => crypto.createHash("sha256").update(t).digest("hex");

export async function userForToken(token?: string | null): Promise<CurrentUser | null> {
  if (!token || token.length < 20) return null;
  let userId: number | null = null;
  if (token.startsWith("tba_")) userId = await userIdForAccessToken(token);
  else {
    const t = await prisma.apiToken.findUnique({ where: { tokenHash: hashToken(token) } });
    if (t) { userId = t.userId; await prisma.apiToken.update({ where: { id: t.id }, data: { lastUsed: new Date() } }); }
  }
  if (!userId) return null;
  const u = await prisma.user.findUnique({ where: { id: userId } });
  if (!u || !u.active) return null;
  return { id: u.id, name: u.name, email: u.email, role: u.role as Role, departments: JSON.parse(u.departments) };
}

type Rpc = { jsonrpc: "2.0"; id?: string | number | null; method: string; params?: Record<string, unknown> };
const ok = (id: Rpc["id"], result: unknown) => ({ jsonrpc: "2.0", id, result });
const err = (id: Rpc["id"], code: number, message: string) => ({ jsonrpc: "2.0", id, error: { code, message } });

/** Minimal MCP server over Streamable HTTP (JSON responses): initialize, tools/list, tools/call, ping. */
export async function handleMcp(u: CurrentUser, msg: Rpc) {
  switch (msg.method) {
    case "initialize":
      return ok(msg.id, {
        protocolVersion: String(msg.params?.protocolVersion ?? "2025-06-18"),
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: "third-brain", title: "Third Brain (The Longevity Clinic)", version: "1.0.0" },
        instructions: "Read and change The Longevity Clinic's Third Brain: departments and their people, playbooks, rules, lessons, knowledge bases, workflow steps, and Jarvis's rules. Ask the person before deleting anything.",
      });
    case "ping":
      return ok(msg.id, {});
    case "tools/list":
      return ok(msg.id, { tools: toolSchemas().map((t) => ({ name: t.name, description: t.description, inputSchema: t.input_schema,
        annotations: { readOnlyHint: !t.write, destructiveHint: t.name.startsWith("delete_") } })) });
    case "tools/call": {
      const r = await runTool(u, String(msg.params?.name ?? ""), msg.params?.arguments ?? {});
      return ok(msg.id, { content: [{ type: "text", text: JSON.stringify(r.ok ? r.result : { error: r.error }, null, 2).slice(0, 50000) }], isError: !r.ok });
    }
    default:
      return msg.id === undefined ? null : err(msg.id, -32601, `Method not found: ${msg.method}`);
  }
}
