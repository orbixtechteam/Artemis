import "server-only";

/** The dashboard's public address: APP_URL, else the last address it was reached at, else the clinic's domain. */
const g = globalThis as unknown as { __appUrl?: string };
export function rememberAppUrl(req: Request) {
  if (process.env.APP_URL) return;
  const h = req.headers;
  const host = h.get("x-forwarded-host") ?? h.get("host");
  if (host && !/^(localhost|127\.0\.0\.1)/.test(host)) g.__appUrl = `${h.get("x-forwarded-proto") ?? "https"}://${host}`;
}
export function appUrl(): string {
  return (process.env.APP_URL || g.__appUrl || "https://ai-brain.thelongevityclinic.net").replace(/\/$/, "");
}
export const GUIDE_URL = () => process.env.GUIDE_URL || "https://docs.google.com/document/d/1JSGaVVDeNYFFeEZ5P3dUtLhDwnCLjvmxZ54RMxUb6p8/edit";
