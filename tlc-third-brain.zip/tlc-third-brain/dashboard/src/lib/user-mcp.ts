import "server-only";
import crypto from "node:crypto";
import { prisma } from "./db";
import { appUrl } from "./appurl";
import { dec, enc } from "./connections";

const REDIRECT = () => `${appUrl()}/api/mcp-connect/callback`;

/** MCP_CLIENTS='{"mcp.asana.com":{"client_id":"…","client_secret":"…"}}' for servers that don't allow dynamic registration. */
function preRegistered(url: string): { client_id: string; client_secret?: string } | null {
  try {
    const all = JSON.parse(process.env.MCP_CLIENTS || "{}") as Record<string, { client_id: string; client_secret?: string }>;
    return all[new URL(url).hostname] ?? null;
  } catch { return null; }
}
const b64url = (b: Buffer) => b.toString("base64url");

async function json(url: string, init?: RequestInit) {
  const r = await fetch(url, { ...init, headers: { accept: "application/json", ...(init?.headers ?? {}) } });
  const t = await r.text();
  try { return { ok: r.ok, status: r.status, headers: r.headers, body: JSON.parse(t) }; } catch { return { ok: r.ok, status: r.status, headers: r.headers, body: t }; }
}

/** Probe the server: does it answer without auth, or does it ask for OAuth (401 + metadata)? */
export async function probe(url: string): Promise<{ needsAuth: boolean; resourceMetadata?: string }> {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/json", accept: "application/json, text/event-stream" },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "initialize", params: { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "third-brain", version: "1.0" } } }) });
  if (r.status !== 401 && r.status !== 403) return { needsAuth: false };
  const www = r.headers.get("www-authenticate") ?? "";
  return { needsAuth: true, resourceMetadata: www.match(/resource_metadata="([^"]+)"/)?.[1] };
}

/** Starts OAuth for a server: discovery, dynamic client registration, PKCE. Returns the sign-in URL. */
export async function startOAuth(serverId: number) {
  const s = (await prisma.userMcpServer.findUnique({ where: { id: serverId } }))!;
  const origin = new URL(s.url).origin;
  const p = await probe(s.url);
  const rm = await json(p.resourceMetadata ?? `${origin}/.well-known/oauth-protected-resource`);
  const issuer: string = (rm.ok && rm.body?.authorization_servers?.[0]) || origin;
  let as = await json(`${issuer.replace(/\/$/, "")}/.well-known/oauth-authorization-server`);
  if (!as.ok) as = await json(`${issuer.replace(/\/$/, "")}/.well-known/openid-configuration`);
  if (!as.ok || !as.body?.authorization_endpoint) throw new Error("This server doesn't publish OAuth sign-in details. Use an API key instead.");
  let clientId = s.clientId, clientSecret = s.clientSecret ? dec(s.clientSecret) : "";
  // Servers without dynamic registration (e.g. Asana) use an app the admin registered once: MCP_CLIENTS in .env.
  const pre = preRegistered(s.url);
  if (!clientId && pre) { clientId = pre.client_id; clientSecret = pre.client_secret ?? ""; }
  if (!clientId) {
    if (!as.body.registration_endpoint) throw new Error(`${new URL(s.url).hostname} has no automatic sign-in registration. Create your own app there (redirect URL: ${REDIRECT()}), then remove this server and add it again with your Client ID and secret.`);
    const reg = await json(as.body.registration_endpoint, { method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ client_name: "Third Brain (The Longevity Clinic)", redirect_uris: [REDIRECT()], grant_types: ["authorization_code", "refresh_token"], response_types: ["code"], token_endpoint_auth_method: "none" }) });
    if (!reg.ok || !reg.body?.client_id) throw new Error(`Registration failed (${reg.status}).`);
    clientId = reg.body.client_id; clientSecret = reg.body.client_secret ?? "";
  }
  const verifier = b64url(crypto.randomBytes(32));
  const challenge = b64url(crypto.createHash("sha256").update(verifier).digest());
  const state = `${serverId}.${b64url(crypto.randomBytes(16))}`;
  await prisma.userMcpServer.update({ where: { id: serverId }, data: { authType: "oauth", clientId, clientSecret: enc(clientSecret), tokenEndpoint: as.body.token_endpoint, pkceVerifier: enc(verifier), oauthState: state } });
  return `${as.body.authorization_endpoint}?${new URLSearchParams({ response_type: "code", client_id: clientId, redirect_uri: REDIRECT(), code_challenge: challenge, code_challenge_method: "S256", state, resource: s.url, ...(as.body.scopes_supported?.length ? { scope: as.body.scopes_supported.join(" ") } : {}) })}`;
}

export async function finishOAuth(userId: number, state: string, code: string) {
  const id = Number(state.split(".")[0]);
  const s = await prisma.userMcpServer.findUnique({ where: { id } });
  if (!s || s.userId !== userId || s.oauthState !== state) throw new Error("This sign-in link doesn't match. Try again.");
  const t = await json(s.tokenEndpoint, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({
    grant_type: "authorization_code", code, redirect_uri: REDIRECT(), client_id: s.clientId, code_verifier: dec(s.pkceVerifier), resource: s.url,
    ...(s.clientSecret ? { client_secret: dec(s.clientSecret) } : {}) }) });
  if (!t.ok || !t.body?.access_token) throw new Error(`Sign-in failed: ${t.body?.error_description ?? t.body?.error ?? t.status}`);
  await prisma.userMcpServer.update({ where: { id }, data: {
    accessToken: enc(t.body.access_token), refreshToken: enc(t.body.refresh_token ?? ""), expiresAt: t.body.expires_in ? new Date(Date.now() + t.body.expires_in * 1000) : null,
    pkceVerifier: "", oauthState: "", status: "connected", lastError: "" } });
  return s.name;
}

async function freshToken(s: Awaited<ReturnType<typeof prisma.userMcpServer.findFirstOrThrow>>) {
  if (s.authType === "none") return "";
  if (s.authType === "bearer") return dec(s.accessToken);
  if (s.expiresAt && s.expiresAt.getTime() < Date.now() + 60_000 && s.refreshToken) {
    const t = await json(s.tokenEndpoint, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({
      grant_type: "refresh_token", refresh_token: dec(s.refreshToken), client_id: s.clientId, resource: s.url, ...(s.clientSecret ? { client_secret: dec(s.clientSecret) } : {}) }) });
    if (!t.ok || !t.body?.access_token) {
      await prisma.userMcpServer.update({ where: { id: s.id }, data: { status: "needs_login", lastError: "Sign-in expired" } });
      return null;
    }
    await prisma.userMcpServer.update({ where: { id: s.id }, data: { accessToken: enc(t.body.access_token), refreshToken: t.body.refresh_token ? enc(t.body.refresh_token) : s.refreshToken,
      expiresAt: t.body.expires_in ? new Date(Date.now() + t.body.expires_in * 1000) : null } });
    return t.body.access_token as string;
  }
  return dec(s.accessToken);
}

/** The person's connected MCP servers, in the shape the Anthropic Messages API takes (mcp_servers). */
export async function mcpServersFor(userId: number) {
  const rows = await prisma.userMcpServer.findMany({ where: { userId, status: "connected" } });
  const out: { type: "url"; url: string; name: string; authorization_token?: string }[] = [];
  for (const s of rows) {
    const token = await freshToken(s);
    if (token === null) continue;
    out.push({ type: "url", url: s.url, name: s.name.replace(/[^\w-]+/g, "_").slice(0, 40) || `server_${s.id}`, ...(token ? { authorization_token: token } : {}) });
  }
  return out;
}

export async function listUserMcp(userId: number) {
  return (await prisma.userMcpServer.findMany({ where: { userId }, orderBy: { createdAt: "asc" } })).map((s) => ({ id: s.id, name: s.name, url: s.url, authType: s.authType, status: s.status, lastError: s.lastError }));
}

/** Adds a server; returns the sign-in URL when it needs OAuth. */
export const MCP_PRESETS = [
  { name: "Asana", url: "https://mcp.asana.com/v2/mcp" },
  { name: "Notion", url: "https://mcp.notion.com/mcp" },
  { name: "Linear", url: "https://mcp.linear.app/mcp" },
  { name: "monday.com", url: "https://mcp.monday.com/mcp" },
  { name: "Fathom", url: "https://api.fathom.ai/mcp" },
  { name: "Periskope", url: "https://api.periskope.app/mcp", whatsapp: true },
];
const isWhatsApp = (url: string) => /periskope|whatsapp|wa\.me|wati|twilio/i.test(url);

export async function addUserMcp(userId: number, name: string, url: string, apiKey?: string, client?: { id: string; secret?: string }) {
  const u = new URL(url);
  if (isWhatsApp(url)) {
    const me = await prisma.user.findUnique({ where: { id: userId } });
    if (me?.role !== "owner" && !me?.whatsapp) throw new Error("WhatsApp tools (like Periskope) are only for people Noah has allowed. Ask Noah to turn on WhatsApp for you in Settings.");
  }
  if (u.protocol !== "https:") throw new Error("Use an https:// address.");
  if (/^(localhost|127\.|10\.|192\.168\.|169\.254\.)/.test(u.hostname)) throw new Error("Private network addresses aren't allowed.");
  const row = await prisma.userMcpServer.create({ data: { userId, name: name.trim().slice(0, 60), url,
    ...(client?.id ? { clientId: client.id.trim(), clientSecret: enc((client.secret ?? "").trim()) } : {}) } });
  if (apiKey) {
    await prisma.userMcpServer.update({ where: { id: row.id }, data: { authType: "bearer", accessToken: enc(apiKey.trim()), status: "connected" } });
    return { id: row.id, connected: true };
  }
  const p = await probe(url).catch((e: Error) => { throw new Error(`Couldn't reach the server: ${e.message}`); });
  if (!p.needsAuth) { await prisma.userMcpServer.update({ where: { id: row.id }, data: { status: "connected" } }); return { id: row.id, connected: true }; }
  return { id: row.id, connected: false, signIn: `${appUrl()}/api/mcp-connect/start?id=${row.id}` };
}

/** Called when the Anthropic API can't reach a server: it stops being used until the person reconnects it. */
export async function markMcpBroken(userId: number, url: string, error: string) {
  await prisma.userMcpServer.updateMany({ where: { userId, url }, data: { status: "error", lastError: error } });
}
