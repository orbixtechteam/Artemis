export const STATUSES = ["idea", "draft", "testing", "live", "paused"] as const;
export const AUTONOMY = {
  green: "AI does it alone",
  amber: "AI drafts, a person approves",
  red: "Never alone",
} as const;
export const RULE_KINDS = ["policy", "fact", "style", "preference"] as const;
export const RULE_STATUSES = ["active", "candidate", "rejected", "superseded"] as const;
export const KNOWLEDGE_KINDS = ["folder", "doc", "sheet", "file", "system", "other"] as const;
export const AUTOMATION_KINDS = ["schedule", "event", "command"] as const;
export const ROLES = {
  owner: "Owner",
  admin: "Admin: sees and edits everything",
  editor: "Editor: edits own departments",
  viewer: "Viewer: reads own departments",
} as const;
export type Role = keyof typeof ROLES;

export const STEP_KINDS = ["person", "automation", "ai_agent", "empty"] as const;
export type StepKind = (typeof STEP_KINDS)[number];
export const STEP_KIND_LABEL: Record<StepKind, string> = {
  person: "Person", automation: "Automation", ai_agent: "AI agent", empty: "Empty",
};
