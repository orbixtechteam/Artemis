import "server-only";
import { prisma } from "./db";

/**
 * Which work belongs to Jarvis. Jarvis runs Noah's own departments (agent "Jarvis", e.g. Chief of Staff)
 * and follows company-wide rules (no department, or "Company"). Everything else, Sales included, is run
 * by its own department and never reaches Jarvis's rules.md or jobs.
 */
export async function jarvisRunsDepartment(departmentId: number | null | undefined): Promise<boolean> {
  if (!departmentId) return true;
  const d = await prisma.department.findUnique({ where: { id: departmentId } });
  if (!d) return true;
  if (/jarvis/i.test(d.agent) || d.name === "Company") return true;
  if (d.parentId) return jarvisRunsDepartment(d.parentId).then((up: boolean) => up && !/sales/i.test(d.name));
  return false;
}

/** Sales work never goes to Jarvis (Noah, 18 Nov 2026), even without a department attached. */
export const SALES_WORK = /\b(sales?|won|not won|payment summar|follow.?up email|non.?buyer|upsell|lead|aov|ltv|customer value)\b/i;
