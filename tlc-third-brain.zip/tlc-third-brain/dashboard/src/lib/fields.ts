import { AUTOMATION_KINDS, AUTONOMY, KNOWLEDGE_KINDS, RULE_KINDS, RULE_STATUSES, STATUSES } from "./constants";

export type Option = { value: string; label: string };
export type Field = {
  key: string;
  label: string;
  type?: "text" | "textarea" | "number" | "date" | "select" | "checkbox";
  options?: "departments" | "playbooks" | Option[];
  required?: boolean;
};
export type EntityKey = "departments" | "playbooks" | "rules" | "lessons" | "knowledge" | "automations";

const opts = (xs: readonly string[]): Option[] => xs.map((x) => ({ value: x, label: x }));

export const ENTITY_FORMS: Record<EntityKey, { title: string; fields: Field[] }> = {
  departments: { title: "department", fields: [
    { key: "name", label: "Name", required: true },
    { key: "owner", label: "Owner" },
    { key: "agent", label: "Agent" },
    { key: "position", label: "Order on the map", type: "number" },
    { key: "description", label: "What this department does", type: "textarea" },
  ] },
  playbooks: { title: "playbook", fields: [
    { key: "name", label: "Name", required: true },
    { key: "departmentId", label: "Department", type: "select", options: "departments" },
    { key: "owner", label: "Owner" },
    { key: "status", label: "Status", type: "select", options: opts(STATUSES) },
    { key: "autonomy", label: "Autonomy", type: "select", options: Object.entries(AUTONOMY).map(([value, l]) => ({ value, label: `${value}: ${l}` })) },
    { key: "trigger", label: "What starts it" },
    { key: "purpose", label: "What it produces", type: "textarea" },
    { key: "driveLink", label: "Link to SKILL.md in Drive" },
    { key: "testsPassed", label: "Tests passed", type: "number" },
    { key: "testsTotal", label: "Tests total", type: "number" },
  ] },
  rules: { title: "rule", fields: [
    { key: "text", label: "Rule", type: "textarea", required: true },
    { key: "departmentId", label: "Department", type: "select", options: "departments" },
    { key: "playbookId", label: "Playbook", type: "select", options: "playbooks" },
    { key: "kind", label: "Kind", type: "select", options: opts(RULE_KINDS) },
    { key: "status", label: "Status", type: "select", options: opts(RULE_STATUSES) },
    { key: "source", label: "Source (who said it, which call or edit)" },
    { key: "owner", label: "Owner" },
    { key: "ruleDate", label: "Date", type: "date" },
  ] },
  lessons: { title: "lesson", fields: [
    { key: "what", label: "What went wrong", type: "textarea", required: true },
    { key: "reason", label: "Why, in the owner's words" },
    { key: "fix", label: "The fix", type: "textarea" },
    { key: "departmentId", label: "Department", type: "select", options: "departments" },
    { key: "playbookId", label: "Playbook", type: "select", options: "playbooks" },
    { key: "owner", label: "Owner" },
    { key: "lessonDate", label: "Date", type: "date" },
  ] },
  knowledge: { title: "knowledge base", fields: [
    { key: "name", label: "Name", required: true },
    { key: "departmentId", label: "Department", type: "select", options: "departments" },
    { key: "kind", label: "Kind", type: "select", options: opts(KNOWLEDGE_KINDS) },
    { key: "link", label: "Link" },
    { key: "owner", label: "Owner" },
    { key: "description", label: "What's in it", type: "textarea" },
    { key: "patientData", label: "Contains patient data", type: "checkbox" },
    { key: "reviewedAt", label: "Last reviewed", type: "date" },
  ] },
  automations: { title: "automation", fields: [
    { key: "name", label: "Name", required: true },
    { key: "kind", label: "Kind", type: "select", options: opts(AUTOMATION_KINDS) },
    { key: "schedule", label: "When it runs" },
    { key: "playbookId", label: "Playbook", type: "select", options: "playbooks" },
    { key: "delivery", label: "Where results go" },
    { key: "enabled", label: "Enabled", type: "checkbox" },
    { key: "notes", label: "Notes", type: "textarea" },
  ] },
};
