import "server-only";
import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { prisma } from "./db";
import type { Role } from "./constants";

export const COOKIE = "ab_session";
const DAYS = Number(process.env.SESSION_DAYS || 14);

export type CurrentUser = {
  id: number; name: string; email: string; role: Role; departments: number[];
};

export const hashPassword = (pw: string) => bcrypt.hash(pw, 12);
export const checkPassword = (pw: string, hash: string) => bcrypt.compare(pw, hash);
export const randomPassword = () => crypto.randomBytes(12).toString("base64url");

export async function createSession(userId: number) {
  const token = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + DAYS * 86400_000);
  await prisma.session.create({ data: { token, userId, expiresAt } });
  await prisma.session.deleteMany({ where: { expiresAt: { lt: new Date() } } });
  (await cookies()).set(COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", expires: expiresAt, secure: process.env.COOKIE_SECURE === "true" || (process.env.APP_URL ?? "").startsWith("https://") });
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (token) await prisma.session.deleteMany({ where: { token } });
  jar.delete(COOKIE);
}

export async function currentUser(): Promise<CurrentUser | null> {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  const s = await prisma.session.findUnique({ where: { token }, include: { user: true } });
  if (!s || s.expiresAt < new Date() || !s.user.active) return null;
  const u = s.user;
  return { id: u.id, name: u.name, email: u.email, role: u.role as Role, departments: JSON.parse(u.departments) as number[] };
}

export async function requireUser(): Promise<CurrentUser> {
  const u = await currentUser();
  if (!u) redirect("/login");
  return u;
}

export const isAdmin = (u: CurrentUser) => u.role === "owner" || u.role === "admin";
export const canEdit = (u: CurrentUser) => isAdmin(u) || u.role === "editor";

/** Prisma filter on departmentId for the user's scope (null = everything). */
export function deptScope(u: CurrentUser): { departmentId?: { in: number[] } } {
  return isAdmin(u) ? {} : { departmentId: { in: u.departments } };
}
export const inScope = (u: CurrentUser, departmentId: number | null | undefined) =>
  isAdmin(u) || (departmentId != null && u.departments.includes(departmentId));
