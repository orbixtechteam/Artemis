import "server-only";
import fs from "node:fs";
import { prisma } from "./db";
import { IMAGE_TYPES, isText } from "./files";
import { runTool, toolSchemas } from "./ops";
import { logUsage } from "./usage";
import { markMcpBroken, mcpServersFor } from "./user-mcp";
import type { CurrentUser } from "./auth";

export type ChatTurn = { role: "user" | "assistant"; content: string; attachments?: number[] };
export type ToolEvent = { tool: string; ok: boolean; write: boolean; summary: string; outboxId?: number };

const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5";

const system = (u: CurrentUser, dept?: { id: number; name: string } | null) => `You are the assistant inside The Longevity Clinic's Third Brain dashboard.${dept ? `
This conversation is about the ${dept.name} department (id ${dept.id}). Default to it when the person doesn't name a department.` : ""}
Today is ${new Date().toISOString().slice(0, 10)}.
You help ${u.name} (role: ${u.role}) read and change the dashboard: departments, the people who can see them, playbooks, rules, lessons from errors, knowledge bases and workflow steps. You can also write rules and lessons into Jarvis (OpenClaw) on the server and propose playbook changes.

How you work:
- Use the tools for every fact; never invent ids, names or numbers. Look things up first when you are unsure which item the person means.
- Make the change the person asks for, then say in one or two short sentences what changed.
- Deleting anything needs the person's explicit OK in this conversation. Ask first; only then call the tool with confirmed: true.
- New rules and lessons go to Jarvis too (apply_to_jarvis true) unless the person says otherwise.
- If a tool says the person's role can't do something, tell them plainly who can.
- Client and patient details may be stored when useful for the work (Noah's decision). Never store passwords, card numbers or API keys.
- People: find emails yourself with find_people (Slack directory); never ask Noah for an email you can look up. Access is always a one-time 'set your own password' link, never a password. Send it with send_via (Slack DM or WhatsApp link) when the admin asks, otherwise give the admin the link to send one to one. Never post access links in group channels. list_people shows who has signed in (lastSignIn).
- Sub-departments: create_department with a parent; people and playbooks can be added to a sub-department like any department.
- WhatsApp: use whatsapp_numbers / whatsapp_inbox / whatsapp_find_chat / whatsapp_messages / whatsapp_send. Each person sees only the numbers assigned to them (read and/or send). Admins and Noah assign numbers to one or more people with whatsapp_set_number; only Noah changes access to his own number. Never show archived chats. Sending always needs the person's explicit yes.
- Files the person attaches are listed with their attachment id. You can read images, PDFs and text files directly. When they ask to put a file in Drive, call upload_to_drive with the attachment_id (folders live inside Jarvis/ in Noah's Drive) and give them the link.
- Skills: write new ones with create_skill; when someone uploads existing SKILL.md files, use import_skill once per file and keep the content as it is. Both are proposals until approved; when the department's editor or an admin says to approve, use approve_playbook (it publishes the skill for Jarvis and Drive automatically). For clinical jobs ask whether a doctor approved it. To change a skill: read_skill, then update_skill with the full new text, then approve_playbook. Never save skills to someone's own Drive: Jarvis only uses the brain's copy; Drive copies are for reading.
- Jarvis's memory (admins only): read before replacing; never store patient data, passwords or keys.
- When something waits for approval (queue_email, queue_slack_message, or a queued send), it appears in this chat with Approve and Reject buttons; tell the person they can approve it right here.
- The person's OWN accounts: 'my email', 'my calendar', 'post as me', 'search my Slack' → my_email_search / my_email_read / my_email_send / my_calendar / my_drive_search / my_drive_read / my_drive_save / my_slack_send / my_slack_search. People can connect several Google and Slack accounts (e.g. their own Gmail plus clinic@); pass account (the email) to pick one, otherwise the first is used. If something isn't connected, tell them: Settings → My connections → Connect / Add another. Noah's mailbox and other team tools go through ask_jarvis.
- Jarvis only does the work of departments he runs (Chief of Staff) and follows company-wide rules. Sales and every other department run their own rules: never send their rules to Jarvis or give Jarvis their tasks.
- Requests like "whenever X happens, send/tell/do Y" or "every Monday at 9 send me…" → create_automation (state the rule in one sentence first). The payment-summary-to-WhatsApp case is: trigger slack_bot_reply in sales-payment-made, action whatsapp_noah, drawn on the Payment summary playbook.
- Act on the request. Don't gather the same context again in every turn: if earlier messages or tool results in this conversation already cover it, use them. When the person says "go ahead", do the task now instead of asking again.
- Word documents: write the full content, then call create_word_document and give the download link (and the Drive copy). Never say you can't make a .docx.
- If a tool fails, say which one and what it means in one line, then continue with what you can do.
- Files attached in the chat can be sent with whatsapp_send, send_email, my_email_send, send_slack_message and my_slack_send (attachment_ids). Name the files when you ask for confirmation.
- Payment links: whop_create_link / whop_update_link / whop_list_links / whop_payments. Take prices only from the 'prices products' sheet; confirm every link before creating it. Payments are posted in #finance-payments-invoices automatically when Whop reports them.
- To post in Slack as the clinic's bot use send_slack_message; to send an email use send_email. Always show the exact text and recipient first and send only after a clear yes (confirmed: true).
- The person may have their own MCP servers connected (their tools appear with a server name); use them for their requests about those tools.
- Each person works with their OWN accounts (my_* tools, send_email from their own mailbox). Noah can use anyone's accounts by passing as_user (their email). Jarvis (ask_jarvis) is Noah's own accounts and only Noah can use it.
- For Noah, anything else outside the dashboard (his WhatsApp, his email, calendar, Asana, calls, research) can go through ask_jarvis: Jarvis has those connections. Pass the full request; show Jarvis's answer. Don't say you can't reach WhatsApp or email without trying ask_jarvis first (owner and admins only).
- New tool connections: use request_tool_connection; you never set credentials up yourself.
- Format answers in Markdown: short paragraphs, lists or small tables when they help.
- Answer in the language the person writes in. Be brief.`;

export async function chat(u: CurrentUser, turns: ChatTurn[], opts: { department?: { id: number; name: string } | null; onEvent?: (e: ToolEvent) => void } = {}): Promise<{ reply: string; events: ToolEvent[] }> {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return { reply: "The AI isn't set up yet: ANTHROPIC_API_KEY is missing in .env.", events: [] };
  // Prompt caching: the 50+ tool definitions and the system prompt are cached, so follow-up calls read them at the cache price.
  const tools = toolSchemas().map(({ write: _w, ...t }, i, all) => (i === all.length - 1 ? { ...t, cache_control: { type: "ephemeral" } } : t));
  type Block = { type: string; [k: string]: unknown };
  const recent = turns.slice(-20);
  const messages: { role: "user" | "assistant"; content: string | Block[] }[] = [];
  for (const [i, t] of recent.entries()) {
    if (t.role === "user" && t.attachments?.length) messages.push({ role: "user", content: await withFiles(u, t, i === recent.length - 1) });
    else messages.push({ role: t.role, content: t.content });
  }
  const events: ToolEvent[] = [];
  // The person's own MCP servers (Settings → My MCP servers), run by the Anthropic API's MCP connector.
  let mcpServers = await mcpServersFor(u.id).catch(() => []);

  for (let round = 0; round < 10; round++) {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01",
        ...(mcpServers.length ? { "anthropic-beta": process.env.MCP_BETA || "mcp-client-2025-11-20" } : {}) },
      body: JSON.stringify({ model: MODEL, max_tokens: Number(process.env.CHAT_MAX_TOKENS || 16000), system: [{ type: "text", text: system(u, opts.department), cache_control: { type: "ephemeral" } }], tools: [...tools, ...mcpServers.map((m) => ({ type: "mcp_toolset", mcp_server_name: m.name }))], messages, ...(mcpServers.length ? { mcp_servers: mcpServers } : {}) }),
    });
    if (!res.ok) {
      const errText = await res.text();
      // A personal MCP server that can't be reached must not block the chat: mark it and retry without it.
      const bad = errText.match(/mcp_servers\[(\d+)\]/);
      if (res.status === 400 && bad && mcpServers[Number(bad[1])]) {
        const broken = mcpServers[Number(bad[1])];
        await markMcpBroken(u.id, broken.url, errText.slice(0, 200));
        mcpServers = mcpServers.filter((_, i) => i !== Number(bad[1]));
        const ev: ToolEvent = { tool: broken.name, ok: false, write: false, summary: `${broken.name} didn't respond, so I continued without it. Reconnect it in Settings → My MCP servers.` };
        events.push(ev); opts.onEvent?.(ev);
        round--; continue;
      }
      return { reply: `The AI request failed (${res.status}): ${errText.slice(0, 300)}`, events };
    }
    const data = (await res.json()) as { content: Block[]; stop_reason: string; model?: string; usage?: Record<string, number> };
    if (data.usage) await logUsage({ source: "dashboard", job: "Dashboard chat", model: data.model ?? MODEL, userId: u.id,
      input: data.usage.input_tokens ?? 0, output: data.usage.output_tokens ?? 0,
      cache: (data.usage.cache_read_input_tokens ?? 0) + (data.usage.cache_creation_input_tokens ?? 0) });
    messages.push({ role: "assistant", content: data.content });
    for (const b of data.content.filter((x) => x.type === "mcp_tool_use")) {
      const res = data.content.find((x) => x.type === "mcp_tool_result" && x.tool_use_id === b.id);
      const ev: ToolEvent = { tool: `${b.server_name}: ${b.name}`, ok: !(res as { is_error?: boolean } | undefined)?.is_error, write: false, summary: `${b.server_name}: ${String(b.name).replace(/_/g, " ")}` };
      events.push(ev); opts.onEvent?.(ev);
    }
    // Cut off by the length limit (e.g. a long document written into a tool call): drop the partial turn and redo it shorter.
    if (data.stop_reason === "max_tokens") {
      messages.push({ role: "user", content: "Your last reply was cut off by the length limit before it finished. Do it again, more concisely: for a document, keep it under about 1,800 words and put it straight into the tool call." });
      continue;
    }
    const calls = data.content.filter((b) => b.type === "tool_use");
    if (data.stop_reason !== "tool_use" || !calls.length) {
      const reply = data.content.filter((b) => b.type === "text").map((b) => String(b.text)).join("\n").trim();
      return { reply: reply || "I finished the steps but didn't write an answer. Ask again, or say exactly what you want me to produce.", events };
    }
    const results: Block[] = [];
    for (const c of calls) {
      const r = await runTool(u, String(c.name), c.input);
      const queued = r.ok && r.result && typeof r.result === "object" ? (r.result as { queued?: unknown }).queued : undefined;
      const ev: ToolEvent = { tool: String(c.name), ok: r.ok, write: !!r.write, summary: r.ok ? summarize(String(c.name), c.input) : `${String(c.name).replace(/_/g, " ")}: ${String(r.error)}`, ...(typeof queued === "number" ? { outboxId: queued } : {}) };
      events.push(ev);
      opts.onEvent?.(ev);
      results.push({ type: "tool_result", tool_use_id: c.id, is_error: !r.ok, content: JSON.stringify(r.ok ? r.result : { error: r.error }).slice(0, 20000) });
    }
    messages.push({ role: "user", content: results });
  }
  return { reply: "I stopped after too many steps. Try a smaller request.", events };
}

function summarize(tool: string, input: unknown) {
  const i = (input ?? {}) as Record<string, unknown>;
  const what = i.name ?? i.title ?? i.text ?? i.what ?? i.playbook ?? i.department ?? i.email ?? i.id ?? "";
  return `${tool.replace(/_/g, " ")}${what ? `: ${String(what).slice(0, 80)}` : ""}`;
}

type FileBlock = { type: string; [k: string]: unknown };
/** The newest message gets the files themselves; older ones only a short note, to keep requests small. */
async function withFiles(u: CurrentUser, t: ChatTurn, latest: boolean): Promise<FileBlock[]> {
  const files = await prisma.attachment.findMany({ where: { id: { in: t.attachments ?? [] }, ...(u.role === "owner" || u.role === "admin" ? {} : { userId: u.id }) } });
  const blocks: FileBlock[] = [];
  const notes: string[] = [];
  for (const f of files) {
    notes.push(`Attached file: ${f.name} (${f.mime}, ${Math.round(f.size / 1024)} KB), attachment_id ${f.id}${f.driveLink ? `, in Drive: ${f.driveLink}` : ""}`);
    if (!latest || !fs.existsSync(f.path)) continue;
    if (IMAGE_TYPES.includes(f.mime) && f.size <= 5 * 1024 * 1024)
      blocks.push({ type: "image", source: { type: "base64", media_type: f.mime, data: fs.readFileSync(f.path).toString("base64") } });
    else if (f.mime === "application/pdf")
      blocks.push({ type: "document", source: { type: "base64", media_type: "application/pdf", data: fs.readFileSync(f.path).toString("base64") }, title: f.name });
    else if (isText(f.mime, f.name))
      blocks.push({ type: "text", text: `Content of ${f.name}:\n${fs.readFileSync(f.path, "utf8").slice(0, 100_000)}` });
  }
  return [...blocks, { type: "text", text: `${notes.join("\n")}\n\n${t.content || "(no message)"}` }];
}
