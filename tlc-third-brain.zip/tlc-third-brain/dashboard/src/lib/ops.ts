import "server-only";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { execFile } from "node:child_process";
import { z } from "zod/v4";
import { prisma, logActivity } from "./db";
import { hashPassword, inScope, isAdmin, canEdit, randomPassword, type CurrentUser } from "./auth";
import { slugify } from "./utils";
import { uploadToDrive } from "./files";
import { appUrl, GUIDE_URL } from "./appurl";
import { ActionSchema, describeRule, TriggerSchema } from "./automations";
import { jarvisRunsDepartment, SALES_WORK } from "./jarvis-scope";
import { cachedStatus, collectStatus, runJobNow } from "./status";

/**
 * One list of tools for the dashboard's AI chat and for the MCP server.
 * Every tool runs with the permissions of the signed-in person (or the owner of the MCP token).
 */

const WS = process.env.WORKSPACE || "/root/.openclaw/workspace";
const sha = (s: string) => crypto.createHash("sha1").update(s).digest("hex").slice(0, 20);
const today = () => new Date().toISOString().slice(0, 10);

export class ToolError extends Error {}
const fail = (m: string): never => { throw new ToolError(m); };

type Tool<S extends z.ZodType> = {
  name: string;
  description: string;
  input: S;
  write?: boolean;
  run: (u: CurrentUser, input: z.infer<S>) => Promise<unknown>;
};
const tool = <S extends z.ZodType>(t: Tool<S>) => t as unknown as Tool<z.ZodType>;

// ---------- lookups ----------
const ref = z.union([z.number().int(), z.string().min(1)]).describe("Id or name");

async function findDepartment(r: number | string) {
  const d = typeof r === "number"
    ? await prisma.department.findUnique({ where: { id: r } })
    : (await prisma.department.findMany()).find((x) => x.name.toLowerCase() === r.toLowerCase() || String(x.id) === r);
  return d ?? fail(`No department called "${r}".`);
}
async function findPlaybook(r: number | string) {
  const p = typeof r === "number"
    ? await prisma.playbook.findUnique({ where: { id: r } })
    : (await prisma.playbook.findMany()).find((x) => [x.name.toLowerCase(), x.slug].includes(r.toLowerCase()) || String(x.id) === r);
  return p ?? fail(`No playbook called "${r}".`);
}
async function findUserByEmail(email: string) {
  return (await prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } })) ?? fail(`No person with the email ${email}.`);
}

const needEdit = (u: CurrentUser) => { if (!canEdit(u)) fail("Your role can only view."); };
const needAdmin = (u: CurrentUser) => { if (!isAdmin(u)) fail("Only admins can do this."); };
const needScope = (u: CurrentUser, deptId: number | null) => { if (!inScope(u, deptId)) fail("That belongs to a department you can't change."); };
const confirmFirst = (confirmed?: boolean) => { if (!confirmed) fail("Deleting needs the person's explicit OK. Ask them, then call again with confirmed: true."); };
const audit = (u: CurrentUser, action: string, entity: string, id: number | null, detail: string) => logActivity(`${u.name} (AI)`, action, entity, id, detail);

// ---------- Jarvis workspace ----------
function ws(p: string) {
  if (!fs.existsSync(WS)) fail("Jarvis's workspace isn't on this machine. This works on the server only.");
  return path.join(WS, p);
}
function gitCommit(message: string) {
  execFile("git", ["-C", WS, "add", "-A", "rules.md", "playbooks", "playbooks-proposed"], () =>
    execFile("git", ["-C", WS, "commit", "-q", "-m", message], () => undefined));
}
function writeJarvisRule(text: string, kind: string, source: string, date: string) {
  const f = ws("rules.md");
  const line = `- [active] [${kind}] ${text.replace(/\s+/g, " ").trim()} — source: ${source} — ${date}\n`;
  fs.appendFileSync(f, (fs.existsSync(f) && !fs.readFileSync(f, "utf8").endsWith("\n") ? "\n" : "") + line);
  gitCommit(`Rule added from dashboard: ${text.slice(0, 60)}`);
  return sha(text.replace(/\s+/g, " ").trim() + date);
}
function writeJarvisLesson(slug: string, what: string, reason: string, fix: string, date: string) {
  const dir = ws(path.join("playbooks", slug));
  fs.mkdirSync(dir, { recursive: true });
  const f = path.join(dir, "notes.md");
  const header = `# notes.md: ${slug}\n\nDated corrections, newest first. Format: YYYY-MM-DD | what was rejected or changed | reason | fix\n\n`;
  const body = fs.existsSync(f) ? fs.readFileSync(f, "utf8") : header;
  const line = `${date} | ${what} | ${reason} | ${fix}`;
  const at = body.indexOf("\n\n", body.indexOf("Format:"));
  const next = at > -1 ? `${body.slice(0, at + 2)}${line}\n${body.slice(at + 2)}` : `${body}${line}\n`;
  fs.writeFileSync(f, next);
  gitCommit(`Lesson added from dashboard: ${what.slice(0, 60)}`);
  return sha(slug + line);
}

// ---------- tools ----------
export const TOOLS: Tool<z.ZodType>[] = [
  // ----- read -----
  tool({
    name: "get_overview",
    description: "Departments with their playbooks (status, autonomy, tests) and totals. Start here to understand the current state.",
    input: z.object({}),
    run: async (u) => {
      const depts = await prisma.department.findMany({ where: isAdmin(u) ? {} : { id: { in: u.departments } }, include: { playbooks: true }, orderBy: { position: "asc" } });
      return depts.map((d) => ({ id: d.id, name: d.name, owner: d.owner, agent: d.agent,
        playbooks: d.playbooks.map((p) => ({ id: p.id, name: p.name, status: p.status, autonomy: p.autonomy, trigger: p.trigger, tests: p.testsTotal ? `${p.testsPassed}/${p.testsTotal}` : null })) }));
    },
  }),
  tool({
    name: "list_departments",
    description: "All departments the person can see, with owner, agent, description and the people who can see each one.",
    input: z.object({}),
    run: async (u) => {
      const [depts, users] = await Promise.all([prisma.department.findMany({ orderBy: { position: "asc" } }), prisma.user.findMany({ where: { active: true } })]);
      return depts.filter((d) => inScope(u, d.id)).map((d) => ({ ...d, members: users.filter((x) => x.role === "owner" || x.role === "admin" || JSON.parse(x.departments).includes(d.id)).map((x) => `${x.name} <${x.email}> (${x.role})`) }));
    },
  }),
  tool({
    name: "get_playbook",
    description: "One playbook with its steps, connections, rules, lessons and linked automations.",
    input: z.object({ playbook: ref }),
    run: async (u, { playbook }) => {
      const p = await findPlaybook(playbook);
      needScope(u, p.departmentId);
      return prisma.playbook.findUnique({ where: { id: p.id }, include: {
        department: { select: { name: true } }, rules: true, lessons: true, automations: true,
        steps: { include: { outgoing: { select: { id: true, toId: true } } }, orderBy: { x: "asc" } },
      } });
    },
  }),
  tool({
    name: "list_playbooks",
    description: "Playbooks, optionally for one department or status.",
    input: z.object({ department: ref.optional(), status: z.enum(["idea", "draft", "testing", "live", "paused"]).optional() }),
    run: async (u, { department, status }) => {
      const d = department ? await findDepartment(department) : null;
      const rows = await prisma.playbook.findMany({ where: { ...(d ? { departmentId: d.id } : {}), ...(status ? { status } : {}) }, orderBy: { name: "asc" } });
      return rows.filter((p) => inScope(u, p.departmentId));
    },
  }),
  tool({
    name: "list_rules",
    description: "Rules, optionally for one playbook or status.",
    input: z.object({ playbook: ref.optional(), status: z.enum(["active", "candidate", "rejected", "superseded"]).optional() }),
    run: async (u, { playbook, status }) => {
      const p = playbook ? await findPlaybook(playbook) : null;
      const rows = await prisma.rule.findMany({ where: { ...(p ? { playbookId: p.id } : {}), ...(status ? { status } : {}) }, orderBy: { updatedAt: "desc" } });
      return rows.filter((r) => isAdmin(u) || inScope(u, r.departmentId));
    },
  }),
  tool({
    name: "list_lessons",
    description: "Lessons from errors, optionally for one playbook.",
    input: z.object({ playbook: ref.optional() }),
    run: async (u, { playbook }) => {
      const p = playbook ? await findPlaybook(playbook) : null;
      const rows = await prisma.lesson.findMany({ where: p ? { playbookId: p.id } : {}, orderBy: { updatedAt: "desc" }, take: 100 });
      return rows.filter((r) => isAdmin(u) || inScope(u, r.departmentId));
    },
  }),
  tool({
    name: "list_knowledge",
    description: "Knowledge bases (folders, docs, sheets) per department.",
    input: z.object({ department: ref.optional() }),
    run: async (u, { department }) => {
      const d = department ? await findDepartment(department) : null;
      const rows = await prisma.knowledge.findMany({ where: d ? { departmentId: d.id } : {}, orderBy: { name: "asc" } });
      return rows.filter((k) => inScope(u, k.departmentId));
    },
  }),
  tool({
    name: "list_automations",
    description: "Jarvis's scheduled jobs with schedule, last run status and errors (read-only; jobs are changed on the server).",
    input: z.object({}),
    run: async () => prisma.automation.findMany({ orderBy: { name: "asc" } }),
  }),
  tool({
    name: "list_people",
    description: "People who can use the dashboard, their role and departments. Admins only.",
    input: z.object({}),
    run: async (u) => {
      needAdmin(u);
      const [users, depts] = await Promise.all([prisma.user.findMany({ orderBy: { name: "asc" } }), prisma.department.findMany()]);
      return users.map((x) => ({ name: x.name, email: x.email, role: x.role, active: x.active, lastSignIn: x.lastLogin ? x.lastLogin.toISOString().slice(0, 16).replace("T", " ") : "never", whatsapp: x.whatsapp,
        departments: x.role === "owner" || x.role === "admin" ? "all" : JSON.parse(x.departments).map((id: number) => depts.find((d) => d.id === id)?.name) }));
    },
  }),

  // ----- departments and people -----
  tool({
    name: "create_department", write: true,
    description: "Add a department, or a sub-department by giving its parent department. Sub-departments have their own people, playbooks and rules. Admins only.",
    input: z.object({ name: z.string().min(1), parent: ref.optional().describe("Parent department, for a sub-department"), owner: z.string().default(""), agent: z.string().default(""), description: z.string().default("") }),
    run: async (u, { parent, ...d }) => {
      needAdmin(u);
      const parentId = parent ? (await findDepartment(parent)).id : null;
      const position = ((await prisma.department.aggregate({ _max: { position: true } }))._max.position ?? 0) + 1;
      const row = await prisma.department.create({ data: { ...d, parentId, position } });
      await audit(u, "created", "departments", row.id, d.name);
      return row;
    },
  }),
  tool({
    name: "update_department", write: true,
    description: "Rename a department or change its owner, agent, description, order, or parent (parent: \"none\" makes it a top-level department again). Admins only.",
    input: z.object({ department: ref, name: z.string().optional(), parent: ref.optional(), owner: z.string().optional(), agent: z.string().optional(), description: z.string().optional(), position: z.number().int().optional() }),
    run: async (u, { department, parent, ...data }) => {
      needAdmin(u);
      const d = await findDepartment(department);
      const parentId = parent === undefined ? undefined : parent === "none" ? null : (await findDepartment(parent)).id;
      if (parentId === d.id) fail("A department can't be its own parent.");
      const row = await prisma.department.update({ where: { id: d.id }, data: { ...data, ...(parentId !== undefined ? { parentId } : {}) } });
      await audit(u, "updated", "departments", d.id, Object.keys(data).join(", "));
      return row;
    },
  }),
  tool({
    name: "delete_department", write: true,
    description: "Delete a department (its playbooks stay, without a department). Ask the person first, then pass confirmed: true. Admins only.",
    input: z.object({ department: ref, confirmed: z.boolean().optional() }),
    run: async (u, { department, confirmed }) => {
      needAdmin(u); confirmFirst(confirmed);
      const d = await findDepartment(department);
      await prisma.department.delete({ where: { id: d.id } });
      await audit(u, "deleted", "departments", d.id, d.name);
      return { deleted: d.name };
    },
  }),
  tool({
    name: "set_department_people", write: true,
    description: "Choose which editors and viewers can see a department (by email). Admins and the owner always see everything. Admins only.",
    input: z.object({ department: ref, add: z.array(z.string()).default([]), remove: z.array(z.string()).default([]) }),
    run: async (u, { department, add, remove }) => {
      needAdmin(u);
      const d = await findDepartment(department);
      for (const [emails, on] of [[add, true], [remove, false]] as const) for (const e of emails) {
        const x = await findUserByEmail(e);
        const set = new Set<number>(JSON.parse(x.departments));
        if (on) set.add(d.id); else set.delete(d.id);
        await prisma.user.update({ where: { id: x.id }, data: { departments: JSON.stringify([...set]) } });
      }
      await audit(u, "changed people of", "departments", d.id, `${d.name}: +${add.join(", ")} -${remove.join(", ")}`);
      return { department: d.name, added: add, removed: remove };
    },
  }),
  tool({
    name: "create_person", write: true,
    description: "Give someone access to the dashboard with a role (admin, editor, viewer) and departments (or sub-departments). Find their email yourself first with find_people; don't ask for it. No password is ever shown or sent: they get a one-time 'set your own password' link (72 hours). send_via: 'slack' DMs it with how to connect their Claude and the quick guide; 'whatsapp' returns a WhatsApp link for the admin to tap; 'none' returns the link for the admin to send one to one. whatsapp_access lets them use WhatsApp through Jarvis (only the owner can turn it on). Admins only.",
    input: z.object({ name: z.string().min(1), email: z.string().email(), role: z.enum(["admin", "editor", "viewer"]), departments: z.array(ref).default([]),
      send_via: z.enum(["none", "slack", "whatsapp"]).default("none"), phone: z.string().optional(), whatsapp_access: z.boolean().optional() }),
    run: async (u, d) => {
      needAdmin(u);
      if (d.whatsapp_access && u.role !== "owner") fail("Only Noah (the owner) decides who can use WhatsApp.");
      const ids = [];
      for (const r of d.departments) ids.push((await findDepartment(r)).id);
      const pw = randomPassword(); // never shown: the person sets their own password through the link
      const row = await prisma.user.create({ data: { name: d.name, email: d.email.toLowerCase(), role: d.role, departments: JSON.stringify(ids), whatsapp: !!d.whatsapp_access, passwordHash: await hashPassword(pw) } })
        .catch(() => fail("Someone already uses this email."));
      await audit(u, "added person", "users", row.id, `${d.name} (${d.role})`);
      const delivery = await deliverAccess(row.id, d.name, d.email.toLowerCase(), d.send_via, d.phone, "invite");
      return { added: d.email, role: d.role, ...delivery };
    },
  }),
  tool({
    name: "update_person", write: true,
    description: "Change someone's name, role (admin, editor, viewer), departments, or switch their access off/on. reset_password (or send_via) makes a new one-time 'set your own password' link and sends it like create_person. whatsapp_access: only the owner may change it. Admins only; the owner account can't be changed here.",
    input: z.object({ email: z.string(), name: z.string().optional(), role: z.enum(["admin", "editor", "viewer"]).optional(), departments: z.array(ref).optional(), active: z.boolean().optional(),
      reset_password: z.boolean().optional(), send_via: z.enum(["none", "slack", "whatsapp"]).default("none"), phone: z.string().optional(), whatsapp_access: z.boolean().optional() }),
    run: async (u, { email, departments, reset_password, send_via, phone, whatsapp_access, ...d }) => {
      needAdmin(u);
      const x = await findUserByEmail(email);
      if (x.role === "owner") fail("The owner account can only be changed in Settings by the owner.");
      if (whatsapp_access !== undefined) {
        if (u.role !== "owner") fail("Only Noah (the owner) decides who can use WhatsApp.");
        await prisma.user.update({ where: { id: x.id }, data: { whatsapp: whatsapp_access } });
      }
      const ids = departments ? await Promise.all(departments.map(async (r) => (await findDepartment(r)).id)) : undefined;
      await prisma.user.update({ where: { id: x.id }, data: { ...d, ...(ids ? { departments: JSON.stringify(ids) } : {}) } });
      if (d.active === false) await prisma.session.deleteMany({ where: { userId: x.id } });
      let delivery = {};
      if (reset_password || send_via !== "none") delivery = await deliverAccess(x.id, x.name, x.email, send_via, phone, x.lastLogin ? "reset" : "invite");
      await audit(u, reset_password ? "reset password" : "updated person", "users", x.id, email);
      return { updated: email, ...delivery };
    },
  }),

  // ----- playbooks -----
  tool({
    name: "create_playbook", write: true,
    description: "Add a playbook (a recurring job) to a department.",
    input: z.object({ name: z.string().min(1), department: ref, owner: z.string().default(""), status: z.enum(["idea", "draft", "testing", "live", "paused"]).default("idea"),
      autonomy: z.enum(["green", "amber", "red"]).default("amber"), trigger: z.string().default(""), purpose: z.string().default(""), driveLink: z.string().default("") }),
    run: async (u, { department, ...d }) => {
      needEdit(u);
      const dept = await findDepartment(department);
      needScope(u, dept.id);
      const row = await prisma.playbook.create({ data: { ...d, departmentId: dept.id, slug: `${slugify(d.name)}-${crypto.randomBytes(2).toString("hex")}` } });
      await audit(u, "created", "playbooks", row.id, d.name);
      return row;
    },
  }),
  tool({
    name: "update_playbook", write: true,
    description: "Change a playbook: name, department, owner, status, autonomy (green alone / amber approve / red never), trigger, purpose, SKILL.md link, tests.",
    input: z.object({ playbook: ref, name: z.string().optional(), department: ref.optional(), owner: z.string().optional(),
      status: z.enum(["idea", "draft", "testing", "live", "paused"]).optional(), autonomy: z.enum(["green", "amber", "red"]).optional(),
      trigger: z.string().optional(), purpose: z.string().optional(), driveLink: z.string().optional(),
      testsPassed: z.number().int().optional(), testsTotal: z.number().int().optional() }),
    run: async (u, { playbook, department, ...d }) => {
      needEdit(u);
      const p = await findPlaybook(playbook);
      needScope(u, p.departmentId);
      const deptId = department ? (await findDepartment(department)).id : undefined;
      if (deptId) needScope(u, deptId);
      const row = await prisma.playbook.update({ where: { id: p.id }, data: { ...d, ...(deptId ? { departmentId: deptId } : {}) } });
      await audit(u, "updated", "playbooks", p.id, `${p.name}: ${Object.keys(d).join(", ")}`);
      return row;
    },
  }),
  tool({
    name: "delete_playbook", write: true,
    description: "Delete a playbook with its steps. Ask the person first, then pass confirmed: true. Admins only.",
    input: z.object({ playbook: ref, confirmed: z.boolean().optional() }),
    run: async (u, { playbook, confirmed }) => {
      needAdmin(u); confirmFirst(confirmed);
      const p = await findPlaybook(playbook);
      await prisma.playbook.delete({ where: { id: p.id } });
      await audit(u, "deleted", "playbooks", p.id, p.name);
      return { deleted: p.name };
    },
  }),

  // ----- rules and lessons (also written to Jarvis) -----
  tool({
    name: "create_rule", write: true,
    description: "Add a rule with its source. Rules of departments Jarvis runs (Chief of Staff) and company-wide rules are also appended to Jarvis's rules.md (apply_to_jarvis, default true). Rules of every other department, Sales included, stay in that department and never go to Jarvis.",
    input: z.object({ text: z.string().min(3), kind: z.enum(["policy", "fact", "style", "preference"]).default("policy"), source: z.string().describe("Who said it or which call/edit it came from"),
      playbook: ref.optional(), department: ref.optional(), owner: z.string().default(""), apply_to_jarvis: z.boolean().default(true) }),
    run: async (u, d) => {
      needEdit(u);
      const p = d.playbook ? await findPlaybook(d.playbook) : null;
      const deptId = p?.departmentId ?? (d.department ? (await findDepartment(d.department)).id : null);
      needScope(u, deptId);
      const date = today();
      const toJarvis = d.apply_to_jarvis && (await jarvisRunsDepartment(deptId)) && !(deptId === null && SALES_WORK.test(d.text));
      const extKey = toJarvis ? writeJarvisRule(d.text, d.kind, d.source, date) : null;
      const row = await prisma.rule.create({ data: { text: d.text.replace(/\s+/g, " ").trim(), kind: d.kind, status: "active", source: d.source, owner: d.owner || u.name, ruleDate: date, playbookId: p?.id ?? null, departmentId: deptId, extKey } });
      await audit(u, "created", "rules", row.id, d.text);
      return { ...row, appliedToJarvis: !!extKey, ...(d.apply_to_jarvis && !extKey ? { note: "Kept in the department only: Jarvis doesn't run this department's work." } : {}) };
    },
  }),
  tool({
    name: "update_rule", write: true,
    description: "Change a rule's text, kind, status (active, candidate, rejected, superseded), source or playbook. Rules already in Jarvis's rules.md are changed there by Ulvi.",
    input: z.object({ id: z.number().int(), text: z.string().optional(), kind: z.enum(["policy", "fact", "style", "preference"]).optional(),
      status: z.enum(["active", "candidate", "rejected", "superseded"]).optional(), source: z.string().optional(), playbook: ref.optional() }),
    run: async (u, { id, playbook, ...d }) => {
      needEdit(u);
      const r = (await prisma.rule.findUnique({ where: { id } })) ?? fail("Rule not found.");
      needScope(u, r.departmentId);
      const p = playbook ? await findPlaybook(playbook) : null;
      const row = await prisma.rule.update({ where: { id }, data: { ...d, ...(p ? { playbookId: p.id, departmentId: p.departmentId } : {}) } });
      await audit(u, "updated", "rules", id, Object.keys(d).join(", "));
      return row;
    },
  }),
  tool({
    name: "delete_rule", write: true,
    description: "Delete a rule from the dashboard. Ask first, then pass confirmed: true. Admins only.",
    input: z.object({ id: z.number().int(), confirmed: z.boolean().optional() }),
    run: async (u, { id, confirmed }) => {
      needAdmin(u); confirmFirst(confirmed);
      const r = await prisma.rule.delete({ where: { id } }).catch(() => fail("Rule not found."));
      await audit(u, "deleted", "rules", id, r.text);
      return { deleted: r.text };
    },
  }),
  tool({
    name: "create_lesson", write: true,
    description: "Log a lesson from an error: what went wrong, the reason, the fix. With apply_to_jarvis (default true) it is also written at the top of the playbook's notes.md on the server, which Jarvis reads before doing that job.",
    input: z.object({ playbook: ref, what: z.string().min(3), reason: z.string().default(""), fix: z.string().default(""), apply_to_jarvis: z.boolean().default(true) }),
    run: async (u, d) => {
      needEdit(u);
      const p = await findPlaybook(d.playbook);
      needScope(u, p.departmentId);
      const date = today();
      const extKey = d.apply_to_jarvis ? writeJarvisLesson(p.slug, d.what, d.reason, d.fix, date) : null;
      const row = await prisma.lesson.create({ data: { playbookId: p.id, departmentId: p.departmentId, lessonDate: date, what: d.what, reason: d.reason, fix: d.fix, owner: u.name, extKey } });
      await audit(u, "created", "lessons", row.id, d.what);
      return { ...row, appliedToJarvis: !!extKey, ...(d.apply_to_jarvis && !extKey ? { note: "Kept in the department only: Jarvis doesn't run this department's work." } : {}) };
    },
  }),

  // ----- knowledge -----
  tool({
    name: "upsert_knowledge", write: true,
    description: "Add a knowledge base (pass no id) or change one (pass id): name, department, kind, link, owner, description, patient data flag, last reviewed date.",
    input: z.object({ id: z.number().int().optional(), name: z.string().optional(), department: ref.optional(), kind: z.enum(["folder", "doc", "sheet", "file", "system", "other"]).optional(),
      link: z.string().optional(), owner: z.string().optional(), description: z.string().optional(), patientData: z.boolean().optional(), reviewedAt: z.string().optional() }),
    run: async (u, { id, department, ...d }) => {
      needEdit(u);
      const deptId = department ? (await findDepartment(department)).id : undefined;
      if (deptId !== undefined) needScope(u, deptId);
      if (id) {
        const k = (await prisma.knowledge.findUnique({ where: { id } })) ?? fail("Knowledge base not found.");
        needScope(u, k.departmentId);
        const row = await prisma.knowledge.update({ where: { id }, data: { ...d, ...(deptId ? { departmentId: deptId } : {}) } });
        await audit(u, "updated", "knowledge", id, k.name);
        return row;
      }
      if (!d.name) fail("Give the knowledge base a name.");
      const row = await prisma.knowledge.create({ data: { name: d.name!, kind: d.kind ?? "folder", link: d.link ?? "", owner: d.owner ?? "", description: d.description ?? "", patientData: d.patientData ?? false, reviewedAt: d.reviewedAt, departmentId: deptId ?? null } });
      await audit(u, "created", "knowledge", row.id, row.name);
      return row;
    },
  }),
  tool({
    name: "delete_knowledge", write: true,
    description: "Delete a knowledge base entry (only the dashboard entry; the Drive file stays). Ask first, then pass confirmed: true. Admins only.",
    input: z.object({ id: z.number().int(), confirmed: z.boolean().optional() }),
    run: async (u, { id, confirmed }) => {
      needAdmin(u); confirmFirst(confirmed);
      const k = await prisma.knowledge.delete({ where: { id } }).catch(() => fail("Not found."));
      await audit(u, "deleted", "knowledge", id, k.name);
      return { deleted: k.name };
    },
  }),

  // ----- workflow canvas -----
  tool({
    name: "add_step", write: true,
    description: "Add a step to a playbook's workflow canvas. kind: person, automation, ai_agent or empty (a gap nobody does yet). Optionally connect it after an existing step.",
    input: z.object({ playbook: ref, title: z.string().min(1), kind: z.enum(["person", "automation", "ai_agent", "empty"]).default("person"),
      role: z.string().default(""), tool: z.string().default(""), note: z.string().default(""), after_step_id: z.number().int().optional() }),
    run: async (u, d) => {
      needEdit(u);
      const p = await findPlaybook(d.playbook);
      needScope(u, p.departmentId);
      const after = d.after_step_id ? await prisma.step.findUnique({ where: { id: d.after_step_id } }) : null;
      const last = await prisma.step.findFirst({ where: { playbookId: p.id }, orderBy: { x: "desc" } });
      const pos = after ? { x: after.x + 210, y: after.y } : { x: last ? last.x + 210 : 24, y: last ? last.y : 64 };
      const s = await prisma.step.create({ data: { playbookId: p.id, title: d.title, kind: d.kind, role: d.role, tool: d.tool, note: d.note, ...pos } });
      if (after) await prisma.connection.create({ data: { fromId: after.id, toId: s.id } });
      await audit(u, "added step", "steps", s.id, `${p.name}: ${d.title}`);
      return s;
    },
  }),
  tool({
    name: "update_step", write: true,
    description: "Change a step you or someone added by hand. Steps marked jarvis or skill come from the server and can't be changed here.",
    input: z.object({ id: z.number().int(), title: z.string().optional(), kind: z.enum(["person", "automation", "ai_agent", "empty"]).optional(), role: z.string().optional(), tool: z.string().optional(), note: z.string().optional() }),
    run: async (u, { id, ...d }) => {
      needEdit(u);
      const s = (await prisma.step.findUnique({ where: { id }, include: { playbook: true } })) ?? fail("Step not found.");
      needScope(u, s.playbook.departmentId);
      if (s.source !== "manual") fail("This step comes from Jarvis or a SKILL.md; change it at the source.");
      return prisma.step.update({ where: { id }, data: d });
    },
  }),
  tool({
    name: "delete_step", write: true,
    description: "Delete a hand-made step and its arrows. Ask first, then pass confirmed: true.",
    input: z.object({ id: z.number().int(), confirmed: z.boolean().optional() }),
    run: async (u, { id, confirmed }) => {
      needEdit(u); confirmFirst(confirmed);
      const s = (await prisma.step.findUnique({ where: { id }, include: { playbook: true } })) ?? fail("Step not found.");
      needScope(u, s.playbook.departmentId);
      if (s.source !== "manual") fail("This step comes from Jarvis or a SKILL.md; change it at the source.");
      await prisma.step.delete({ where: { id } });
      await audit(u, "deleted step", "steps", id, s.title);
      return { deleted: s.title };
    },
  }),
  tool({
    name: "connect_steps", write: true,
    description: "Draw an arrow from one step to another (or remove it with remove: true).",
    input: z.object({ from_step_id: z.number().int(), to_step_id: z.number().int(), remove: z.boolean().default(false) }),
    run: async (u, { from_step_id, to_step_id, remove }) => {
      needEdit(u);
      for (const id of [from_step_id, to_step_id]) {
        const s = (await prisma.step.findUnique({ where: { id }, include: { playbook: true } })) ?? fail(`Step ${id} not found.`);
        needScope(u, s.playbook.departmentId);
      }
      if (remove) { await prisma.connection.deleteMany({ where: { fromId: from_step_id, toId: to_step_id } }); return { removed: true }; }
      await prisma.connection.upsert({ where: { fromId_toId: { fromId: from_step_id, toId: to_step_id } }, update: {}, create: { fromId: from_step_id, toId: to_step_id } });
      return { connected: true };
    },
  }),

  // ----- Jarvis (OpenClaw) -----
  tool({
    name: "jarvis_read_rules",
    description: "Read Jarvis's current rules: rules.md and the section titles of AGENTS.md on the server.",
    input: z.object({}),
    run: async () => {
      const rules = fs.existsSync(ws("rules.md")) ? fs.readFileSync(ws("rules.md"), "utf8").slice(-8000) : "";
      const agents = fs.existsSync(ws("AGENTS.md")) ? fs.readFileSync(ws("AGENTS.md"), "utf8").split("\n").filter((l) => /^#{1,3}\s/.test(l)) : [];
      return { rulesMd: rules, agentsSections: agents };
    },
  }),
  tool({
    name: "jarvis_propose_playbook_change", write: true,
    description: "Propose a change to a playbook's SKILL.md or file. It goes to Drive (Jarvis/Proposed) for the department owner to approve; the live playbook is not changed.",
    input: z.object({ playbook: z.string().min(1), file: z.string().default("SKILL.md"), content: z.string().min(1), reason: z.string().min(3) }),
    run: async (u, d) => {
      needEdit(u);
      const dir = ws(path.join("playbooks-proposed", slugify(d.playbook)));
      fs.mkdirSync(dir, { recursive: true });
      const f = path.join(dir, path.basename(d.file));
      fs.writeFileSync(f, `PROPOSED ${today()} by ${u.name}: ${d.reason}\n\n${d.content}`);
      gitCommit(`Proposed change: ${d.playbook}/${d.file}`);
      await audit(u, "proposed playbook change", "playbooks", null, `${d.playbook}/${d.file}: ${d.reason}`);
      return { proposed: path.relative(WS, f), note: "Synced to Drive Jarvis/Proposed within 30 minutes." };
    },
  }),
  // ----- files and Drive -----
  tool({
    name: "list_attachments",
    description: "Files the person attached in the chat recently (id, name, type, size, Drive link if uploaded).",
    input: z.object({}),
    run: async (u) => prisma.attachment.findMany({ where: isAdmin(u) ? {} : { userId: u.id }, orderBy: { createdAt: "desc" }, take: 30,
      select: { id: true, name: true, mime: true, size: true, driveLink: true, createdAt: true } }),
  }),

  tool({
    name: "add_file", write: true,
    description: "Store a file (base64 content, e.g. from your own Claude) so it can be sent with whatsapp_send, send_email, my_email_send or Slack tools. Returns its attachment_id. Max 25 MB.",
    input: z.object({ name: z.string().min(1), content_base64: z.string().min(4), mime: z.string().default("application/octet-stream") }),
    run: async (u, d) => {
      const { saveUpload } = await import("./files");
      const a = await saveUpload(u.id, d.name, d.mime, Buffer.from(d.content_base64, "base64")).catch((e: Error) => fail(e.message));
      return { attachment_id: a.id, name: a.name, size: a.size };
    },
  }),

  tool({
    name: "create_word_document", write: true,
    description: "Create a Word (.docx) document from text you write: # / ## / ### headings, - bullets, 1. numbered lists, | tables |, **bold**. Returns a download link and saves a copy in Drive (Jarvis/Documents). Use this whenever someone asks for a Word document or a .docx; write the full content yourself first.",
    input: z.object({ title: z.string().min(2), content: z.string().min(50).describe("The whole document in markdown"), subtitle: z.string().optional(), file_name: z.string().optional(), save_to_drive: z.boolean().default(true) }),
    run: async (u, d) => {
      const { buildWord } = await import("./word");
      const buf = await buildWord(d.title, d.content, d.subtitle);
      const name = `${(d.file_name || d.title).replace(/[\\/:*?"<>|]+/g, "-").slice(0, 80)}.docx`;
      const { saveUpload } = await import("./files");
      const a = await saveUpload(u.id, name, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", buf).catch((e: Error) => fail(e.message));
      let drive: string | null = null;
      if (d.save_to_drive) drive = (await uploadToDrive(a.path, name, "Documents").catch(() => ({ link: null }))).link;
      await audit(u, "created Word document", "files", a.id, name);
      return { file: name, download: `${appUrl()}/api/files/${a.id}`, drive: drive ?? "not saved to Drive", attachment_id: a.id };
    },
  }),
  tool({
    name: "upload_to_drive", write: true,
    description: "Put a file in Noah's Google Drive under the Jarvis folder (e.g. folder 'Uploads', 'Protocols', 'Patients/Andrea'). Give attachment_id for a file attached in the chat, or name plus text, or name plus content_base64 (from Claude). Returns the Drive link. Only folders inside Jarvis/ are possible.",
    input: z.object({ attachment_id: z.number().int().optional(), name: z.string().optional(), text: z.string().optional(), content_base64: z.string().optional(), folder: z.string().default("Uploads") }),
    run: async (u, d) => {
      needEdit(u);
      let local: string, name: string, attId: number | null = null;
      if (d.attachment_id) {
        const a = (await prisma.attachment.findUnique({ where: { id: d.attachment_id } })) ?? fail("Attachment not found.");
        if (a.userId !== u.id && !isAdmin(u)) fail("That file belongs to someone else.");
        local = a.path; name = d.name || a.name; attId = a.id;
      } else {
        if (!d.name || (!d.text && !d.content_base64)) fail("Give attachment_id, or a name with text or content_base64.");
        const tmp = path.join(process.env.UPLOAD_DIR || "./data/uploads", `mcp-${crypto.randomBytes(6).toString("hex")}`);
        fs.mkdirSync(path.dirname(tmp), { recursive: true });
        fs.writeFileSync(tmp, d.text !== undefined ? Buffer.from(d.text) : Buffer.from(d.content_base64!, "base64"));
        local = tmp; name = d.name!;
      }
      const r = await uploadToDrive(local, name.replace(/[\\/]/g, "_"), d.folder).catch((e: Error) => fail(`Drive upload failed: ${e.message}`));
      if (attId && r.link) await prisma.attachment.update({ where: { id: attId }, data: { driveLink: r.link } });
      await audit(u, "uploaded to Drive", "files", attId, `${r.folder}/${name}`);
      return r;
    },
  }),

  // ----- skills -----
  tool({
    name: "create_skill", write: true,
    description: "Write a new playbook skill (SKILL.md) in Noah's format and propose it: it goes to Drive Jarvis/Proposed for the department owner to approve, and a draft playbook appears in the dashboard. Use plain, specific language; steps are numbered actions.",
    input: z.object({
      name: z.string().min(2), department: ref, owner: z.string().default(""),
      purpose: z.string().min(5), when_to_use: z.string().min(5).describe("Trigger, in the words Noah uses"),
      inputs: z.array(z.string()).default([]), steps: z.array(z.string()).min(1),
      decisions: z.array(z.string()).default([]).describe("If X then Y rules"),
      definition_of_done: z.array(z.string()).default([]).describe("Pass/fail checks with evidence"),
      edge_cases: z.array(z.string()).default([]), approval: z.string().default("").describe("Which step needs a human, who approves, how fast"),
      autonomy: z.enum(["green", "amber", "red"]).default("amber"),
    }),
    run: async (u, d) => {
      needEdit(u);
      const dept = await findDepartment(d.department);
      needScope(u, dept.id);
      const list = (xs: string[], numbered = false) => (xs.length ? xs.map((x, i) => `${numbered ? `${i + 1}.` : "-"} ${x}`).join("\n") : "- (to fill in)");
      const md = `# ${d.name}

## Purpose
${d.purpose}

## When to use this
${d.when_to_use}

## Inputs
${list(d.inputs)}

## Steps
${list(d.steps, true)}

## Decisions
${list(d.decisions)}

## Definition of done
${list(d.definition_of_done)}

## Edge cases
${list(d.edge_cases)}

## Approval
${d.approval || "(to fill in)"}
`;
      const slug = slugify(d.name);
      const dir = ws(path.join("playbooks-proposed", slug));
      fs.mkdirSync(path.join(dir, "files"), { recursive: true });
      fs.writeFileSync(path.join(dir, "SKILL.md"), `PROPOSED ${today()} by ${u.name}: new skill\n\n${md}`);
      if (!fs.existsSync(path.join(dir, "notes.md"))) fs.writeFileSync(path.join(dir, "notes.md"), `# notes.md: ${slug}\n\nDated corrections, newest first.\n\n`);
      gitCommit(`Proposed skill: ${d.name}`);
      const existing = await prisma.playbook.findFirst({ where: { name: d.name } });
      const pb = existing ?? await prisma.playbook.create({ data: { name: d.name, slug: `${slug}-${crypto.randomBytes(2).toString("hex")}`, departmentId: dept.id, owner: d.owner || dept.owner, status: "draft", autonomy: d.autonomy, trigger: d.when_to_use.slice(0, 200), purpose: d.purpose.slice(0, 500) } });
      await audit(u, "proposed skill", "playbooks", pb.id, d.name);
      return { proposed: `playbooks-proposed/${slug}/SKILL.md`, driveFolder: "Jarvis/Proposed (synced within 30 minutes)", playbookId: pb.id, skill: md };
    },
  }),

  // ----- Jarvis memory -----
  tool({
    name: "memory_list",
    description: "List Jarvis's memory files (MEMORY.md and memory/*.md) with size and last change. Admins only.",
    input: z.object({}),
    run: async (u) => {
      needAdmin(u);
      const files = [ws("MEMORY.md"), ...((fs.existsSync(ws("memory")) ? fs.readdirSync(ws("memory")) : []).filter((f) => f.endsWith(".md")).map((f) => path.join(WS, "memory", f)))];
      return files.filter((f) => fs.existsSync(f)).map((f) => ({ file: path.relative(WS, f), bytes: fs.statSync(f).size, changed: fs.statSync(f).mtime.toISOString().slice(0, 16) }));
    },
  }),
  tool({
    name: "memory_read",
    description: "Read one of Jarvis's memory files in full (MEMORY.md or memory/<name>.md). Admins only.",
    input: z.object({ file: z.string().default("MEMORY.md") }),
    run: async (u, { file }) => {
      needAdmin(u);
      const f = memoryPath(file);
      return fs.existsSync(f) ? { file, content: fs.readFileSync(f, "utf8").slice(0, 60000) } : fail(`${file} doesn't exist yet.`);
    },
  }),
  tool({
    name: "memory_search",
    description: "Search all of Jarvis's memory files for words; returns matching lines with file and line number. Admins only.",
    input: z.object({ query: z.string().min(2) }),
    run: async (u, { query }) => {
      needAdmin(u);
      const words = query.toLowerCase().split(/\s+/).filter(Boolean);
      const hits: { file: string; line: number; text: string }[] = [];
      for (const f of (await TOOL_MAP.get("memory_list")!.run(u, {}) as { file: string }[])) {
        fs.readFileSync(path.join(WS, f.file), "utf8").split("\n").forEach((l, i) => {
          if (words.every((w) => l.toLowerCase().includes(w))) hits.push({ file: f.file, line: i + 1, text: l.slice(0, 300) });
        });
      }
      return hits.slice(0, 80);
    },
  }),
  tool({
    name: "memory_write", write: true,
    description: "Write to Jarvis's memory. mode 'append' adds a dated line (default); 'replace' rewrites the whole file (read it first and keep what should stay). Never store patient data, passwords or keys. Admins only.",
    input: z.object({ file: z.string().default("MEMORY.md"), mode: z.enum(["append", "replace"]).default("append"), text: z.string().min(2), source: z.string().default("") }),
    run: async (u, { file, mode, text, source }) => {
      needAdmin(u);
      if (/\b(sk-ant-|xox[bap]-|password\s*[:=]|api[_ ]?key\s*[:=])/i.test(text)) fail("That looks like a secret. Secrets never go into memory.");
      const f = memoryPath(file);
      fs.mkdirSync(path.dirname(f), { recursive: true });
      if (mode === "replace") fs.writeFileSync(f, text.endsWith("\n") ? text : `${text}\n`);
      else fs.appendFileSync(f, `${fs.existsSync(f) && !fs.readFileSync(f, "utf8").endsWith("\n") ? "\n" : ""}- ${today()}: ${text.replace(/\s+/g, " ").trim()}${source ? ` (source: ${source})` : ""} [added by ${u.name}]\n`);
      execFile("git", ["-C", WS, "add", "-A", "MEMORY.md", "memory"], () => execFile("git", ["-C", WS, "commit", "-q", "-m", `Memory ${mode} from dashboard`], () => undefined));
      await audit(u, `memory ${mode}`, "memory", null, `${file}: ${text.slice(0, 120)}`);
      return { file, mode, ok: true };
    },
  }),

  // ----- tool connections -----
  tool({
    name: "request_tool_connection", write: true,
    description: "Ask Ulvi to connect a new tool to Jarvis (e.g. GoHighLevel, Whop, a shared inbox). Records what, which access (read-only first) and why. Connections need credentials on the server, so the AI never sets them up itself.",
    input: z.object({ tool: z.string().min(2), access: z.string().default("read-only"), why: z.string().min(5), for_playbooks: z.array(z.string()).default([]) }),
    run: async (u, d) => {
      const line = `- ${today()} | ${d.tool} | ${d.access} | ${d.why}${d.for_playbooks.length ? ` | playbooks: ${d.for_playbooks.join(", ")}` : ""} | requested by ${u.name}\n`;
      try { fs.appendFileSync(ws("tool-requests.md"), line); } catch { /* not on the server: the activity log still records it */ }
      await audit(u, "requested tool connection", "tools", null, line.trim());
      return { requested: d.tool, note: "Logged for Ulvi (Activity and tool-requests.md on the server)." };
    },
  }),
  // ----- system status and control -----
  tool({
    name: "system_status",
    description: "Live status of Jarvis: gateway, WhatsApp and Telegram, every MCP connector, Google sign-in, scheduled jobs, last backup and disk. Uses the last check unless refresh is true (refresh tests every connector one by one and takes a minute or two). Admins only.",
    input: z.object({ refresh: z.boolean().default(false) }),
    run: async (u, { refresh }) => {
      needAdmin(u);
      const s = refresh ? await collectStatus(true) : (await cachedStatus()) ?? await collectStatus(false);
      return { checkedAt: s.checkedAt, problems: s.checks.filter((c) => c.level !== "ok"), all: s.checks };
    },
  }),
  tool({
    name: "run_job_now", write: true,
    description: "Start one of Jarvis's scheduled jobs right away (by name or id), e.g. 'WhatsApp digest' after a failure. Admins only. It doesn't change the job.",
    input: z.object({ job: z.string().min(2) }),
    run: async (u, { job }) => {
      needAdmin(u);
      const r = await runJobNow(job);
      if (!r.ok) fail(r.message);
      await audit(u, "ran job now", "automations", null, job);
      return r;
    },
  }),
  // ----- time sinks (Insights: where the time goes) -----
  tool({
    name: "list_time_sinks",
    description: "Recurring jobs with estimated team hours a week, department, owner, where they get stuck and the linked playbook (the 20/80 view in Insights).",
    input: z.object({}),
    run: async (u) => {
      const rows = await prisma.timeSink.findMany({ include: { department: { select: { name: true } } }, orderBy: { hoursPerWeek: "desc" } });
      return rows.filter((r) => inScope(u, r.departmentId));
    },
  }),
  tool({
    name: "upsert_time_sink", write: true,
    description: "Add a recurring job with its estimated hours a week (no id) or update one (with id): task, department, owner, hours_per_week, frequency, where it gets stuck, linked playbook, source of the number.",
    input: z.object({ id: z.number().int().optional(), task: z.string().optional(), department: ref.optional(), owner: z.string().optional(), hours_per_week: z.number().min(0).optional(),
      frequency: z.string().optional(), stuck: z.string().optional(), playbook: ref.optional(), source: z.string().optional() }),
    run: async (u, d) => {
      needEdit(u);
      const deptId = d.department ? (await findDepartment(d.department)).id : undefined;
      if (deptId !== undefined) needScope(u, deptId);
      const pbId = d.playbook ? (await findPlaybook(d.playbook)).id : undefined;
      const data = { ...(d.task ? { task: d.task } : {}), ...(d.owner !== undefined ? { owner: d.owner } : {}), ...(d.hours_per_week !== undefined ? { hoursPerWeek: d.hours_per_week } : {}),
        ...(d.frequency !== undefined ? { frequency: d.frequency } : {}), ...(d.stuck !== undefined ? { stuck: d.stuck } : {}), ...(d.source !== undefined ? { source: d.source } : {}),
        ...(deptId !== undefined ? { departmentId: deptId } : {}), ...(pbId !== undefined ? { playbookId: pbId } : {}) };
      if (d.id) {
        const r = (await prisma.timeSink.findUnique({ where: { id: d.id } })) ?? fail("Not found.");
        needScope(u, r.departmentId);
        const row = await prisma.timeSink.update({ where: { id: d.id }, data });
        await audit(u, "updated", "time sinks", d.id, row.task);
        return row;
      }
      if (!d.task || d.hours_per_week === undefined) fail("Give the job and its hours a week.");
      const row = await prisma.timeSink.create({ data: { task: d.task!, hoursPerWeek: d.hours_per_week!, owner: d.owner ?? "", frequency: d.frequency ?? "", stuck: d.stuck ?? "", source: d.source ?? `Added by ${u.name}`, departmentId: deptId ?? null, playbookId: pbId ?? null } });
      await audit(u, "created", "time sinks", row.id, row.task);
      return row;
    },
  }),
  tool({
    name: "delete_time_sink", write: true,
    description: "Remove a job from the time view. Ask first, then pass confirmed: true. Admins only.",
    input: z.object({ id: z.number().int(), confirmed: z.boolean().optional() }),
    run: async (u, { id, confirmed }) => {
      needAdmin(u); confirmFirst(confirmed);
      const r = await prisma.timeSink.delete({ where: { id } }).catch(() => fail("Not found."));
      await audit(u, "deleted", "time sinks", id, r.task);
      return { deleted: r.task };
    },
  }),
  // ----- outgoing messages (sent only after a person approves in the dashboard) -----
  tool({
    name: "queue_email", write: true,
    description: "Put an email from the person's own mailbox in their approval queue (Jarvis's emails are Noah's). Nothing is sent until that person (or Noah) approves it in Approvals or in the chat. Use thread_id to reply in a thread. Name the playbook so rejections become lessons.",
    input: z.object({ to: z.string().min(3), cc: z.string().default(""), subject: z.string().default(""), body: z.string().min(1), thread_id: z.string().default(""), playbook: z.string().default("email-replies"), reason: z.string().default("") }),
    run: async (u, d) => {
      needEdit(u);
      const row = await prisma.outbox.create({ data: { channel: "gmail", toAddr: d.to, cc: d.cc, subject: d.subject, body: d.body, threadId: d.thread_id, playbook: d.playbook, reason: d.reason, requestedBy: u.name, fromUserId: u.id } });
      await audit(u, "queued email", "outbox", row.id, `${d.to}: ${d.subject}`);
      return { queued: row.id, status: "waiting for approval", where: `${process.env.APP_URL ?? ""}/approvals` };
    },
  }),
  tool({
    name: "queue_slack_message", write: true,
    description: "Put a Slack message in the approval queue (channel name or id, optional thread_ts to reply in a thread). Nothing is posted until the owner or an admin approves it in the dashboard.",
    input: z.object({ channel: z.string().min(2), text: z.string().min(1), thread_ts: z.string().default(""), playbook: z.string().default(""), reason: z.string().default("") }),
    run: async (u, d) => {
      needEdit(u);
      const row = await prisma.outbox.create({ data: { channel: "slack", slackChannel: d.channel, slackThreadTs: d.thread_ts, body: d.text, playbook: d.playbook, reason: d.reason, requestedBy: u.name } });
      await audit(u, "queued Slack message", "outbox", row.id, `${d.channel}: ${d.text.slice(0, 60)}`);
      return { queued: row.id, status: "waiting for approval", where: `${process.env.APP_URL ?? ""}/approvals` };
    },
  }),
  tool({
    name: "list_outbox",
    description: "Messages waiting for approval, or recently sent or rejected (with the reason).",
    input: z.object({ status: z.enum(["pending", "sent", "rejected", "failed"]).optional() }),
    run: async (u, { status }) => {
      needEdit(u);
      return prisma.outbox.findMany({ where: status ? { status } : {}, orderBy: { createdAt: "desc" }, take: 30 });
    },
  }),

  // ----- event chains and patient journey -----
  tool({
    name: "link_playbooks", write: true,
    description: "Record that one playbook leads to another (an event chain, e.g. payment summary → upsell check), with a label for the event. remove: true deletes the link.",
    input: z.object({ from: ref, to: ref, label: z.string().default(""), remove: z.boolean().default(false) }),
    run: async (u, d) => {
      needEdit(u);
      const [a, b] = [await findPlaybook(d.from), await findPlaybook(d.to)];
      needScope(u, a.departmentId); needScope(u, b.departmentId);
      if (d.remove) { await prisma.playbookLink.deleteMany({ where: { fromId: a.id, toId: b.id } }); return { removed: `${a.name} → ${b.name}` }; }
      await prisma.playbookLink.upsert({ where: { fromId_toId: { fromId: a.id, toId: b.id } }, update: { label: d.label }, create: { fromId: a.id, toId: b.id, label: d.label } });
      await audit(u, "linked playbooks", "playbooks", a.id, `${a.name} → ${b.name}`);
      return { linked: `${a.name} → ${b.name}`, label: d.label };
    },
  }),
  tool({
    name: "list_journey",
    description: "Patient journey stages per program, in order, with the playbook that runs each stage.",
    input: z.object({ program: z.string().optional() }),
    run: async (_u, { program }) => prisma.journeyStage.findMany({ where: program ? { program } : {}, orderBy: [{ program: "asc" }, { position: "asc" }] }),
  }),
  tool({
    name: "upsert_journey_stage", write: true,
    description: "Add a stage to a program's patient journey (no id) or change one (with id): program, position (order), name, owner, description, duration, playbook that runs it.",
    input: z.object({ id: z.number().int().optional(), program: z.string().optional(), position: z.number().int().optional(), name: z.string().optional(), owner: z.string().optional(),
      description: z.string().optional(), duration: z.string().optional(), playbook: ref.optional() }),
    run: async (u, { id, playbook, ...d }) => {
      needEdit(u);
      const pbId = playbook ? (await findPlaybook(playbook)).id : undefined;
      const data = { ...Object.fromEntries(Object.entries(d).filter(([, v]) => v !== undefined)), ...(pbId !== undefined ? { playbookId: pbId } : {}) };
      if (id) return prisma.journeyStage.update({ where: { id }, data }).catch(() => fail("Stage not found."));
      if (!d.name) fail("Give the stage a name.");
      const program = d.program ?? "All programs";
      const position = d.position ?? (((await prisma.journeyStage.aggregate({ where: { program }, _max: { position: true } }))._max.position ?? 0) + 1);
      const row = await prisma.journeyStage.create({ data: { ...data, name: d.name!, program, position } });
      await audit(u, "added journey stage", "journey", row.id, `${program}: ${d.name}`);
      return row;
    },
  }),
  tool({
    name: "delete_journey_stage", write: true,
    description: "Remove a journey stage. Ask first, then pass confirmed: true.",
    input: z.object({ id: z.number().int(), confirmed: z.boolean().optional() }),
    run: async (u, { id, confirmed }) => {
      needEdit(u); confirmFirst(confirmed);
      const r = await prisma.journeyStage.delete({ where: { id } }).catch(() => fail("Not found."));
      return { deleted: r.name };
    },
  }),
  tool({
    name: "usage_report",
    description: "AI token use (and cost, when prices are set) over the last N days, by source and job. Admins only.",
    input: z.object({ days: z.number().int().min(1).max(90).default(30) }),
    run: async (u, { days }) => {
      needAdmin(u);
      const { costFor } = await import("./usage");
      const rows = await prisma.usageLog.findMany({ where: { at: { gte: new Date(Date.now() - days * 86400_000) } } });
      const by = new Map<string, { input: number; output: number; cost: number | null; calls: number }>();
      for (const r of rows) {
        const k = `${r.source}: ${r.job}`;
        const e = by.get(k) ?? { input: 0, output: 0, cost: 0, calls: 0 };
        const c = costFor(r.model, r.inputTokens, r.outputTokens, r.cacheTokens);
        by.set(k, { input: e.input + r.inputTokens, output: e.output + r.outputTokens, cost: c === null || e.cost === null ? null : e.cost + c, calls: e.calls + 1 });
      }
      return [...by.entries()].map(([job, v]) => ({ job, ...v })).sort((a, b) => b.input + b.output - (a.input + a.output));
    },
  }),
  // ----- hand a task to Jarvis (WhatsApp, Gmail, Calendar, Asana, Zoom, Fathom...) -----
  tool({
    name: "ask_jarvis", write: true,
    description: "Hand a task or question to Jarvis, Noah's AI chief of staff on the server, which has the tools this chat doesn't: Gmail, Google Calendar and Drive, Asana, Slack, Zoom, Fathom, web research, and WhatsApp (only for people Noah allowed). Noah only (Jarvis runs on Noah's own accounts). Everyone else uses their own connections.",
    input: z.object({ task: z.string().min(3).describe("What Jarvis should do or answer, with all the context it needs") }),
    run: async (u, { task }) => {
      if (u.role !== "owner") fail("Jarvis works with Noah's own accounts, so only Noah can use it. Use your own connections (Settings → My connections) instead.");
      const me = await prisma.user.findUnique({ where: { id: u.id } });
      const whatsapp = u.role === "owner" || !!me?.whatsapp;
      if (!whatsapp && /whats\s?app|periskope|wa\.me/i.test(task)) fail("WhatsApp is only for people Noah has allowed. Ask Noah to turn it on for you in Settings.");
      const bin = process.env.OPENCLAW_BIN || "openclaw";
      const guard = whatsapp ? "" : " This person has NO WhatsApp access: do not read, search, summarise or draft any WhatsApp/Periskope messages for them, even if asked.";
      const message = `Request from ${u.name} (${u.role}) in the Third Brain dashboard chat (not WhatsApp). Answer here; do not message anyone unless the request says so and Noah's usual approval applies.${guard}\n\n${task}`;
      const out = await new Promise<string>((resolve) =>
        execFile(bin, ["agent", "--agent", "main", "--session-key", `agent:main:dashboard-${u.id}`, "--message", message],
          { timeout: 300_000, maxBuffer: 8 * 1024 * 1024 },
          (err, stdout, stderr) => resolve(err ? `ERROR: ${(stderr || err.message).slice(-400)}` : stdout)));
      if (out.startsWith("ERROR:")) fail(`Jarvis didn't answer: ${out.slice(7)}`);
      await audit(u, "asked Jarvis", "jarvis", null, task.slice(0, 160));
      const answer = out.trim().slice(-12000);
      if (!whatsapp && /periskope|whatsapp/i.test(answer) && /\+\d{6,}|wa\.me/.test(answer)) return { jarvis: "Jarvis's answer touched WhatsApp, which this person can't use, so it was withheld." };
      return { jarvis: answer };
    },
  }),
  // ----- sending (shown first, sent after the person says yes) -----
  tool({
    name: "send_slack_message", write: true,
    description: "Post in Slack as the clinic's bot: a channel (#name), a thread (thread_ts) or a direct message to a person (email, @name, name or Slack user id; it is resolved to their real Slack user). To post as the person themself (e.g. as Noah), use my_slack_send. First show the person the exact text and where it goes; call with confirmed: true only after they say yes. Anyone who can edit posts straight away.",
    input: z.object({ to: z.string().min(2).describe("#channel, channel id, or a person's email for a DM"), text: z.string().default(""), attachment_ids: z.array(z.number().int()).default([]).describe("Files attached in the chat to send with it (ids from list_attachments or the chat)"),  thread_ts: z.string().default(""), playbook: z.string().default(""), confirmed: z.boolean().optional() }),
    run: async (u, d) => {
      needEdit(u);
      if (!d.confirmed) fail("Show the exact message and where it goes, ask the person to confirm, then call again with confirmed: true.");
      const { sendSlack } = await import("./send");
      const { loadAttachments } = await import("./files");
      const files = await loadAttachments(u, d.attachment_ids).catch((e: Error) => fail(e.message));
      const ts = await sendSlack({ channel: d.to, text: d.text, threadTs: d.thread_ts || undefined, files }).catch((e: Error) => fail(e.message));
      await audit(u, "sent Slack message", "slack", null, `${d.to}: ${d.text.slice(0, 80)}`);
      return { sent: true, to: d.to, ts };
    },
  }),
  tool({
    name: "list_slack_channels",
    description: "Slack channels the bot can see, and whether it is a member (it can only post where it is a member).",
    input: z.object({}),
    run: async (u) => {
      needEdit(u);
      const { listSlackChannels } = await import("./send");
      return listSlackChannels().catch((e: Error) => fail(e.message));
    },
  }),
  tool({
    name: "send_email", write: true,
    description: "Send an email from the person's OWN mailbox (their connected Google account; Noah can also send as someone else with as_user). Show the exact email first; call with confirmed: true only after they say yes. thread_id replies in a thread.",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), to: z.string().min(3), cc: z.string().default(""), subject: z.string().default(""), body: z.string().min(1), thread_id: z.string().default(""),
      attachment_ids: z.array(z.number().int()).default([]).describe("Files attached in the chat to send with it (ids from list_attachments or the chat)"), as_user: z.string().optional(), confirmed: z.boolean().optional() }),
    run: async (u, d) => {
      if (!d.confirmed) fail("Show the exact email (from, to, subject, text), ask the person to confirm, then call again with confirmed: true.");
      const sender = await whoFor(u, d.as_user);
      const { listConnections, myEmailSend } = await import("./connections");
      const connected = (await listConnections(sender)).some((c) => c.provider === "google");
      const { loadAttachments } = await import("./files");
      const files = await loadAttachments(u, d.attachment_ids).catch((e: Error) => fail(e.message));
      let r: unknown;
      if (connected) r = await myEmailSend(sender, { to: d.to, cc: d.cc, subject: d.subject, body: d.body, threadId: d.thread_id || undefined, files, from: d.account }).catch((e: Error) => fail(e.message));
      else if (files.length) fail("To send files, connect your Google account: Settings → My connections → Google.");
      else if (u.role === "owner" && sender === u.id) { const { sendGmail } = await import("./send"); r = { id: await sendGmail({ to: d.to, cc: d.cc, subject: d.subject, body: d.body, threadId: d.thread_id || undefined }).catch((e: Error) => fail(e.message)) }; }
      else fail("Connect your Google account first: Settings → My connections → Google.");
      await audit(u, "sent email", "gmail", null, `${d.to}: ${d.subject}`);
      return { sent: true, to: d.to, result: r };
    },
  }),
  // ----- people lookup -----
  tool({
    name: "find_people",
    description: "Find a team member's email (and title, phone) by name, from Slack's directory and the dashboard's people. Use this instead of asking for an email.",
    input: z.object({ name: z.string().min(2) }),
    run: async (u, { name }) => {
      needEdit(u);
      const words = name.toLowerCase().split(/\s+/).filter(Boolean);
      const local = (await prisma.user.findMany()).filter((x) => words.every((w) => `${x.name} ${x.email}`.toLowerCase().includes(w)))
        .map((x) => ({ name: x.name, email: x.email, source: "dashboard", role: x.role }));
      const { findSlackPeople } = await import("./send");
      const slack = await findSlackPeople(name).catch((e: Error) => [{ name: "", email: "", title: `Slack lookup failed: ${e.message}`, phone: "" }]);
      return { dashboard: local, slack };
    },
  }),

  // ----- the person's OWN connected accounts (Settings → My connections) -----
  tool({
    name: "my_connections",
    description: "Which of the person's own accounts are connected (their Google: Gmail and Calendar; their Slack). Use the my_* tools for 'my email', 'my calendar', 'post as me'.",
    input: z.object({}),
    run: async (u) => { const { listConnections } = await import("./connections"); return listConnections(u.id); },
  }),
  tool({
    name: "my_email_search",
    description: "Search the person's OWN Gmail (Gmail search syntax, e.g. 'from:kim newer_than:7d'). Returns sender, subject, date and snippet.",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), query: z.string().default("in:inbox newer_than:3d"), max: z.number().int().min(1).max(25).default(10) }),
    run: async (u, d) => { const { myEmailSearch } = await import("./connections"); return myEmailSearch(await whoFor(u, d.as_user), d.query, d.max, d.account).catch((e: Error) => fail(e.message)); },
  }),
  tool({
    name: "my_email_read",
    description: "Read one email from the person's OWN Gmail by id (from my_email_search).",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), id: z.string().min(5) }),
    run: async (u, d) => { const { myEmailRead } = await import("./connections"); return myEmailRead(await whoFor(u, d.as_user), d.id, d.account).catch((e: Error) => fail(e.message)); },
  }),
  tool({
    name: "my_email_send", write: true,
    description: "Send an email from the person's OWN Gmail. Show the exact email first; call with confirmed: true only after they say yes. thread_id replies in a thread.",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), to: z.string().min(3), cc: z.string().default(""), subject: z.string().default(""), body: z.string().min(1), thread_id: z.string().default(""), attachment_ids: z.array(z.number().int()).default([]).describe("Files attached in the chat to send with it (ids from list_attachments or the chat)"), confirmed: z.boolean().optional() }),
    run: async (u, d) => {
      if (!d.confirmed) fail("Show the exact email (to, subject, text), ask the person to confirm, then call again with confirmed: true.");
      const { myEmailSend } = await import("./connections");
      const { loadAttachments } = await import("./files");
      const files = await loadAttachments(u, d.attachment_ids).catch((e: Error) => fail(e.message));
      const r = await myEmailSend(await whoFor(u, d.as_user), { to: d.to, cc: d.cc, subject: d.subject, body: d.body, threadId: d.thread_id || undefined, files, from: d.account }).catch((e: Error) => fail(e.message));
      await audit(u, "sent own email", "gmail", null, `${d.to}: ${d.subject}`);
      return r;
    },
  }),
  tool({
    name: "my_calendar",
    description: "The person's OWN calendar events for the next N days.",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), days: z.number().int().min(1).max(31).default(7) }),
    run: async (u, d) => { const { myCalendar } = await import("./connections"); return myCalendar(await whoFor(u, d.as_user), d.days, d.account).catch((e: Error) => fail(e.message)); },
  }),
  tool({
    name: "my_slack_send", write: true,
    description: "Post in Slack AS the person (from their own connected Slack): a #channel they're in, a thread (thread_ts), or a DM by email. Show the exact text first; confirmed: true only after they say yes.",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), to: z.string().min(2), text: z.string().default(""), thread_ts: z.string().default(""), attachment_ids: z.array(z.number().int()).default([]).describe("Files attached in the chat to send with it (ids from list_attachments or the chat)"), confirmed: z.boolean().optional() }),
    run: async (u, d) => {
      if (!d.confirmed) fail("Show the exact message and where it goes, ask the person to confirm, then call again with confirmed: true.");
      const { mySlackSend } = await import("./connections");
      const { loadAttachments } = await import("./files");
      const files = await loadAttachments(u, d.attachment_ids).catch((e: Error) => fail(e.message));
      const r = await mySlackSend(await whoFor(u, d.as_user), d.to, d.text, d.thread_ts || undefined, files, d.account).catch((e: Error) => fail(e.message));
      await audit(u, "posted in Slack as self", "slack", null, `${d.to}: ${d.text.slice(0, 80)}`);
      return r;
    },
  }),
  tool({
    name: "my_slack_search",
    description: "Search the person's OWN Slack messages (Slack search syntax, e.g. 'from:@kim in:#sales after:2026-11-01').",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), query: z.string().min(2) }),
    run: async (u, d) => { const { mySlackSearch } = await import("./connections"); return mySlackSearch(await whoFor(u, d.as_user), d.query, d.account).catch((e: Error) => fail(e.message)); },
  }),


  tool({
    name: "my_drive_search",
    description: "Search the person's OWN Google Drive (and shared drives they can see) by words in the file name or content. Returns name, type, date and link.",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), query: z.string().min(2), max: z.number().int().min(1).max(50).default(15) }),
    run: async (u, d) => { const { myDriveSearch } = await import("./connections"); return myDriveSearch(await whoFor(u, d.as_user), d.query, d.max, d.account).catch((e: Error) => fail(e.message)); },
  }),
  tool({
    name: "my_drive_read",
    description: "Read a file from the person's OWN Drive by id (from my_drive_search): Google Docs, Sheets (as CSV), Slides and text files.",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), id: z.string().min(5) }),
    run: async (u, d) => { const { myDriveRead } = await import("./connections"); return myDriveRead(await whoFor(u, d.as_user), d.id, d.account).catch((e: Error) => fail(e.message)); },
  }),
  tool({
    name: "my_drive_save", write: true,
    description: "Save text as a new Google Doc in the person's OWN Drive (optionally in a folder id). Returns the link.",
    input: z.object({ account: z.string().optional().describe("Which of their connected accounts (email, e.g. clinic@…); default the first one"), as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), name: z.string().min(1), text: z.string().min(1), folder_id: z.string().optional() }),
    run: async (u, d) => {
      const { myDriveSave } = await import("./connections");
      const r = await myDriveSave(await whoFor(u, d.as_user), d.name, d.text, d.folder_id, d.account).catch((e: Error) => fail(e.message));
      await audit(u, "saved to own Drive", "drive", null, d.name);
      return r;
    },
  }),

  // ----- WhatsApp numbers (Periskope), per-number access set by Noah -----
  tool({
    name: "whatsapp_numbers",
    description: "The WhatsApp numbers this person may use, and whether they can read and/or send from each.",
    input: z.object({}),
    run: async (u) => { const { myNumbers } = await import("./whatsapp"); return myNumbers(u); },
  }),
  tool({
    name: "whatsapp_inbox",
    description: "Latest WhatsApp chats on one number (label like 'Clinic' or the phone number): name, unread count, last message. Archived chats are never shown.",
    input: z.object({ number: z.string().optional(), limit: z.number().int().min(1).max(50).default(20) }),
    run: async (u, d) => { const { inbox } = await import("./whatsapp"); return inbox(u, d.number, d.limit).catch((e: Error) => fail(e.message)); },
  }),
  tool({
    name: "whatsapp_find_chat",
    description: "Find a WhatsApp chat by name on one number.",
    input: z.object({ number: z.string().optional(), name: z.string().min(2) }),
    run: async (u, d) => { const { findChat } = await import("./whatsapp"); return findChat(u, d.number, d.name).catch((e: Error) => fail(e.message)); },
  }),
  tool({
    name: "whatsapp_messages",
    description: "Read the recent messages of one WhatsApp chat (chat_id from whatsapp_inbox or whatsapp_find_chat).",
    input: z.object({ number: z.string().optional(), chat_id: z.string().min(3), limit: z.number().int().min(1).max(100).default(30) }),
    run: async (u, d) => { const { messages } = await import("./whatsapp"); return messages(u, d.number, d.chat_id, d.limit).catch((e: Error) => fail(e.message)); },
  }),
  tool({
    name: "whatsapp_send", write: true,
    description: "Send a WhatsApp message, files (images, PDFs, videos, voice notes) or both from one number to a chat. Show the exact text, the files, the number it goes from and the chat first; call with confirmed: true only after the person says yes. Only people with send rights on that number.",
    input: z.object({ number: z.string().optional(), chat_id: z.string().optional(), phone: z.string().optional().describe("Or a phone number with country code, for a new chat"), text: z.string().default(""), attachment_ids: z.array(z.number().int()).default([]).describe("Files attached in the chat to send"), confirmed: z.boolean().optional() }),
    run: async (u, d) => {
      if (!d.confirmed) fail("Show the exact message, the number it's sent from and the chat, ask the person to confirm, then call again with confirmed: true.");
      if (!d.text && !d.attachment_ids.length) fail("Give a message, a file, or both.");
      const chatId = d.chat_id || (d.phone ? `${d.phone.replace(/[^\d]/g, "")}@c.us` : fail("Give a chat_id or a phone number."));
      const { loadAttachments } = await import("./files");
      const files = await loadAttachments(u, d.attachment_ids).catch((e: Error) => fail(e.message));
      const { sendMessage } = await import("./whatsapp");
      const r = await sendMessage(u, d.number, chatId, d.text, files).catch((e: Error) => fail(e.message));
      await audit(u, "sent WhatsApp", "whatsapp", null, `${r.from} → ${chatId}: ${d.text.slice(0, 80)}`);
      return r;
    },
  }),
  tool({
    name: "whatsapp_set_number", write: true,
    description: "Add or change a WhatsApp number and assign it to one or more people: who may read and who may send (by email; find emails with find_people). Admins and Noah; only Noah changes access to his own number.",
    input: z.object({ as_user: z.string().optional().describe("Owner only: someone else's email, to use their account"), phone: z.string().min(6), label: z.string().min(2), readers: z.array(z.string()).optional(), senders: z.array(z.string()).optional() }),
    run: async (u, d) => {
      needAdmin(u);
      const noah = (process.env.NOAH_WHATSAPP || "+34673555075").replace(/[^\d+]/g, "");
      if (u.role !== "owner" && d.phone.replace(/[^\d+]/g, "") === noah) fail("Only Noah decides who uses his own number.");
      const toIds = async (emails?: string[]) => emails ? Promise.all(emails.map(async (e) => (await findUserByEmail(e)).id)) : undefined;
      const [r, w] = [await toIds(d.readers), await toIds(d.senders)];
      const phone = d.phone.replace(/[^\d+]/g, "");
      const row = await prisma.whatsappNumber.upsert({ where: { phone }, update: { label: d.label, ...(r ? { readers: JSON.stringify(r) } : {}), ...(w ? { senders: JSON.stringify(w) } : {}) },
        create: { phone, label: d.label, readers: JSON.stringify(r ?? []), senders: JSON.stringify(w ?? []) } });
      await audit(u, "set WhatsApp number access", "whatsapp", row.id, `${d.label} ${phone}`);
      return { number: d.label, phone, readers: d.readers ?? "unchanged", senders: d.senders ?? "unchanged" };
    },
  }),

  // ----- skills: import as-is, approve automatically -----
  tool({
    name: "import_skill", write: true,
    description: "Add an existing skill (a SKILL.md someone already wrote) as a draft playbook in a department, keeping its content exactly as it is. Use one call per skill when someone uploads several. It waits for approval like any proposal.",
    input: z.object({ name: z.string().min(2), department: ref, content: z.string().min(20).describe("The SKILL.md text, unchanged"), owner: z.string().default("") }),
    run: async (u, d) => {
      needEdit(u);
      const dept = await findDepartment(d.department);
      needScope(u, dept.id);
      const slug = slugify(d.name);
      const dir = ws(path.join("playbooks-proposed", slug));
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, "SKILL.md"), d.content.endsWith("\n") ? d.content : `${d.content}\n`);
      if (!fs.existsSync(path.join(dir, "notes.md"))) fs.writeFileSync(path.join(dir, "notes.md"), `# notes.md: ${slug}\n\nDated corrections, newest first.\n\n`);
      gitCommit(`Imported skill: ${d.name}`);
      const purpose = (d.content.match(/##\s*purpose[^\n]*\n+([^\n#]+)/i)?.[1] ?? "").trim().slice(0, 500);
      const trigger = (d.content.match(/##\s*when[^\n]*\n+([^\n#]+)/i)?.[1] ?? "").trim().slice(0, 200);
      const existing = await prisma.playbook.findFirst({ where: { name: d.name, departmentId: dept.id } });
      const pb = existing ?? await prisma.playbook.create({ data: { name: d.name, slug: `${slug}-${crypto.randomBytes(2).toString("hex")}`, departmentId: dept.id,
        owner: d.owner || u.name, status: "draft", autonomy: "amber", trigger, purpose } });
      await audit(u, "imported skill", "playbooks", pb.id, d.name);
      return { playbookId: pb.id, name: d.name, status: "draft (waiting for approval)" };
    },
  }),
  tool({
    name: "approve_playbook", write: true,
    description: "Approve a proposed playbook so Jarvis uses it: its SKILL.md is published where Jarvis reads it and saved in Drive (Jarvis/Playbooks), the playbook moves to testing and its SKILL.md link fills in. Only the department's editors, admins or the owner. For clinical jobs, ask whether a doctor has approved it first. Confirm before approving.",
    input: z.object({ playbook: ref, confirmed: z.boolean().optional() }),
    run: async (u, d) => {
      needEdit(u);
      const pb = await findPlaybook(d.playbook);
      needScope(u, pb.departmentId);
      if (!d.confirmed) fail(`Confirm with the person that "${pb.name}" should go live for Jarvis (testing), then call again with confirmed: true.`);
      const candidates = [slugify(pb.name), pb.slug].map((x) => ws(path.join("playbooks-proposed", x, "SKILL.md")));
      const src = candidates.find((f) => fs.existsSync(f)) ?? fail(`No proposed SKILL.md found for "${pb.name}". Write or import the skill first.`);
      const body = fs.readFileSync(src, "utf8").replace(/^PROPOSED [^\n]*\n+/, "");
      const outDir = ws(path.join("playbooks-approved", pb.slug));
      fs.mkdirSync(outDir, { recursive: true });
      const out = path.join(outDir, "SKILL.md");
      fs.writeFileSync(out, body);
      const notes = path.join(path.dirname(src), "notes.md");
      if (fs.existsSync(notes) && !fs.existsSync(path.join(outDir, "notes.md"))) fs.copyFileSync(notes, path.join(outDir, "notes.md"));
      // Jarvis learns once where approved playbooks live.
      const agents = ws("AGENTS.md");
      if (fs.existsSync(agents) && !fs.readFileSync(agents, "utf8").includes("## Approved playbooks from the dashboard")) {
        fs.appendFileSync(agents, "\n\n## Approved playbooks from the dashboard\n\nPlaybooks approved in the Third Brain dashboard live in playbooks-approved/<name>/SKILL.md (with notes.md). Treat them exactly like the live playbooks from Drive: read the SKILL.md and its notes.md before doing that job.\n");
      }
      execFile("git", ["-C", WS, "add", "-A", "playbooks-approved", "AGENTS.md"], () => execFile("git", ["-C", WS, "commit", "-q", "-m", `Approved playbook: ${pb.name}`], () => undefined));
      const drive = await uploadToDrive(out, "SKILL.md", `Playbooks/${pb.name.replace(/[\\/]/g, "-")}`).catch(() => ({ link: null, folder: "" }));
      await prisma.playbook.update({ where: { id: pb.id }, data: { status: "testing", ...(drive.link ? { driveLink: drive.link } : {}) } });
      await audit(u, "approved playbook", "playbooks", pb.id, pb.name);
      return { approved: pb.name, status: "testing", jarvis: "reads it from the next job on", drive: drive.link ?? "Drive copy failed; Jarvis still has it" };
    },
  }),

  tool({
    name: "read_skill",
    description: "Read a playbook's SKILL.md: the live version Jarvis uses (approved) and the proposed draft if there is one. Use this before changing a skill.",
    input: z.object({ playbook: ref }),
    run: async (u, d) => {
      const pb = await findPlaybook(d.playbook);
      needScope(u, pb.departmentId);
      const read = (f: string) => (fs.existsSync(f) ? fs.readFileSync(f, "utf8") : null);
      const approved = read(ws(path.join("playbooks-approved", pb.slug, "SKILL.md")));
      const proposed = read(ws(path.join("playbooks-proposed", slugify(pb.name), "SKILL.md"))) ?? read(ws(path.join("playbooks-proposed", pb.slug, "SKILL.md")));
      const live = read(ws(path.join("playbooks-live", pb.name, "SKILL.md")));
      if (!approved && !proposed && !live) fail(`"${pb.name}" has no SKILL.md yet. Draft one with create_skill or import one with import_skill.`);
      return { playbook: pb.name, status: pb.status, approved: approved ?? live, proposed };
    },
  }),
  tool({
    name: "update_skill", write: true,
    description: "Change a playbook's SKILL.md: pass the full new text (read it first with read_skill and keep everything that should stay). It is saved as the proposal; it goes live for Jarvis when approved with approve_playbook. This is the only way to edit a skill: copies in anyone's Drive are not used by Jarvis.",
    input: z.object({ playbook: ref, content: z.string().min(20), reason: z.string().min(3) }),
    run: async (u, d) => {
      needEdit(u);
      const pb = await findPlaybook(d.playbook);
      needScope(u, pb.departmentId);
      const dir = ws(path.join("playbooks-proposed", slugify(pb.name)));
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, "SKILL.md"), d.content.endsWith("\n") ? d.content : `${d.content}\n`);
      gitCommit(`Skill change proposed: ${pb.name} (${d.reason.slice(0, 60)})`);
      await audit(u, "changed skill", "playbooks", pb.id, `${pb.name}: ${d.reason}`);
      return { saved: pb.name, note: pb.status === "draft" || pb.status === "idea" ? "Saved as the draft. Approve it when ready." : "Saved as a proposal. Jarvis keeps using the current version until you approve this one." };
    },
  }),

  // ----- Whop payment links (Noah, admins, and Finance editors) -----
  tool({
    name: "whop_create_link", write: true,
    description: "Create a Whop payment link: title, amount, currency, one-time or instalments (number and days between). Optional product_id, client and invoice_ref so the payment can be matched to the invoice. Confirm the details with the person first. Prices come from the 'prices products' sheet.",
    input: z.object({ title: z.string().min(2), amount: z.number().positive(), currency: z.enum(["usd", "eur", "gbp", "aed"]).default("usd"),
      kind: z.enum(["one_time", "instalments"]).default("one_time"), instalments: z.number().int().min(2).max(24).optional(), every_days: z.number().int().min(7).max(365).default(30),
      product_id: z.string().optional(), client: z.string().optional(), invoice_ref: z.string().optional(), confirmed: z.boolean().optional() }),
    run: async (u, d) => {
      await needFinance(u);
      if (!d.confirmed) fail("Show the link details (title, amount, currency, one-time or instalments, client, invoice) and ask the person to confirm, then call again with confirmed: true.");
      if (d.kind === "instalments" && !d.instalments) fail("How many instalments?");
      const { createLink } = await import("./whop");
      const l = await createLink({ ...d, createdBy: u.name }).catch((e: Error) => fail(e.message));
      await audit(u, "created payment link", "payments", l.id, `${l.title} ${l.amount} ${l.currency}`);
      return { id: l.id, url: l.url, title: l.title, amount: l.amount, currency: l.currency, kind: l.kind, instalments: l.instalments };
    },
  }),
  tool({
    name: "whop_list_links",
    description: "Payment links made from the brain, with status (open, paid, failed, deactivated). Filter by client or status.",
    input: z.object({ client: z.string().optional(), status: z.enum(["open", "paid", "failed", "deactivated"]).optional() }),
    run: async (u, d) => {
      await needFinance(u);
      return prisma.paymentLink.findMany({ where: { ...(d.status ? { status: d.status } : {}), ...(d.client ? { client: { contains: d.client } } : {}) }, orderBy: { createdAt: "desc" }, take: 50 });
    },
  }),
  tool({
    name: "whop_update_link", write: true,
    description: "Change a payment link's price or title (by id from whop_list_links), or deactivate it so it stops taking payments. Confirm first.",
    input: z.object({ id: z.number().int(), amount: z.number().positive().optional(), title: z.string().optional(), deactivate: z.boolean().optional(), confirmed: z.boolean().optional() }),
    run: async (u, d) => {
      await needFinance(u);
      if (!d.confirmed) fail("Show what will change and ask the person to confirm, then call again with confirmed: true.");
      const w = await import("./whop");
      const l = d.deactivate ? await w.deactivateLink(d.id).catch((e: Error) => fail(e.message)) : await w.updateLink(d.id, { amount: d.amount, title: d.title }).catch((e: Error) => fail(e.message));
      await audit(u, d.deactivate ? "deactivated payment link" : "updated payment link", "payments", l.id, `${l.title} ${l.amount} ${l.currency}`);
      return { id: l.id, title: l.title, amount: l.amount, status: l.status, url: l.url };
    },
  }),
  tool({
    name: "whop_payments",
    description: "Recent Whop payments (status, amount, payer, plan, metadata with the brain link and invoice), optionally since a date or for one email. Use to match a payment to an invoice.",
    input: z.object({ since: z.string().optional().describe("YYYY-MM-DD"), email: z.string().optional(), limit: z.number().int().min(1).max(100).default(25) }),
    run: async (u, d) => {
      await needFinance(u);
      const { listPayments } = await import("./whop");
      return listPayments(d).catch((e: Error) => fail(e.message));
    },
  }),
  // ----- automations: "when X happens, do Y" -----
  tool({
    name: "create_automation", write: true,
    description: "Create a rule that runs by itself every 5 minutes: WHEN (a bot reply in a Slack thread, e.g. payment summaries in sales-payment-made; a new Slack message with keywords; or a schedule like every day 09:00) THEN (send to Noah's WhatsApp, post to a Slack channel/person, or ask Jarvis to do something and deliver the answer). Existing messages are skipped on the first run. Optionally draw it on a playbook's workflow. Sending to Noah's WhatsApp only for the owner and people Noah allowed. Confirm the rule in one sentence before creating.",
    input: z.object({ name: z.string().min(3), trigger: TriggerSchema, action: ActionSchema, playbook: ref.optional().describe("Playbook to draw the steps on") }),
    run: async (u, d) => {
      needEdit(u);
      const me = await prisma.user.findUnique({ where: { id: u.id } });
      const wa = u.role === "owner" || !!me?.whatsapp;
      const toWa = d.action.type === "whatsapp_noah" || (d.action.type === "jarvis" && d.action.deliver === "whatsapp_noah");
      if (toWa && !wa) fail("Only Noah and people he allowed can send to his WhatsApp.");
      const pb = d.playbook ? await findPlaybook(d.playbook) : null;
      if (pb) needScope(u, pb.departmentId);
      if (d.action.type === "jarvis") {
        if (pb && !(await jarvisRunsDepartment(pb.departmentId))) fail("Jarvis doesn't do this department's work. Use a WhatsApp/Slack action instead, or have the department run it.");
        if (SALES_WORK.test(`${d.name} ${d.action.prompt}`)) fail("Sales work belongs to the Sales department, not Jarvis (Noah, 18 Nov).");
      }
      const rule = await prisma.automationRule.create({ data: { name: d.name, trigger: JSON.stringify(d.trigger), action: JSON.stringify(d.action), playbookId: pb?.id ?? null, createdBy: u.id } });
      const { when, then } = describeRule(d.trigger, d.action);
      if (pb) {
        const last = await prisma.step.findFirst({ where: { playbookId: pb.id }, orderBy: { y: "desc" } });
        const y = (last?.y ?? 0) + 140;
        const a = await prisma.step.create({ data: { playbookId: pb.id, title: `When ${when}`, kind: "automation", role: "Brain automation", tool: d.trigger.type === "schedule" ? "Schedule" : "Slack", x: 24, y } });
        const b = await prisma.step.create({ data: { playbookId: pb.id, title: then.charAt(0).toUpperCase() + then.slice(1), kind: d.action.type === "jarvis" ? "ai_agent" : "automation",
          role: d.action.type === "jarvis" ? "Jarvis" : "Brain automation", tool: toWa ? "WhatsApp" : "Slack", x: 234, y } });
        await prisma.connection.create({ data: { fromId: a.id, toId: b.id } });
      }
      await audit(u, "created automation", "automations", rule.id, `${d.name}: when ${when}, ${then}`);
      return { created: rule.id, rule: `When ${when}, ${then}.`, note: "Runs every 5 minutes. On the first run it only remembers existing messages, so only new ones are sent." };
    },
  }),
  tool({
    name: "list_brain_automations",
    description: "Automation rules created in the dashboard (when X, do Y), with status and last result.",
    input: z.object({}),
    run: async () => (await prisma.automationRule.findMany({ orderBy: { createdAt: "desc" } })).map((r) => {
      const { when, then } = describeRule(TriggerSchema.parse(JSON.parse(r.trigger)), ActionSchema.parse(JSON.parse(r.action)));
      return { id: r.id, name: r.name, enabled: r.enabled, rule: `When ${when}, ${then}.`, lastRunAt: r.lastRunAt, lastResult: r.lastResult };
    }),
  }),
  tool({
    name: "update_brain_automation", write: true,
    description: "Pause, resume, rename or change an automation rule (by id). delete: true removes it (ask first, then confirmed: true).",
    input: z.object({ id: z.number().int(), enabled: z.boolean().optional(), name: z.string().optional(), trigger: TriggerSchema.optional(), action: ActionSchema.optional(),
      delete: z.boolean().optional(), confirmed: z.boolean().optional() }),
    run: async (u, d) => {
      needEdit(u);
      const r = (await prisma.automationRule.findUnique({ where: { id: d.id } })) ?? fail("Automation not found.");
      if (r.createdBy !== u.id && !isAdmin(u)) fail("Only its creator or an admin can change it.");
      if (d.delete) { confirmFirst(d.confirmed); await prisma.automationRule.delete({ where: { id: d.id } }); await audit(u, "deleted automation", "automations", d.id, r.name); return { deleted: r.name }; }
      const row = await prisma.automationRule.update({ where: { id: d.id }, data: {
        ...(d.enabled !== undefined ? { enabled: d.enabled } : {}), ...(d.name ? { name: d.name } : {}),
        ...(d.trigger ? { trigger: JSON.stringify(d.trigger), state: "{}" } : {}), ...(d.action ? { action: JSON.stringify(d.action) } : {}) } });
      await audit(u, "updated automation", "automations", d.id, row.name);
      return { updated: row.name, enabled: row.enabled };
    },
  }),
];

/** Payment links and payments: Noah, admins, and editors of the Finance department. */
async function needFinance(u: CurrentUser) {
  if (isAdmin(u)) return;
  needEdit(u);
  const fin = await prisma.department.findMany({ where: { name: { contains: "inance" } } });
  if (!fin.some((d) => inScope(u, d.id))) fail("Payment links are for Noah, admins and the Finance team.");
}

/** Whose own accounts to use: the person's, or (owner only) someone else's by email. */
async function whoFor(u: CurrentUser, asUser?: string): Promise<number> {
  if (!asUser) return u.id;
  if (u.role !== "owner") fail("Only Noah can use other people's accounts.");
  return (await findUserByEmail(asUser)).id;
}

/** Access message: a one-time link where they set their own password (no password ever travels). */
function accessText(name: string, link: string) {
  const base = appUrl();
  return [
    `Hi ${name.split(" ")[0]}, your Third Brain access is ready.`,
    ``,
    `Set your own password and sign in here (one-time link, valid 72 hours): ${link}`,
    ``,
    `Use it from your own Claude too: Settings → Connectors → Add custom connector → ${base}/api/mcp → Connect → sign in and Allow.`,
    ``,
    `Quick guide (what to add and how): ${GUIDE_URL()}`,
  ].join("\n");
}

async function deliverAccess(userId: number, name: string, email: string, via: "none" | "slack" | "whatsapp", phone?: string, purpose: "invite" | "reset" = "invite") {
  const { createPasswordLink } = await import("./invites");
  const link = await createPasswordLink(userId, purpose);
  const text = accessText(name, link);
  if (via === "slack") {
    const { sendSlack } = await import("./send");
    await sendSlack({ channel: email, text }).catch((e: Error) => fail(`Saved, but the Slack DM failed: ${e.message}. Send the link below one to one instead.`));
    return { sent: `Slack DM to ${email} with a set-your-own-password link` };
  }
  if (via === "whatsapp") {
    let number = (phone ?? "").replace(/[^\d]/g, "");
    if (!number) {
      const { findSlackPeople } = await import("./send");
      number = ((await findSlackPeople(email).catch(() => []))[0]?.phone ?? "").replace(/[^\d]/g, "");
    }
    return { whatsappLink: `https://wa.me/${number}?text=${encodeURIComponent(text)}`, note: number ? "Tap to send it from WhatsApp, one to one." : "No phone number found: add it to the link." };
  }
  return { accessLink: link, note: "Send this link to the person one to one; it works once and expires in 72 hours. No password is shown or sent." };
}

function memoryPath(file: string) {
  const clean = file.replace(/^\/+/, "");
  if (clean === "MEMORY.md") return ws("MEMORY.md");
  if (!/^memory\/[\w.\- ]+\.md$/.test(clean)) fail("Memory files are MEMORY.md or memory/<name>.md.");
  return ws(clean);
}


export const TOOL_MAP = new Map(TOOLS.map((t) => [t.name, t]));

export function toolSchemas() {
  return TOOLS.map((t) => {
    const schema = z.toJSONSchema(t.input, { io: "input" }) as Record<string, unknown>;
    delete schema.$schema;
    return { name: t.name, description: t.description, input_schema: schema, write: !!t.write };
  });
}

export async function runTool(u: CurrentUser, name: string, args: unknown): Promise<{ ok: boolean; result?: unknown; error?: string; write?: boolean }> {
  const t = TOOL_MAP.get(name);
  if (!t) return { ok: false, error: `Unknown tool ${name}.` };
  const parsed = t.input.safeParse(args ?? {});
  if (!parsed.success) return { ok: false, error: `Invalid input: ${parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ")}` };
  try {
    return { ok: true, result: await t.run(u, parsed.data), write: t.write };
  } catch (e) {
    return { ok: false, error: e instanceof ToolError ? e.message : `Failed: ${(e as Error).message.split("\n").pop()}` };
  }
}
