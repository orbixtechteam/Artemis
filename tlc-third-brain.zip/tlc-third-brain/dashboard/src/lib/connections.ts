import "server-only";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { prisma } from "./db";
import { appUrl } from "./appurl";

// ---------- encryption (key in CONNECTIONS_KEY, else a key file created once next to the uploads) ----------
function key(): Buffer {
  if (process.env.CONNECTIONS_KEY) return crypto.createHash("sha256").update(process.env.CONNECTIONS_KEY).digest();
  const file = path.resolve(process.env.UPLOAD_DIR || "./data/uploads", "..", ".connections-key");
  if (!fs.existsSync(file)) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, crypto.randomBytes(32).toString("base64"), { mode: 0o600 }); }
  return crypto.createHash("sha256").update(fs.readFileSync(file, "utf8").trim()).digest();
}
export const enc = (s: string) => { if (!s) return ""; const iv = crypto.randomBytes(12); const c = crypto.createCipheriv("aes-256-gcm", key(), iv); const out = Buffer.concat([c.update(s, "utf8"), c.final()]); return [iv, c.getAuthTag(), out].map((b) => b.toString("base64")).join("."); };
export const dec = (s: string) => { if (!s) return ""; const [iv, tag, data] = s.split(".").map((x) => Buffer.from(x, "base64")); const d = crypto.createDecipheriv("aes-256-gcm", key(), iv); d.setAuthTag(tag); return Buffer.concat([d.update(data), d.final()]).toString("utf8"); };

// ---------- providers ----------
export const PROVIDERS = {
  google: {
    label: "Google (Gmail, Calendar and Drive)",
    configured: () => !!(process.env.GOOGLE_OAUTH_CLIENT_ID && process.env.GOOGLE_OAUTH_CLIENT_SECRET),
    authUrl: (state: string, hint: string) => `https://accounts.google.com/o/oauth2/v2/auth?${new URLSearchParams({
      client_id: process.env.GOOGLE_OAUTH_CLIENT_ID!, redirect_uri: `${appUrl()}/api/connect/google/callback`, response_type: "code",
      scope: "openid email https://www.googleapis.com/auth/gmail.modify https://www.googleapis.com/auth/gmail.send https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/drive.file",
      access_type: "offline", prompt: hint ? "consent" : "consent select_account", state, ...(hint ? { login_hint: hint } : {}),
    })}`,
  },
  slack: {
    label: "Slack",
    configured: () => !!(process.env.SLACK_CLIENT_ID && process.env.SLACK_CLIENT_SECRET),
    authUrl: (state: string) => `https://slack.com/oauth/v2/authorize?${new URLSearchParams({
      client_id: process.env.SLACK_CLIENT_ID!, redirect_uri: `${appUrl()}/api/connect/slack/callback`, state,
      user_scope: "chat:write,files:write,im:write,search:read,users:read,users:read.email,channels:read,groups:read",
    })}`,
  },
} as const;
export type Provider = keyof typeof PROVIDERS;

export async function finishConnect(provider: Provider, userId: number, code: string) {
  if (provider === "google") {
    const r = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({
      code, client_id: process.env.GOOGLE_OAUTH_CLIENT_ID!, client_secret: process.env.GOOGLE_OAUTH_CLIENT_SECRET!, redirect_uri: `${appUrl()}/api/connect/google/callback`, grant_type: "authorization_code" }) });
    const t = await r.json();
    if (!t.access_token) throw new Error(t.error_description || t.error || "Google sign-in failed");
    const who = await fetch("https://openidconnect.googleapis.com/v1/userinfo", { headers: { authorization: `Bearer ${t.access_token}` } }).then((x) => x.json()).catch(() => ({}));
    await save(userId, "google", who.email ?? "", t.access_token, t.refresh_token ?? "", t.expires_in);
  } else {
    const r = await fetch("https://slack.com/api/oauth.v2.access", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({
      code, client_id: process.env.SLACK_CLIENT_ID!, client_secret: process.env.SLACK_CLIENT_SECRET!, redirect_uri: `${appUrl()}/api/connect/slack/callback` }) });
    const t = await r.json();
    if (!t.ok || !t.authed_user?.access_token) throw new Error(t.error || "Slack sign-in failed");
    await save(userId, "slack", `${t.team?.name ?? "Slack"} (${t.authed_user.id})`, t.authed_user.access_token, t.authed_user.refresh_token ?? "", t.authed_user.expires_in, { slackUserId: t.authed_user.id });
  }
}

async function save(userId: number, provider: Provider, account: string, access: string, refresh: string, expiresIn?: number, extra: object = {}) {
  const data = { account, accessToken: enc(access), refreshToken: enc(refresh), extra: JSON.stringify(extra), expiresAt: expiresIn ? new Date(Date.now() + expiresIn * 1000) : null };
  await prisma.userConnection.upsert({ where: { userId_provider_account: { userId, provider, account } }, update: data, create: { userId, provider, ...data } });
}

export async function listConnections(userId: number) {
  return (await prisma.userConnection.findMany({ where: { userId }, orderBy: { createdAt: "asc" } })).map((c) => ({ id: c.id, provider: c.provider as Provider, account: c.account, since: c.createdAt }));
}

/** A valid access token for this person's own account, refreshing Google tokens when needed. */
/** A valid token for one of the person's connected accounts: the one named (email or part of it), else the first connected. */
export async function tokenFor(userId: number, provider: Provider, account?: string): Promise<{ token: string; account: string; extra: Record<string, string> }> {
  const all = await prisma.userConnection.findMany({ where: { userId, provider }, orderBy: { createdAt: "asc" } });
  if (!all.length) throw new Error(`You haven't connected your ${PROVIDERS[provider].label} yet: Settings → My connections → Connect.`);
  const want = (account ?? "").toLowerCase().trim();
  const c = want ? all.find((x) => x.account.toLowerCase() === want) ?? all.find((x) => x.account.toLowerCase().includes(want)) : all[0];
  if (!c) throw new Error(`No connected ${PROVIDERS[provider].label} account matches "${account}". Connected: ${all.map((x) => x.account).join(", ")}.`);
  let token = dec(c.accessToken);
  if (provider === "google" && c.expiresAt && c.expiresAt.getTime() < Date.now() + 60_000) {
    const r = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({
      client_id: process.env.GOOGLE_OAUTH_CLIENT_ID!, client_secret: process.env.GOOGLE_OAUTH_CLIENT_SECRET!, refresh_token: dec(c.refreshToken), grant_type: "refresh_token" }) });
    const t = await r.json();
    if (!t.access_token) throw new Error("Your Google connection expired. Connect it again in Settings → My connections.");
    token = t.access_token;
    await prisma.userConnection.update({ where: { id: c.id }, data: { accessToken: enc(token), expiresAt: new Date(Date.now() + (t.expires_in ?? 3600) * 1000) } });
  }
  return { token, account: c.account, extra: JSON.parse(c.extra || "{}") };
}

export async function disconnect(userId: number, provider: Provider, id?: number) {
  await prisma.userConnection.deleteMany({ where: { userId, provider, ...(id ? { id } : {}) } });
}

// ---------- the person's own Gmail, Calendar and Slack ----------
const G = "https://gmail.googleapis.com/gmail/v1/users/me";
async function gget(token: string, url: string) {
  const r = await fetch(url, { headers: { authorization: `Bearer ${token}` } });
  const d = await r.json();
  if (!r.ok) throw new Error(googleError(d, r.status));
  return d;
}

/** Plain-language Google errors; "insufficient scopes" means the account was connected before a feature (e.g. Drive) was added. */
export function googleError(d: { error?: { message?: string } }, status: number) {
  const m = d.error?.message ?? `Google ${status}`;
  return /insufficient authentication scopes|insufficientPermissions/i.test(m)
    ? "This Google account was connected before this feature was added, so it lacks permission. Reconnect it: Settings → My connections → Google → Disconnect, then Connect / Add another."
    : m;
}

export async function myEmailSearch(userId: number, query: string, max = 10, account?: string) {
  const { token } = await tokenFor(userId, "google", account);
  const list = await gget(token, `${G}/messages?q=${encodeURIComponent(query)}&maxResults=${Math.min(max, 25)}`);
  const out = [];
  for (const m of list.messages ?? []) {
    const d = await gget(token, `${G}/messages/${m.id}?format=metadata&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Subject&metadataHeaders=Date`);
    const h = (n: string) => d.payload?.headers?.find((x: { name: string }) => x.name.toLowerCase() === n.toLowerCase())?.value ?? "";
    out.push({ id: d.id, threadId: d.threadId, from: h("From"), to: h("To"), subject: h("Subject"), date: h("Date"), snippet: d.snippet });
  }
  return out;
}

export async function myEmailRead(userId: number, id: string, account?: string) {
  const { token } = await tokenFor(userId, "google", account);
  const d = await gget(token, `${G}/messages/${id}?format=full`);
  const walk = (p: { mimeType?: string; body?: { data?: string }; parts?: unknown[] }): string => {
    if (p.mimeType === "text/plain" && p.body?.data) return Buffer.from(p.body.data, "base64url").toString("utf8");
    for (const c of (p.parts ?? []) as typeof p[]) { const t = walk(c); if (t) return t; }
    return "";
  };
  const h = (n: string) => d.payload?.headers?.find((x: { name: string }) => x.name.toLowerCase() === n.toLowerCase())?.value ?? "";
  return { id: d.id, threadId: d.threadId, from: h("From"), to: h("To"), subject: h("Subject"), date: h("Date"), text: (walk(d.payload) || d.snippet || "").slice(0, 20000) };
}

export async function myEmailSend(userId: number, m: { to: string; cc?: string; subject: string; body: string; threadId?: string; files?: { name: string; mime: string; data: Buffer }[]; from?: string }) {
  const { token, account } = await tokenFor(userId, "google", m.from);
  const head = (v: string) => (/^[\x20-\x7e]*$/.test(v) ? v : `=?UTF-8?B?${Buffer.from(v).toString("base64")}?=`);
  const top = [`From: ${account}`, `To: ${m.to}`, ...(m.cc ? [`Cc: ${m.cc}`] : []), `Subject: ${head(m.subject)}`, "MIME-Version: 1.0"];
  let raw: string;
  if (!m.files?.length) {
    raw = [...top, "Content-Type: text/plain; charset=UTF-8", "", m.body].join("\r\n");
  } else {
    const b = `tb_${Date.now().toString(36)}`;
    const wrap = (s: string) => s.replace(/.{1,76}/g, "$&\r\n").trimEnd();
    const parts = [`--${b}`, "Content-Type: text/plain; charset=UTF-8", "Content-Transfer-Encoding: base64", "", wrap(Buffer.from(m.body).toString("base64"))];
    for (const f of m.files) parts.push(`--${b}`, `Content-Type: ${f.mime}; name="${head(f.name)}"`, "Content-Transfer-Encoding: base64", `Content-Disposition: attachment; filename="${head(f.name)}"`, "", wrap(f.data.toString("base64")));
    parts.push(`--${b}--`);
    raw = [...top, `Content-Type: multipart/mixed; boundary="${b}"`, "", ...parts].join("\r\n");
  }
  const r = await fetch(`${G}/messages/send`, { method: "POST", headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
    body: JSON.stringify({ raw: Buffer.from(raw).toString("base64url"), ...(m.threadId ? { threadId: m.threadId } : {}) }) });
  const d = await r.json();
  if (!r.ok) throw new Error(googleError(d, r.status));
  return { sentFrom: account, id: d.id };
}

export async function myCalendar(userId: number, days = 7, account?: string) {
  const { token } = await tokenFor(userId, "google", account);
  const now = new Date(), end = new Date(Date.now() + days * 86400_000);
  const d = await gget(token, `https://www.googleapis.com/calendar/v3/calendars/primary/events?singleEvents=true&orderBy=startTime&maxResults=100&timeMin=${now.toISOString()}&timeMax=${end.toISOString()}`);
  return (d.items ?? []).map((e: { summary?: string; start?: { dateTime?: string; date?: string }; end?: { dateTime?: string; date?: string }; attendees?: { email: string }[]; location?: string }) => ({
    title: e.summary ?? "(no title)", start: e.start?.dateTime ?? e.start?.date, end: e.end?.dateTime ?? e.end?.date, location: e.location ?? "", attendees: (e.attendees ?? []).map((a) => a.email).slice(0, 10) }));
}

async function slackUser(userId: number, method: string, body: Record<string, unknown>, account?: string) {
  const { token } = await tokenFor(userId, "slack", account);
  const r = await fetch(`https://slack.com/api/${method}`, { method: "POST", headers: { authorization: `Bearer ${token}`, "content-type": "application/json; charset=utf-8" }, body: JSON.stringify(body) });
  const d = await r.json();
  if (!d.ok) throw new Error(`Slack ${method}: ${d.error}`);
  return d;
}

export async function mySlackSend(userId: number, to: string, text: string, threadTs?: string, files: { name: string; mime: string; data: Buffer }[] = [], account?: string) {
  let channel = to.trim();
  if (!channel.startsWith("#") && (channel.includes("@") || /^[UW][A-Z0-9]{6,}$/.test(channel) || /^<@/.test(channel))) {
    const { resolveSlackUserId } = await import("./send");
    channel = (await slackUser(userId, "conversations.open", { users: await resolveSlackUserId(channel) }, account)).channel.id;
  } else if (channel.startsWith("#")) {
    const name = channel.slice(1).toLowerCase();
    const list = await slackUser(userId, "conversations.list", { types: "public_channel,private_channel", limit: 1000, exclude_archived: true }, account);
    const hit = (list.channels as { id: string; name: string }[]).find((c) => c.name.toLowerCase() === name);
    if (!hit) throw new Error(`You're not in a channel called #${name}.`);
    channel = hit.id;
  }
  if (files.length) {
    const { token } = await tokenFor(userId, "slack", account);
    return { posted: true, files: await slackUploadFiles(token, channel, files, text, threadTs) };
  }
  const d = await slackUser(userId, "chat.postMessage", { channel, text, ...(threadTs ? { thread_ts: threadTs } : {}) }, account);
  return { posted: true, ts: d.ts };
}

/** Uploads files to a Slack conversation with a token (person's own or the bot's), optional message as the comment. */
export async function slackUploadFiles(token: string, channel: string, files: { name: string; mime: string; data: Buffer }[], comment?: string, threadTs?: string) {
  const done: { id: string; title: string }[] = [];
  for (const f of files) {
    const u = await fetch(`https://slack.com/api/files.getUploadURLExternal?${new URLSearchParams({ filename: f.name, length: String(f.data.length) })}`, { headers: { authorization: `Bearer ${token}` } }).then((r) => r.json());
    if (!u.ok) throw new Error(`Slack upload: ${u.error}`);
    const put = await fetch(u.upload_url, { method: "POST", headers: { "content-type": f.mime || "application/octet-stream" }, body: new Uint8Array(f.data) });
    if (!put.ok) throw new Error(`Slack upload: HTTP ${put.status}`);
    done.push({ id: u.file_id, title: f.name });
  }
  const c = await fetch("https://slack.com/api/files.completeUploadExternal", { method: "POST", headers: { authorization: `Bearer ${token}`, "content-type": "application/json; charset=utf-8" },
    body: JSON.stringify({ files: done, channel_id: channel, ...(comment ? { initial_comment: comment } : {}), ...(threadTs ? { thread_ts: threadTs } : {}) }) }).then((r) => r.json());
  if (!c.ok) throw new Error(`Slack upload: ${c.error}`);
  return done.map((d) => d.title);
}

export async function mySlackSearch(userId: number, query: string, account?: string) {
  const { token } = await tokenFor(userId, "slack", account);
  const r = await fetch(`https://slack.com/api/search.messages?${new URLSearchParams({ query, count: "20" })}`, { headers: { authorization: `Bearer ${token}` } });
  const d = await r.json();
  if (!d.ok) throw new Error(`Slack search: ${d.error}`);
  return (d.messages?.matches ?? []).map((m: { username?: string; text?: string; channel?: { name?: string }; ts?: string; permalink?: string }) => ({ from: m.username, channel: m.channel?.name, text: (m.text ?? "").slice(0, 500), ts: m.ts, link: m.permalink }));
}

// ---------- the person's own Drive ----------
const D = "https://www.googleapis.com/drive/v3/files";
const DOPTS = "supportsAllDrives=true&includeItemsFromAllDrives=true";

export async function myDriveSearch(userId: number, query: string, max = 15, account?: string) {
  const { token } = await tokenFor(userId, "google", account);
  const q = `fullText contains '${query.replace(/'/g, "\\'")}' and trashed = false`;
  const d = await gget(token, `${D}?q=${encodeURIComponent(q)}&pageSize=${Math.min(max, 50)}&orderBy=modifiedTime desc&fields=files(id,name,mimeType,modifiedTime,webViewLink,owners(displayName))&corpora=allDrives&${DOPTS}`)
    .catch(async () => gget(token, `${D}?q=${encodeURIComponent(q)}&pageSize=${Math.min(max, 50)}&fields=files(id,name,mimeType,modifiedTime,webViewLink)&${DOPTS}`));
  return (d.files ?? []).map((f: { id: string; name: string; mimeType: string; modifiedTime: string; webViewLink: string }) => ({ id: f.id, name: f.name, type: f.mimeType.split(".").pop(), modified: f.modifiedTime?.slice(0, 10), link: f.webViewLink }));
}

export async function myDriveRead(userId: number, id: string, account?: string) {
  const { token } = await tokenFor(userId, "google", account);
  const meta = await gget(token, `${D}/${id}?fields=id,name,mimeType,webViewLink&${DOPTS}`);
  const exportAs: Record<string, string> = {
    "application/vnd.google-apps.document": "text/plain",
    "application/vnd.google-apps.spreadsheet": "text/csv",
    "application/vnd.google-apps.presentation": "text/plain",
  };
  const url = exportAs[meta.mimeType] ? `${D}/${id}/export?mimeType=${encodeURIComponent(exportAs[meta.mimeType])}` : `${D}/${id}?alt=media&${DOPTS}`;
  const r = await fetch(url, { headers: { authorization: `Bearer ${token}` } });
  if (!r.ok) throw new Error(`Drive ${r.status}`);
  const isText = exportAs[meta.mimeType] || /^text\/|json|csv|xml/.test(meta.mimeType);
  if (!isText) return { name: meta.name, link: meta.webViewLink, note: `This is a ${meta.mimeType} file; open it from the link (only text, Docs, Sheets and Slides can be read here).` };
  return { name: meta.name, link: meta.webViewLink, text: (await r.text()).slice(0, 30000) };
}

export async function myDriveSave(userId: number, name: string, text: string, folderId?: string, account?: string) {
  const { token } = await tokenFor(userId, "google", account);
  const meta = { name, mimeType: "application/vnd.google-apps.document", ...(folderId ? { parents: [folderId] } : {}) };
  const boundary = `tb${Date.now()}`;
  const body = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n${text}\r\n--${boundary}--`;
  const r = await fetch(`https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink&${DOPTS}`, {
    method: "POST", headers: { authorization: `Bearer ${token}`, "content-type": `multipart/related; boundary=${boundary}` }, body });
  const d = await r.json();
  if (!r.ok) throw new Error(googleError(d, r.status));
  return { saved: name, link: d.webViewLink };
}
