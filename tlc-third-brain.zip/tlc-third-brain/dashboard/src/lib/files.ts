import "server-only";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { execFile } from "node:child_process";
import { prisma } from "./db";

export const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || "./data/uploads");
export const MAX_BYTES = 25 * 1024 * 1024;
const RCLONE = process.env.RCLONE_BIN || "rclone";
const REMOTE = process.env.DRIVE_REMOTE || "gdrive:Jarvis";

export const IMAGE_TYPES = ["image/png", "image/jpeg", "image/gif", "image/webp"];
export const isText = (mime: string, name: string) =>
  mime.startsWith("text/") || /json|xml|yaml|csv/.test(mime) || /\.(md|txt|csv|json|ya?ml|html?|xml|tsv|log)$/i.test(name);

export async function saveUpload(userId: number, name: string, mime: string, data: Buffer) {
  if (data.length > MAX_BYTES) throw new Error("Files up to 25 MB.");
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  const safe = name.replace(/[^\w.\- ]+/g, "_").slice(-120) || "file";
  const file = path.join(UPLOAD_DIR, `${crypto.randomBytes(8).toString("hex")}-${safe}`);
  fs.writeFileSync(file, data, { mode: 0o600 });
  return prisma.attachment.create({ data: { userId, name: safe, mime: mime || "application/octet-stream", size: data.length, path: file } });
}

const run = (args: string[]) => new Promise<string>((resolve, reject) =>
  execFile(RCLONE, args, { timeout: 180_000, maxBuffer: 10 * 1024 * 1024 }, (err, out, errOut) => (err ? reject(new Error((errOut || err.message).slice(-300))) : resolve(out))));

/** Uploads into the Jarvis folder of Noah's Drive (the only place the server may write). Returns a Drive link. */
export async function uploadToDrive(localPath: string, name: string, folder = "Uploads") {
  const sub = folder.split("/").map((p) => p.replace(/[^\w.\- ]+/g, "_").trim()).filter(Boolean).join("/") || "Uploads";
  const dest = `${REMOTE}/${sub}`;
  await run(["copyto", localPath, `${dest}/${name}`]);
  const list = JSON.parse(await run(["lsjson", "--files-only", dest])) as { Name: string; ID?: string }[];
  const id = list.find((f) => f.Name === name)?.ID;
  return { folder: `Jarvis/${sub}`, link: id ? `https://drive.google.com/file/d/${id}/view` : null };
}

/** Chat attachments to send (WhatsApp, email, Slack): only the person's own files, or anyone's for Noah and admins. */
export async function loadAttachments(user: { id: number; role: string }, ids: number[] = []) {
  const out: { name: string; mime: string; data: Buffer }[] = [];
  let total = 0;
  for (const id of ids) {
    const a = await prisma.attachment.findUnique({ where: { id } });
    if (!a) throw new Error(`File #${id} not found.`);
    if (a.userId !== user.id && user.role !== "owner" && user.role !== "admin") throw new Error(`File "${a.name}" belongs to someone else.`);
    const data = fs.readFileSync(a.path);
    total += data.length;
    if (total > MAX_BYTES) throw new Error("Files together must be under 25 MB.");
    out.push({ name: a.name, mime: a.mime, data });
  }
  return out;
}
