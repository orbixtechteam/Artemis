import "server-only";
import fs from "node:fs";

const GOOGLE_CREDS = process.env.GOOGLE_CREDS_FILE || "/root/.google_workspace_mcp/credentials/noah@thelongevityclinic.net.json";
const CONFIG = process.env.OPENCLAW_CONFIG || "/root/.openclaw/openclaw.json";

async function googleToken() {
  const c = JSON.parse(fs.readFileSync(GOOGLE_CREDS, "utf8"));
  const r = await fetch(c.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ client_id: c.client_id, client_secret: c.client_secret, refresh_token: c.refresh_token, grant_type: "refresh_token" }),
  });
  const d = await r.json();
  if (!d.access_token) throw new Error(`Google sign-in failed: ${d.error_description ?? d.error ?? r.status}`);
  return d.access_token as string;
}

const b64url = (s: string) => Buffer.from(s).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const header = (v: string) => (/^[\x20-\x7e]*$/.test(v) ? v : `=?UTF-8?B?${Buffer.from(v).toString("base64")}?=`);

/** Sends from Noah's Gmail (the account Jarvis uses). Replies stay in the thread when threadId is set. */
export async function sendGmail(m: { to: string; cc?: string; subject: string; body: string; threadId?: string }) {
  const token = await googleToken();
  let inReplyTo = "";
  if (m.threadId) {
    const t = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/threads/${m.threadId}?format=metadata&metadataHeaders=Message-ID`, { headers: { authorization: `Bearer ${token}` } }).then((r) => r.json()).catch(() => null);
    const msgs = t?.messages ?? [];
    inReplyTo = msgs[msgs.length - 1]?.payload?.headers?.find((h: { name: string }) => h.name.toLowerCase() === "message-id")?.value ?? "";
  }
  const raw = [
    `To: ${m.to}`, m.cc ? `Cc: ${m.cc}` : "", `Subject: ${header(m.subject)}`,
    inReplyTo ? `In-Reply-To: ${inReplyTo}` : "", inReplyTo ? `References: ${inReplyTo}` : "",
    "MIME-Version: 1.0", "Content-Type: text/plain; charset=UTF-8", "Content-Transfer-Encoding: 8bit", "", m.body,
  ].filter((l, i, a) => l !== "" || i === a.length - 2).join("\r\n");
  const r = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", {
    method: "POST", headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
    body: JSON.stringify({ raw: b64url(raw), ...(m.threadId ? { threadId: m.threadId } : {}) }),
  });
  const d = await r.json();
  if (!r.ok) throw new Error(`Gmail: ${d.error?.message ?? r.status}`);
  return d.id as string;
}

function slackToken() {
  const token = process.env.SLACK_BOT_TOKEN || JSON.parse(fs.readFileSync(CONFIG, "utf8")).mcp?.servers?.slack?.env?.SLACK_MCP_XOXB_TOKEN;
  if (!token) throw new Error("Slack token not found (SLACK_BOT_TOKEN or the OpenClaw config).");
  return token as string;
}

const SLACK_ERRORS: Record<string, string> = {
  missing_scope: "the Slack bot is missing a permission (add users:read, users:read.email and im:write to the bot, then Reinstall to Workspace)",
  users_not_found: "no Slack account uses that email",
  ratelimited: "Slack is rate-limiting; try again in a minute",
  not_in_channel: "the bot isn't in that channel; invite it with /invite",
  channel_not_found: "channel not found, or the bot can't see it",
  invalid_auth: "the Slack token is invalid",
};

/** Slack Web API call with retry on rate limits and readable errors. */
async function slackApi(method: string, body: Record<string, unknown>, attempt = 0): Promise<Record<string, any>> { // eslint-disable-line @typescript-eslint/no-explicit-any
  // Form encoding works for every Web API method (read methods don't all accept JSON bodies).
  const form = new URLSearchParams(Object.entries(body).filter(([, v]) => v !== undefined && v !== "").map(([k, v]) => [k, typeof v === "object" ? JSON.stringify(v) : String(v)]));
  const r = await fetch(`https://slack.com/api/${method}`, {
    method: "POST", headers: { authorization: `Bearer ${slackToken()}`, "content-type": "application/x-www-form-urlencoded" }, body: form,
  });
  if (r.status === 429 && attempt < 3) {
    const wait = Math.min(30, Number(r.headers.get("retry-after") ?? 3));
    await new Promise((res) => setTimeout(res, wait * 1000));
    return slackApi(method, body, attempt + 1);
  }
  const d = await r.json();
  if (!d.ok) {
    if (d.error === "ratelimited" && attempt < 3) { await new Promise((res) => setTimeout(res, 3000)); return slackApi(method, body, attempt + 1); }
    const why = SLACK_ERRORS[d.error] ?? d.error;
    throw new Error(`Slack ${method}: ${why}${d.needed ? ` (needs ${d.needed})` : ""}`);
  }
  return d;
}

// Team directory cached for 10 minutes, so lookups don't hit Slack's rate limits.
let dirCache: { at: number; members: Record<string, any>[] } | null = null; // eslint-disable-line @typescript-eslint/no-explicit-any
async function directory() {
  if (dirCache && Date.now() - dirCache.at < 600_000) return dirCache.members;
  const members: Record<string, any>[] = []; // eslint-disable-line @typescript-eslint/no-explicit-any
  let cursor = "";
  for (let i = 0; i < 10; i++) {
    const d = await slackApi("users.list", { limit: 500, ...(cursor ? { cursor } : {}) });
    members.push(...d.members);
    cursor = d.response_metadata?.next_cursor;
    if (!cursor) break;
  }
  dirCache = { at: Date.now(), members };
  return members;
}

/** A person's Slack user id from an email, a user id, "@name" or their name (display or real name, unique match). */
export async function resolveSlackUserId(who: string): Promise<string> {
  const t = who.trim().replace(/^<@([UW][A-Z0-9]+)(\|[^>]*)?>$/, "$1");
  if (/^[UW][A-Z0-9]{6,}$/.test(t)) return t;
  const members = (await directory().catch(() => [])).filter((m) => !m.deleted && !m.is_bot);
  if (t.includes("@") && !t.startsWith("@")) {
    const hit = members.find((m) => (m.profile?.email ?? "").toLowerCase() === t.toLowerCase());
    if (hit) return hit.id as string;
    const u = await slackApi("users.lookupByEmail", { email: t }).catch((e: Error) => { throw new Error(`Couldn't find ${t} in Slack: ${e.message.replace(/^Slack users\.lookupByEmail: /, "")}.`); });
    return u.user.id as string;
  }
  const q = t.replace(/^@/, "").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "");
  const names = (m: Record<string, any>) => [m.name, m.real_name, m.profile?.display_name, m.profile?.real_name].filter(Boolean).map((x: string) => x.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "")); // eslint-disable-line @typescript-eslint/no-explicit-any
  let hits = members.filter((m) => names(m).some((n) => n === q));
  if (!hits.length) hits = members.filter((m) => names(m).some((n) => n.split(/\s+/)[0] === q || n.startsWith(q)));
  if (hits.length === 1) return hits[0].id as string;
  if (hits.length > 1) throw new Error(`"${who}" matches several Slack people (${hits.slice(0, 4).map((m) => m.real_name || m.name).join(", ")}). Use their email.`);
  throw new Error(`No Slack person called "${who}". Use their email or Slack name.`);
}

/** A channel name (#sales), a channel id, or a person (email, @name, name or user id) for a direct message. */
export async function resolveSlackTarget(target: string): Promise<string> {
  const t = target.trim();
  if (/^[CGD][A-Z0-9]{6,}$/.test(t)) return t;
  if (!t.startsWith("#") && (t.includes("@") || /^[UW][A-Z0-9]{6,}$/.test(t) || /^<@/.test(t))) {
    return (await slackApi("conversations.open", { users: await resolveSlackUserId(t) })).channel.id;
  }
  if (t.includes("@") && !t.startsWith("#")) {
    const email = t.toLowerCase();
    let id = (await directory().catch(() => [])).find((m) => (m.profile?.email ?? "").toLowerCase() === email && !m.deleted)?.id as string | undefined;
    if (!id) {
      const u = await slackApi("users.lookupByEmail", { email }).catch((e: Error) => { throw new Error(`Couldn't find ${t} in Slack: ${e.message.replace(/^Slack users\.lookupByEmail: /, "")}.`); });
      id = u.user.id as string;
    }
    return (await slackApi("conversations.open", { users: id })).channel.id;
  }
  const name = t.replace(/^#/, "").toLowerCase();
  let cursor = "";
  for (let i = 0; i < 10; i++) {
    const d = await slackApi("conversations.list", { types: "public_channel,private_channel", limit: 1000, exclude_archived: true, ...(cursor ? { cursor } : {}) });
    const hit = (d.channels as { id: string; name: string }[]).find((c) => c.name.toLowerCase() === name);
    if (hit) return hit.id;
    cursor = d.response_metadata?.next_cursor;
    if (!cursor) break;
  }
  throw new Error(`No Slack channel called #${name} that the bot can see. Invite the bot to it first.`);
}

export async function listSlackChannels() {
  const d = await slackApi("conversations.list", { types: "public_channel,private_channel", limit: 1000, exclude_archived: true });
  return (d.channels as { id: string; name: string; is_member: boolean; is_private: boolean }[]).map((c) => ({ id: c.id, name: `#${c.name}`, botIsMember: c.is_member, private: c.is_private }));
}

export async function sendSlack(m: { channel: string; text: string; threadTs?: string; files?: { name: string; mime: string; data: Buffer }[] }) {
  const channel = await resolveSlackTarget(m.channel);
  if (m.files?.length) {
    const { slackUploadFiles } = await import("./connections");
    await slackUploadFiles(slackToken(), channel, m.files, m.text, m.threadTs);
    return "files";
  }
  const d = await slackApi("chat.postMessage", { channel, text: m.text, ...(m.threadTs ? { thread_ts: m.threadTs } : {}) });
  return d.ts as string;
}

/** Team members from Slack's directory, matched by name (for finding someone's email without asking). */
export async function findSlackPeople(query: string) {
  const words = query.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").split(/\s+/).filter(Boolean);
  const out: { name: string; email: string; title: string; phone: string }[] = [];
  {
    for (const m of (await directory()) as { deleted?: boolean; is_bot?: boolean; name?: string; real_name?: string; profile?: { email?: string; title?: string; phone?: string; real_name?: string; display_name?: string } }[]) {
      if (m.deleted || m.is_bot || !m.profile?.email) continue;
      const hay = [m.real_name, m.name, m.profile.real_name, m.profile.display_name, m.profile.email].join(" ").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "");
      if (words.every((w) => hay.includes(w))) out.push({ name: m.real_name || m.profile.real_name || m.name || "", email: m.profile.email, title: m.profile.title ?? "", phone: m.profile.phone ?? "" });
    }
  }
  return out;
}

/** Channel id by name (#name or name), for automations. */
export async function slackChannelId(name: string) {
  return resolveSlackTarget(name.startsWith("#") ? name : `#${name}`);
}
/** Top-level messages in a channel since a Slack timestamp. */
export async function slackHistory(channel: string, oldest: string) {
  const d = await slackApi("conversations.history", { channel, oldest, limit: 200 });
  return (d.messages ?? []) as { ts: string; text?: string; user?: string; bot_id?: string; reply_count?: number; latest_reply?: string }[];
}
export async function slackReplies(channel: string, ts: string) {
  const d = await slackApi("conversations.replies", { channel, ts, limit: 200 });
  return ((d.messages ?? []) as { ts: string; text?: string; user?: string; bot_id?: string }[]).slice(1);
}
export async function slackBotUserId() {
  return (await slackApi("auth.test", {})).user_id as string;
}
export async function slackPermalink(channel: string, ts: string) {
  return (await slackApi("chat.getPermalink", { channel, message_ts: ts }).catch(() => ({ permalink: "" }))).permalink as string;
}
