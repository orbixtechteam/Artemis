import { PrismaClient } from "@prisma/client";

const g = globalThis as unknown as { prisma?: PrismaClient };
export const prisma = g.prisma ?? new PrismaClient();
if (process.env.NODE_ENV !== "production") g.prisma = prisma;

export async function logActivity(userName: string, action: string, entity?: string, entityId?: number | null, detail?: string) {
  await prisma.activity.create({ data: { userName, action, entity, entityId: entityId ?? null, detail: detail?.slice(0, 500) } });
}

export const meta = {
  async get(key: string) {
    return (await prisma.meta.findUnique({ where: { key } }))?.value ?? null;
  },
  async set(key: string, value: string) {
    await prisma.meta.upsert({ where: { key }, update: { value }, create: { key, value } });
  },
};
