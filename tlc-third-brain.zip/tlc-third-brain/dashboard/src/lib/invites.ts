import "server-only";
import crypto from "node:crypto";
import { prisma } from "./db";
import { appUrl } from "./appurl";

const sha = (s: string) => crypto.createHash("sha256").update(s).digest("hex");
export const INVITE_HOURS = 72;

/** A one-time link where the person sets their own password. Older unused links for them stop working. */
export async function createPasswordLink(userId: number, purpose: "invite" | "reset" = "invite") {
  await prisma.passwordToken.updateMany({ where: { userId, usedAt: null }, data: { usedAt: new Date() } });
  const token = crypto.randomBytes(32).toString("base64url");
  await prisma.passwordToken.create({ data: { tokenHash: sha(token), userId, purpose, expiresAt: new Date(Date.now() + INVITE_HOURS * 3600_000) } });
  return `${appUrl()}/set-password?token=${token}`;
}

export async function checkPasswordLink(token: string) {
  const t = token ? await prisma.passwordToken.findUnique({ where: { tokenHash: sha(token) } }) : null;
  if (!t || t.usedAt || t.expiresAt < new Date()) return null;
  const user = await prisma.user.findUnique({ where: { id: t.userId } });
  return user?.active ? { user, purpose: t.purpose } : null;
}

export async function usePasswordLink(token: string) {
  await prisma.passwordToken.update({ where: { tokenHash: sha(token) }, data: { usedAt: new Date() } });
}

/** Tells the owner on Slack the first time someone signs in. */
export async function notifyFirstLogin(name: string, email: string) {
  try {
    const owner = await prisma.user.findFirst({ where: { role: "owner" } });
    if (!owner || owner.email === email) return;
    const { sendSlack } = await import("./send");
    await sendSlack({ channel: owner.email, text: `${name} (${email}) just signed in to the Third Brain for the first time.` });
  } catch { /* a missing Slack setup must never block a login */ }
}
