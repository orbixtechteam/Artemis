import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { execFile } from "node:child_process";
import { prisma, meta, logActivity } from "./db";
import { slugify } from "./utils";
import { syncCanvasFromJobs, syncSkillSteps, type CronJob } from "./canvas-sync";
import { syncJarvisUsage } from "./usage";

const WS = process.env.WORKSPACE || "/root/.openclaw/workspace";
const OC = process.env.OPENCLAW_BIN || "openclaw";
const hash = (s: string) => crypto.createHash("sha1").update(s).digest("hex").slice(0, 20);
const exists = (p: string) => fs.existsSync(p);

export type SyncReport = { errors: string[]; [k: string]: number | string[] };

export function parseCSV(text: string): string[][] {
  const rows: string[][] = []; let row: string[] = [], field = "", q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') q = false;
      else field += c;
    } else if (c === '"') q = true;
    else if (c === ",") { row.push(field); field = ""; }
    else if (c === "\n") { row.push(field); rows.push(row); row = []; field = ""; }
    else if (c !== "\r") field += c;
  }
  if (field || row.length) { row.push(field); rows.push(row); }
  return rows;
}

const JOB_TO_PLAYBOOK: [string, string][] = [
  ["calendar brief", "pre-call-brief"], ["pre-call", "pre-call-brief"], ["payment", "payment-summary"],
  ["whatsapp digest", "whatsapp-replies"], ["morning brief", "morning-brief"], ["week plan", "week-plan"],
  ["monday review", "monday-review"], ["patient summar", "patient-summary"],
];
async function playbookIdFor(job: string) {
  const hit = JOB_TO_PLAYBOOK.find(([k]) => job.toLowerCase().includes(k));
  return hit ? (await prisma.playbook.findUnique({ where: { slug: hit[1] } }))?.id ?? null : null;
}


function cronJobs(): Promise<{ jobs?: CronJob[]; error?: string }> {
  return new Promise((resolve) => {
    execFile(OC, ["cron", "list", "--json"], { timeout: 120_000, maxBuffer: 20 * 1024 * 1024 }, (err, stdout) => {
      if (err) return resolve({ error: err.message });
      try { resolve({ jobs: JSON.parse(stdout.slice(stdout.indexOf("{"))).jobs ?? [] }); }
      catch (e) { resolve({ error: `cannot read cron list: ${(e as Error).message}` }); }
    });
  });
}

async function syncAutomations(r: SyncReport) {
  const res = await cronJobs();
  if (res.error || !res.jobs) { r.errors.push(`automations: ${res.error}`); return; }
  for (const j of res.jobs) {
    const s = j.schedule ?? {}, st = j.state ?? {}, d = j.delivery ?? {};
    const name = j.displayName || j.name || j.id;
    const schedule = s.kind === "cron" ? `${s.expr}${s.tz ? ` (${s.tz})` : ""}` : s.kind === "every" ? `every ${Math.round((s.everyMs ?? 0) / 60000)} min` : s.kind === "at" ? `once at ${s.at}` : "";
    const failed = st.lastRunStatus && !st.lastRunStatus.startsWith("ok");
    const data = {
      name, schedule, kind: j.payload?.kind === "command" || j.command ? "command" : "schedule",
      enabled: j.enabled !== false, delivery: d.mode && d.mode !== "none" ? `${d.mode}${d.channel ? ` to ${d.channel}` : ""}` : "",
      lastRunAt: st.lastRunAtMs ? new Date(st.lastRunAtMs) : null, lastStatus: st.lastRunStatus ?? null,
      lastError: failed ? String(st.lastError || st.lastDiagnosticSummary || "").slice(0, 500) : null,
    };
    const existing = await prisma.automation.findUnique({ where: { extId: j.id } });
    if (existing) await prisma.automation.update({ where: { id: existing.id }, data: { ...data, playbookId: existing.playbookId ?? (await playbookIdFor(name)) } });
    else await prisma.automation.create({ data: { ...data, extId: j.id, playbookId: await playbookIdFor(name) } });
  }
  const ids = res.jobs.map((j) => j.id);
  await prisma.automation.updateMany({ where: { extId: { not: null, notIn: ids } }, data: { enabled: false } });
  for (const p of await prisma.playbook.findMany({ where: { automations: { some: {} } }, include: { automations: { orderBy: { lastRunAt: "desc" }, take: 1 } } })) {
    const a = p.automations[0];
    await prisma.playbook.update({ where: { id: p.id }, data: { lastRunAt: a?.lastRunAt ?? null, lastRunStatus: a?.lastStatus ?? null } });
  }
  r.automations = res.jobs.length;
  const c = await syncCanvasFromJobs(res.jobs);
  r.canvasSteps = c.steps;
}

async function syncRuns(r: SyncReport) {
  const f = path.join(WS, "logs/run-log.csv");
  if (!exists(f)) return;
  const rows = parseCSV(fs.readFileSync(f, "utf8")).slice(1).filter((x) => x.length >= 3);
  const data = rows.map(([at, job, status, dur, delivery]) => ({
    runAt: new Date(at.replace(" ", "T") + ":00Z"), job, status, durationS: Number(dur) || null, delivery: delivery || null, extKey: hash(at + job),
  })).filter((x) => !Number.isNaN(x.runAt.getTime()));
  const known = new Set((await prisma.run.findMany({ where: { extKey: { in: data.map((x) => x.extKey) } }, select: { extKey: true } })).map((x) => x.extKey));
  const fresh = data.filter((x) => !known.has(x.extKey));
  if (fresh.length) await prisma.run.createMany({ data: fresh });
  r.runs = fresh.length;
}

async function syncLessons(r: SyncReport) {
  const dir = path.join(WS, "playbooks");
  if (!exists(dir)) return;
  let n = 0;
  for (const slug of fs.readdirSync(dir)) {
    const f = path.join(dir, slug, "notes.md");
    if (!exists(f)) continue;
    const pb = await prisma.playbook.findUnique({ where: { slug } });
    for (const line of fs.readFileSync(f, "utf8").split("\n")) {
      const m = line.match(/^\s*(\d{4}-\d{2}-\d{2})\s*\|\s*([^|]+)\|\s*([^|]*)\|\s*(.*)$/);
      if (!m) continue;
      const extKey = hash(slug + line);
      if (await prisma.lesson.findUnique({ where: { extKey } })) continue;
      await prisma.lesson.create({ data: {
        extKey, lessonDate: m[1], what: m[2].trim(), reason: m[3].trim(), fix: m[4].trim(), owner: "Noah",
        playbookId: pb?.id ?? null, departmentId: pb?.departmentId ?? null,
      } });
      n++;
    }
  }
  r.lessons = n;
}

async function syncRules(r: SyncReport) {
  const f = path.join(WS, "rules.md");
  if (!exists(f)) return;
  let n = 0;
  for (const line of fs.readFileSync(f, "utf8").split("\n")) {
    const m = line.match(/^\s*-\s*\[(active|candidate|rejected|superseded)\]\s*\[(style|fact|preference|policy)\]\s*(.+?)\s+—\s+source:\s*(.+?)\s+—\s+(\d{4}-\d{2}-\d{2})/i);
    if (!m) continue;
    const extKey = hash(m[3] + m[5]);
    await prisma.rule.upsert({
      where: { extKey },
      update: { status: m[1].toLowerCase() },
      create: { extKey, text: m[3], kind: m[2].toLowerCase(), status: m[1].toLowerCase(), source: m[4], ruleDate: m[5], owner: "Noah" },
    });
    n++;
  }
  r.rules = n;
}

async function syncTests(r: SyncReport) {
  const dir = path.join(WS, "playbooks");
  if (!exists(dir)) return;
  let n = 0;
  for (const slug of fs.readdirSync(dir)) {
    const f = path.join(dir, slug, "tests", "cases.csv");
    if (!exists(f)) continue;
    const rows = parseCSV(fs.readFileSync(f, "utf8")).slice(1).filter((x) => x.length >= 5);
    const passed = rows.filter((x) => /^pass/i.test((x[4] ?? "").trim())).length;
    n += (await prisma.playbook.updateMany({ where: { slug }, data: { testsPassed: passed, testsTotal: rows.length } })).count;
  }
  r.tests = n;
}

async function syncLivePlaybooks(r: SyncReport) {
  const root = path.join(WS, "playbooks-live");
  if (!exists(root)) return;
  const cos = await prisma.department.findFirst({ where: { name: "Chief of Staff" } });
  let n = 0;
  const walk = async (d: string) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) await walk(p);
      else if (/^skill\.md$/i.test(e.name)) {
        const txt = fs.readFileSync(p, "utf8");
        const name = path.basename(path.dirname(p));
        const slug = slugify(name);
        if (await prisma.playbook.findUnique({ where: { slug } })) continue;
        await prisma.playbook.create({ data: {
          name, slug, owner: "Noah", status: "draft", autonomy: "amber", departmentId: cos?.id ?? null,
          purpose: (txt.match(/purpose[^\n]*\n+([^\n#]+)/i)?.[1] ?? "").trim(),
          trigger: (txt.match(/when to use[^\n]*\n+([^\n#]+)/i)?.[1] ?? "").trim(),
        } });
        n++;
      }
    }
  };
  await walk(root);
  r.livePlaybooks = n;
}

let running = false;
export async function runSync(by = "system"): Promise<SyncReport> {
  if (running) return { errors: ["A sync is already running."] };
  running = true;
  const report: SyncReport = { errors: [] };
  try {
    const syncSkills = async (rep: SyncReport) => { rep.skillSteps = await syncSkillSteps(WS); };
    const syncUsage = async (rep: SyncReport) => { rep.usageRows = await syncJarvisUsage(); };
    for (const step of [syncRuns, syncLessons, syncRules, syncTests, syncLivePlaybooks, syncAutomations, syncSkills, syncUsage]) {
      try { await step(report); } catch (e) { report.errors.push(`${step.name}: ${(e as Error).message}`); }
    }
  } finally { running = false; }
  await meta.set("last_sync", new Date().toISOString());
  await meta.set("last_sync_report", JSON.stringify(report));
  if (by !== "system") await logActivity(by, "ran sync", "sync", null, JSON.stringify(report));
  return report;
}
