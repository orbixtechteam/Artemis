import "server-only";
import fs from "node:fs";
import { execFile } from "node:child_process";
import { meta, prisma } from "./db";

const OC = process.env.OPENCLAW_BIN || "openclaw";
const CONFIG = process.env.OPENCLAW_CONFIG || "/root/.openclaw/openclaw.json";
const RCLONE = process.env.RCLONE_BIN || "rclone";
const REMOTE = process.env.DRIVE_REMOTE || "gdrive:Jarvis";

export type Level = "ok" | "warn" | "down" | "unknown";
export type Check = { key: string; group: "Jarvis" | "Channels" | "Connectors" | "Server"; name: string; level: Level; detail: string };
export type SystemStatus = { checkedAt: string; checks: Check[] };

const sh = (cmd: string, args: string[], timeout = 60_000) => new Promise<{ ok: boolean; out: string }>((resolve) =>
  execFile(cmd, args, { timeout, maxBuffer: 5 * 1024 * 1024 }, (err, stdout, stderr) => resolve({ ok: !err, out: `${stdout}\n${stderr}` })));

async function channels(): Promise<Check[]> {
  const r = await sh(OC, ["channels", "status"]);
  const out: Check[] = [{
    key: "gateway", group: "Jarvis", name: "Jarvis gateway",
    level: /Gateway reachable/i.test(r.out) ? "ok" : r.ok ? "warn" : "down",
    detail: /Gateway reachable/i.test(r.out) ? "Running and reachable" : r.out.trim().split("\n").slice(-2).join(" ").slice(0, 200) || "No answer from OpenClaw",
  }];
  const warnings = r.out.split("\n").filter((l) => /^- \w+ \w+: /.test(l) && /warn|lost|reconnect|error|fail/i.test(l));
  for (const l of r.out.split("\n")) {
    const m = l.match(/^- ([A-Z][\w]*) (\w+): (.+)$/);
    if (!m) continue;
    const [, name, account, rest] = m;
    const health = rest.match(/health:(\w+)/)?.[1];
    const connected = /\bconnected\b/.test(rest) && !/disconnected/.test(rest);
    const warn = warnings.find((w) => w.toLowerCase().startsWith(`- ${name.toLowerCase()} ${account}`));
    const level: Level = !connected || /logged.?out|not linked/i.test(rest) ? "down" : warn || (health && health !== "healthy") ? "warn" : "ok";
    out.push({ key: `channel:${name}:${account}`, group: "Channels", name: account === "default" ? name : `${name} (${account})`, level,
      detail: [connected ? "Connected" : "Not connected", health && `health ${health}`, rest.match(/in:([^,]+)/)?.[1] && `last message ${rest.match(/in:([^,]+)/)![1]}`, warn && warn.replace(/^- \w+ \w+: /, "").slice(0, 160)].filter(Boolean).join(" · ") });
  }
  return out;
}

async function connectors(probe: boolean, previous: Check[]): Promise<Check[]> {
  let names: string[] = [];
  try { names = Object.keys(JSON.parse(fs.readFileSync(CONFIG, "utf8")).mcp?.servers ?? {}); } catch { return [{ key: "mcp", group: "Connectors", name: "MCP connectors", level: "unknown", detail: "Can't read the OpenClaw config on this machine." }]; }
  if (!probe) {
    // Probing starts every connector as its own process; too heavy for a background check. Reuse the last probe.
    return names.map((n) => previous.find((c) => c.key === `mcp:${n}`) ?? { key: `mcp:${n}`, group: "Connectors" as const, name: n.charAt(0).toUpperCase() + n.slice(1), level: "unknown" as Level, detail: "Not tested yet. Press Check now." });
  }
  const results: Check[] = [];
  const queue = [...names];
  const worker = async () => {
    for (let n = queue.shift(); n; n = queue.shift()) {
      const r = await sh(OC, ["mcp", "doctor", n, "--probe"], 90_000);
      const line = r.out.split("\n").find((l) => l.trim().startsWith(`- ${n}:`)) ?? "";
      const verdict = line.split(":").slice(1).join(":").trim();
      const ok = /^ok\b/i.test(verdict);
      const warn = r.out.split("\n").filter((l) => /warning:/i.test(l) && !/literal sensitive value/i.test(l)).map((l) => l.replace(/.*warning:\s*/i, "")).join("; ");
      results.push({ key: `mcp:${n}`, group: "Connectors", name: n.charAt(0).toUpperCase() + n.slice(1), level: ok ? (warn ? "warn" : "ok") : "down",
        detail: ok ? (warn || "Connected and answering") : (verdict || r.out.trim().split("\n").slice(-1)[0] || "No answer").slice(0, 200) });
    }
  };
  await worker(); // one at a time, to keep memory low
  return results.sort((a, b) => a.name.localeCompare(b.name));
}

async function google(): Promise<Check> {
  if (!fs.existsSync("/usr/local/bin/check-google")) return { key: "google", group: "Connectors", name: "Google sign-in", level: "unknown", detail: "Health check script not on this machine." };
  const r = await sh("/usr/local/bin/check-google", [], 90_000);
  const ok = /NO_REPLY/.test(r.out);
  return { key: "google", group: "Connectors", name: "Google sign-in", level: ok ? "ok" : "down", detail: ok ? "Token valid (Gmail, Calendar, Drive)" : r.out.trim().slice(0, 200) };
}

async function backups(): Promise<Check> {
  const r = await sh(RCLONE, ["lsjson", "--files-only", `${REMOTE}/Backups`], 60_000);
  if (!r.ok) return { key: "backups", group: "Server", name: "Nightly backup", level: "unknown", detail: "Can't list Drive backups from this machine." };
  try {
    const files = JSON.parse(r.out.slice(r.out.indexOf("["), r.out.lastIndexOf("]") + 1)) as { Name: string; ModTime: string; Size: number }[];
    const last = files.sort((a, b) => b.ModTime.localeCompare(a.ModTime))[0];
    if (!last) return { key: "backups", group: "Server", name: "Nightly backup", level: "down", detail: "No backup in Drive yet." };
    const hours = (Date.now() - new Date(last.ModTime).getTime()) / 3_600_000;
    return { key: "backups", group: "Server", name: "Nightly backup", level: hours < 30 ? "ok" : "down",
      detail: `Last: ${last.Name} (${Math.round(last.Size / 1_048_576)} MB), ${Math.round(hours)} h ago · ${files.length} kept` };
  } catch { return { key: "backups", group: "Server", name: "Nightly backup", level: "unknown", detail: "Couldn't read the backup list." }; }
}

function disk(): Check {
  try {
    const s = fs.statfsSync("/");
    const used = 1 - s.bavail / s.blocks;
    const freeGb = (s.bavail * s.bsize) / 1e9;
    return { key: "disk", group: "Server", name: "Disk", level: used > 0.9 ? "down" : used > 0.8 ? "warn" : "ok", detail: `${Math.round(used * 100)}% used, ${freeGb.toFixed(1)} GB free` };
  } catch { return { key: "disk", group: "Server", name: "Disk", level: "unknown", detail: "Not available." }; }
}

async function jobs(): Promise<Check> {
  const all = await prisma.automation.findMany({ where: { enabled: true } }).catch(() => null);
  if (!all) return { key: "jobs", group: "Jarvis", name: "Scheduled jobs", level: "unknown", detail: "Couldn't read jobs from the database." };
  const failing = all.filter((a) => a.lastStatus && !/^ok/.test(a.lastStatus) && !["suppressed", "skipped"].includes(a.lastStatus));
  return { key: "jobs", group: "Jarvis", name: "Scheduled jobs", level: !all.length ? "unknown" : failing.length ? "warn" : "ok",
    detail: all.length ? (failing.length ? `${failing.length} of ${all.length} failing: ${failing.map((f) => f.name).join(", ")}` : `All ${all.length} jobs ran fine last time`) : "No jobs synced yet." };
}

let running: Promise<SystemStatus> | null = null;
/** probe = also start every MCP connector to test it (heavy; only on "Check now"). */
export function collectStatus(probe = false): Promise<SystemStatus> {
  running ??= (async () => {
    const previous = (await cachedStatus().catch(() => null))?.checks ?? [];
    const ch = await channels();
    const mc = await connectors(probe, previous);
    const g = probe ? await google() : previous.find((c) => c.key === "google") ?? { key: "google", group: "Connectors" as const, name: "Google sign-in", level: "unknown" as Level, detail: "Not tested yet. Press Check now." };
    const [b, j] = await Promise.all([backups(), jobs()]);
    const status: SystemStatus = { checkedAt: new Date().toISOString(), checks: [...ch, j, ...mc, g, b, disk()] };
    await meta.set("system_status", JSON.stringify(status)).catch((e) => console.error("couldn't save status:", e));
    return status;
  })().finally(() => { running = null; });
  return running;
}

export async function cachedStatus(): Promise<SystemStatus | null> {
  const raw = await meta.get("system_status");
  return raw ? (JSON.parse(raw) as SystemStatus) : null;
}

export async function runJobNow(ref: string): Promise<{ ok: boolean; message: string }> {
  const job = (await prisma.automation.findMany()).find((a) => a.extId === ref || a.name.toLowerCase() === ref.toLowerCase() || String(a.id) === ref);
  if (!job?.extId) return { ok: false, message: `No Jarvis job called "${ref}".` };
  const r = await sh(OC, ["cron", "run", job.extId], 60_000);
  return { ok: r.ok && /"ok":\s*true|enqueued/i.test(r.out), message: r.ok ? `Started "${job.name}". Its result appears after the next sync.` : `Couldn't start it: ${r.out.trim().slice(-200)}` };
}
