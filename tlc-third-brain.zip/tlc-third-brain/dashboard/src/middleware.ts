import { NextResponse, type NextRequest } from "next/server";

/** Public address of the app (e.g. https://brain.example.com behind a Cloudflare Tunnel). */
function base(req: NextRequest) {
  if (process.env.APP_URL) return process.env.APP_URL;
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  const proto = req.headers.get("x-forwarded-proto") ?? "http";
  return host ? `${proto}://${host}` : req.url;
}

export function middleware(req: NextRequest) {
  const signedIn = req.cookies.has("ab_session");
  const onLogin = req.nextUrl.pathname === "/login" || req.nextUrl.pathname === "/set-password";
  if (!signedIn && !onLogin) {
    const to = new URL("/login", base(req));
    const back = req.nextUrl.pathname + req.nextUrl.search;
    if (back !== "/") to.searchParams.set("next", back);
    return NextResponse.redirect(to);
  }
  return NextResponse.next();
}

export const config = { matcher: ["/((?!_next|favicon.ico|api/mcp|api/oauth|api/automations|api/webhooks|\.well-known).*)"] };
