module.exports = {
  apps: [{
    name: "ai-brain",
    cwd: "/root/ai-brain-visual",
    script: "node_modules/next/dist/bin/next",
    args: "start -p 3900 -H 127.0.0.1",
    env: { NODE_ENV: "production" },
    autorestart: true,
    max_memory_restart: "700M",
    time: true,
  }],
};
