# AI Brain Visual

The Longevity Clinic's Third Brain dashboard: departments, playbooks, rules, lessons from errors, knowledge bases, automations and runs, filled automatically from Jarvis (OpenClaw).

**Package manager:** pnpm (`corepack enable` once if `pnpm` is missing).

**Stack:** Next.js 15 (App Router) · TypeScript · Prisma · shadcn/ui (Radix + Tailwind v4) · server actions · zod.

## Deploy in one command

From the Mac, in the project folder:

```bash
bash scripts/deploy.sh
```

It sends the code (never `.env`, the database or uploads), installs, updates the database, seeds what's missing, builds and reloads PM2. First time on a fresh server, also: `cp .env.example .env` on the server and fill it in.

One-time server scripts (run on the server):
- `bash scripts/server-tune.sh`: swap, Ollama idle unload, SearXNG memory cap, nightly gateway restart, `jarvis-memory`.
- `bash scripts/jarvis-approvals.sh` (optional, not recommended while Noah approves in chat): makes Approvals mandatory for all of Jarvis's email and Slack.
- `bash scripts/jarvis-permissions.sh`: per-person tool limits for Jarvis.

## Run locally (Mac)

```bash
cd ~/Projects/longliving/ai-brain-visual
pnpm install
cp .env.example .env        # set NOAH_PASSWORD
pnpm prisma db push          # creates the database from prisma/schema.prisma
pnpm db:seed             # owner (Noah), departments, playbooks, knowledge bases
pnpm dev                 # http://localhost:3900
```

Sign in with `NOAH_EMAIL` / `NOAH_PASSWORD`.

## Database

Prisma with SQLite by default: one file (`prisma/brain.db`), no database server to run. To use PostgreSQL, set `provider = "postgresql"` in `prisma/schema.prisma` and a `postgres://` `DATABASE_URL`, then `pnpm prisma db push`. No other code changes.

## Deploy on the Jarvis server

```bash
# from the Mac
rsync -av --exclude node_modules --exclude .next --exclude .env --exclude 'prisma/*.db' \
  ~/Projects/longliving/ai-brain-visual/ root@187.126.15.145:/root/ai-brain-visual/
# on the server
cd /root/ai-brain-visual
corepack enable
pnpm install
cp .env.example .env && nano .env      # NOAH_PASSWORD, WORKSPACE, OPENCLAW_BIN
pnpm prisma db push && pnpm db:seed
pnpm build
cp ai-brain-visual.service /etc/systemd/system/
systemctl daemon-reload && pm2 start ecosystem.config.cjs && pm2 save
```

It listens on `127.0.0.1:3900` only (no open port). Open it from the Mac with
`ssh -L 3900:localhost:3900 root@187.126.15.145` and http://localhost:3900. For the team, use Tailscale or Cloudflare Access instead of opening a port.

## How data changes

Only two places change data: **the AI chat** and **Settings**. Every other page is read-only.

- **Ask the brain** (`/chat`, from the sidebar or the button bottom right): a full chat page like Claude, with each person's own history (rename, delete), chats per department (pick the department for a new chat; the AI works in that context; filter the history by department), Markdown answers and the AI's steps shown live. Voice: the **mic** dictates into the message box; **Voice** mode is hands-free (talk, it sends when you stop, reads the answer aloud, then listens again). Speech-to-text runs on the server with the local Whisper (`TRANSCRIBE_BIN`), so audio never leaves it; replies are read with the browser's voices. From it you can add or change departments, people and who sees which department, playbooks, rules, lessons, knowledge bases and workflow steps, in plain words. New rules go to Jarvis's `rules.md` and new lessons to the playbook's `notes.md` on the server, so Jarvis follows them. It can also propose a playbook change (to Drive `Jarvis/Proposed` for the owner to approve). It works with your permissions and always asks before deleting. Needs `ANTHROPIC_API_KEY` in `.env`.
- **Files in the chat**: paste (Cmd+V), drop or attach images and files up to 25 MB. The AI reads images, PDFs and text files (txt, md, csv, json…). Say "put this in Drive" and it uploads the file to Noah's Drive under `Jarvis/<folder>` and gives you the link (the server's Drive access only reaches folders it created).
- **Skills**: "write a skill for …" creates a SKILL.md in Noah's format in `Jarvis/Proposed` and a draft playbook; the owner approves it.
- **Jarvis memory** (admins): read, search and write `MEMORY.md` and `memory/*.md`. Secrets and patient data are refused.
- **People** (Settings or chat): passwords are always generated, never typed; you get the login details (link, email, password) to copy once. Admins set anyone's role (admin, editor, viewer) and departments, reset passwords. Only the owner account is protected.
- **New tool connections**: the AI logs a request for Ulvi; it never sets credentials up itself.
- **Settings**: your password, departments (add, edit, delete, who sees each one), people (add, role, departments, reset password, switch off), API tokens for Claude, the link with Jarvis.

## Approvals (optional)

By default Jarvis keeps sending email and Slack after Noah's "send" in WhatsApp or Telegram. Approvals is an optional queue for messages that should wait for a click in the dashboard (for example drafts prepared for or by the team): `queue_email` / `queue_slack_message` put them in **Approvals** (admins, with a count in the sidebar). The owner or an admin can edit it, then **Approve and send** (the dashboard sends from Noah's Gmail or the Slack bot) or **Reject** with a reason, which becomes a lesson in that playbook's notes.md. Sent-as-drafted vs sent-after-edits feeds the autonomy map ("approved without edits in a row"). No AI tool can approve.

## Costs, event chains, patient journey

- **Costs** (admins): tokens per day and per job for the dashboard chat and every Jarvis job (read from OpenClaw's session logs at each sync). Set `MODEL_PRICES` for dollars and `MONTHLY_BUDGET_USD` for the budget bar.
- **Event chains:** which playbook starts which, as a graph (`link_playbooks`).
- **Patient journey:** stages per program, the playbook that runs each one, and the stages still done by hand (`upsert_journey_stage`).

## Server tuning

`sudo bash scripts/server-tune.sh` once on the server: adds swap if missing, lets Ollama unload its model when idle, caps SearXNG's memory, restarts the gateway nightly, and installs `jarvis-memory` (memory report).

## Insights

Library → **Insights**:
- **Autonomy map:** live and testing playbooks in green / amber / red, with clean runs since the last correction (target 20), failures and tests. An amber job that passes all three is marked "ready for green" (Road to autonomy 1–2).
- **Where the time goes:** recurring jobs by estimated hours a week (Phase 0 analysis), a Pareto chart with the 80% line, totals per department, and which jobs have no playbook yet. `pnpm db:seed` loads the Phase 0 numbers; the chat updates them (`upsert_time_sink`).
- **Quality:** corrections per week (last 8 weeks) and tests against the 9-of-10 bar.

## System status

Library → **System status** (admins): Jarvis gateway, WhatsApp and Telegram (connected, health, recent reconnects), every MCP connector (`openclaw mcp doctor --probe`), Google sign-in, scheduled jobs, last backup in Drive and disk. Checked every `STATUS_MINUTES` (15) and with **Check now**; each job has **Run now**. The overview shows a one-line summary. The chat and Claude answer "how is the system?" (`system_status`) and can start a job (`run_job_now`). The dashboard never runs shell commands or changes Jarvis's configuration.

## Claude connector (MCP)

The same 40 tools as the chat are available to Claude, including Drive upload (Claude passes the file content), skills and memory.

1. Claude: Settings → Connectors → Add custom connector → `https://ai-brain.thelongevityclinic.net/api/mcp` → **Connect**. You sign in to the dashboard and press **Allow** (OAuth 2.1 with PKCE and dynamic client registration; access tokens last 1 hour, refresh tokens 30 days). Settings lists connected apps with **Disconnect**.
2. For clients without OAuth: Settings → Create token, and use the link `…/api/mcp/<token>` instead.
3. With Cloudflare Access in front of the site, add a **Bypass** policy for `/api/mcp*`, `/api/oauth/*` and `/.well-known/*` so Claude's servers can reach them. `/oauth/authorize` stays behind Access: it opens in your own browser.

Claude acts with the token owner's permissions. Revoke a token in Settings and access stops at once.

## Workflows canvas (Puzzle-style)

`/workflows/<department>` shows each department as a canvas: every playbook is a section, every step is a box, arrows are connections.

- Read-only: click a step to see its details. To add, change or connect steps, ask the brain ("add a step to Fulfilment after Signed prescription: Paid? check, empty").
- **View as** dims every step that a chosen person or agent doesn't do.
- Right panel: sections, steps and connections, who does the work (person, automation, AI agent, empty), jump to a section, tools used.
- Steps come from real sources on every sync with Jarvis, marked JARVIS or SKILL on the box:
  - every scheduled Jarvis job (`openclaw cron list`): its schedule, the script it runs or the instruction Jarvis gets, the tools it uses, who receives the result, and the last run status;
  - every live SKILL.md with a "Steps" list (Drive Playbooks folder).
  These are read-only on the canvas (change them at the source) but you can move them; your positions are kept. Steps you add by hand are never touched by a sync.
- `pnpm db:seed` only creates Noah's owner account, departments, playbooks and knowledge bases. No example steps.

## Features

- **Overview:** departments as columns with their playbooks, coloured by autonomy (green alone, amber approve, red never), status, tests and last run; what needs attention, runs over 14 days, latest lessons, test progress to go-live (9 of 10).
- **Departments, playbooks, rules, lessons, knowledge bases, automations:** list, filter, add, edit, delete (shadcn dialogs, zod validation).
- **Runs** and **activity log** (who changed what).
- **Search** across everything.
- **Settings:** change password; **People** (owner and admins): add people, roles (admin, editor, viewer), departments each person sees, reset password, switch off access.

## Roles

| Role | Can |
| --- | --- |
| Owner (Noah) | Everything; the only one who adds admins |
| Admin | Everything, including people, deletes and sync |
| Editor | Edit only their departments |
| Viewer | Read only their departments |

## Sync with Jarvis

Every `SYNC_MINUTES` (default 10, started in `src/instrumentation-node.ts`) and on **Sync with Jarvis**:

| What | From |
| --- | --- |
| Automations and last status | `openclaw cron list --json` |
| Runs | `WORKSPACE/logs/run-log.csv` |
| Lessons | `WORKSPACE/playbooks/<playbook>/notes.md` |
| Rules | `WORKSPACE/rules.md` |
| Test results | `WORKSPACE/playbooks/<playbook>/tests/cases.csv` |
| New playbooks | `WORKSPACE/playbooks-live/**/SKILL.md` |

Manual: `pnpm sync`. On a Mac without Jarvis the sync reports that the files are missing; everything else works.

## Project layout

```
prisma/schema.prisma      models
prisma/seed.ts            owner + starting data
src/app/login             sign-in
src/app/(app)/...         pages (server components)
src/components/ui         shadcn/ui components
src/components            app components (brain map, tables, dialogs, people)
src/lib/actions.ts        server actions (auth, CRUD, people, sync)
src/lib/auth.ts           sessions, roles, department scope
src/lib/sync.ts           Jarvis importers
src/middleware.ts         redirects to /login without a session
```
