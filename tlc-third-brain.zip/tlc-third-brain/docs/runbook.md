# Runbook

## Server
- `ssh root@187.126.15.145` (Node: `export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH`)
- Dashboard: `/root/ai-brain-visual`, PM2 app `ai-brain` (`pm2 status`, `pm2 logs ai-brain`), port 3900
- Jarvis: `openclaw gateway status`, `openclaw cron list`, `openclaw mcp doctor --probe`
- Tunnel: cloudflared → https://ai-brain.thelongevityclinic.net

## Deploy the dashboard
```bash
cd dashboard && bash scripts/deploy.sh
```
rsync (without `.env`, database, data) → `pnpm install` → `prisma db push` → seed → build → `pm2 reload ai-brain` → local check 200.

## One-time scripts (in `dashboard/scripts/`)
| Script | Does |
| --- | --- |
| `server-tune.sh` | swap, Ollama keep-alive, SearXNG memory cap, nightly gateway restart |
| `jarvis-permissions.sh` | per-sender tool limits for Jarvis |
| `automations-setup.sh` | automation key, *Brain automations* job, Jarvis ↔ brain MCP |

## Environment (`/root/ai-brain-visual/.env`, never in git)
`APP_URL`, `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL`, `MODEL_PRICES`, `MONTHLY_BUDGET_USD`, `NOAH_EMAIL`, `NOAH_PASSWORD`, `NOAH_WHATSAPP`, `WORKSPACE`, `OPENCLAW_BIN`, `OPENCLAW_CONFIG`, `STATUS_MINUTES`, `GUIDE_URL`, `GOOGLE_OAUTH_CLIENT_ID/SECRET`, `SLACK_CLIENT_ID/SECRET`, `MCP_CLIENTS`, `AUTOMATION_KEY`, `PERISKOPE_API_KEY` (optional, else Jarvis's), `CONNECTIONS_KEY` (optional), `TRANSCRIBE_BIN`.

## Common fixes
- **Chat says an MCP server failed:** it's skipped automatically; the person reconnects it in Settings → My MCP servers.
- **Slack "No Slack user with that email":** check the person's Slack email (`users.lookupByEmail`); bot needs `users:read.email`, `im:write`.
- **Backup:** `tail -30 /var/log/jarvis-backup.log`, run `/usr/local/bin/jarvis-backup` by hand.
