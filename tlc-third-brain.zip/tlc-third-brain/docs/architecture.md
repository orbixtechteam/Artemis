# Architecture

```
WhatsApp / Telegram ──► Jarvis (OpenClaw + Claude API) ──► Gmail, Calendar, Drive, Asana, Slack, Zoom, Fathom, Periskope (Noah's accounts)
                              │  reads rules.md, AGENTS.md, playbooks-live / -approved
                              │  brain MCP (Noah's token): team accounts, automations, playbooks
                              ▼
Browser / Claude ──► Third Brain dashboard (Next.js, SQLite) ──► Claude API (chat), Periskope (WhatsApp numbers),
   (OAuth MCP)           │                                       each person's own Google / Slack / MCP servers
                         │  writes rules, lessons, skills into Jarvis's workspace; syncs Jarvis's jobs and logs
                         ▼
               VPS 187.126.15.145 (Ubuntu, 2 CPU, 8 GB) · Cloudflare Tunnel · PM2 · nightly Drive backup
```

## Dashboard
- **Stack:** Next.js 15 (App Router), Prisma + SQLite (`prisma/brain.db`), Tailwind v4, shadcn-style UI, React Flow.
- **Auth:** email + password sessions; one-time "set your own password" links; roles owner / admin / editor / viewer per department (sub-departments supported).
- **Chat:** Claude (`ANTHROPIC_MODEL`, default Sonnet), one tool registry (`src/lib/ops.ts`) shared with the MCP server. Each person's own MCP servers are passed through the Anthropic MCP connector.
- **MCP server:** `/api/mcp` with OAuth 2.1 (PKCE, dynamic client registration) for Claude; `/api/mcp/<token>` for tools without OAuth.
- **Access model:** everyone uses their own accounts (Settings → My connections). Noah can use anyone's (`as_user`) and is the only one who can use Jarvis. WhatsApp numbers are assigned per person (read / send); only Noah changes access to his own number.
- **Automations:** "when X, do Y" rules in the dashboard, run every 5 minutes by the OpenClaw job *Brain automations* (`/api/automations/run`, shared key).
- **Skills:** proposals in `workspace/playbooks-proposed`, approved ones in `workspace/playbooks-approved` (Jarvis reads both live folders) and a read-only copy in Drive `Jarvis/Playbooks`.

## Shared storage
- R2 bucket `tlc-shared` (TLC's Cloudflare account): TLC agents read/write, partners read-only. Partners' data in their own buckets, read-only for us.
