#!/bin/bash
# Run on the server after copying jarvis/scripts/{payment_summaries.py,sales_calls_filing.py} to /root/jarvis/
#   bash /root/jarvis/install-sales-calls.sh
set -euo pipefail
export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH
OC=$(which openclaw)
printf '#!/bin/sh\nOPENCLAW=%s exec /root/.local/bin/uv run --script /root/jarvis/sales_calls_filing.py "$@"\n' "$OC" > /usr/local/bin/jarvis-sales-calls
chmod +x /usr/local/bin/jarvis-sales-calls

echo "== Test (files nothing):"
jarvis-sales-calls --test || true

echo
read -r -p "Does the test show the latest sales call, its transcript and 'Google Drive access: OK'? [y/N] " OK
[ "$OK" = "y" ] || { echo "Stopped. Send the output to Claude."; exit 1; }

echo "== Backfill the last 30 days into WON / NOT WON:"
jarvis-sales-calls --days 30

if ! openclaw cron list --json | grep -q '"Sales calls filing"'; then
  openclaw cron create "30 6 * * *" --name "Sales calls filing" --command "/usr/local/bin/jarvis-sales-calls" \
    --announce --channel telegram --to "8619174084"
fi
echo "Done: runs daily at 06:30 UTC; problems go to Ulvi on Telegram."
