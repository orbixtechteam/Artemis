# /// script
# requires-python = ">=3.10"
# dependencies = ["httpx"]
# ///
import os, sys, json, time, re, fcntl, subprocess, httpx
from datetime import date, timedelta, datetime, timezone
from urllib.parse import quote

ENV = json.load(open("/root/.openclaw/openclaw.json"))["mcp"]["servers"]["zoom"]["env"]
D = "/root/.jarvis/zoom-drive"
OUT, STATE, LOCK = D + "/files", D + "/seen.json", D + "/lock"
REMOTE = "gdrive:Jarvis/Zoom calls"
DOMAINS = ["thelongevityclinic.net"]
_tok = {"v": None, "exp": 0}

def token():
    if _tok["v"] and time.time() < _tok["exp"] - 60:
        return _tok["v"]
    r = httpx.post("https://zoom.us/oauth/token",
                   params={"grant_type": "account_credentials", "account_id": ENV["ZOOM_ACCOUNT_ID"]},
                   auth=(ENV["ZOOM_CLIENT_ID"], ENV["ZOOM_CLIENT_SECRET"]), timeout=30)
    r.raise_for_status()
    d = r.json()
    _tok["v"], _tok["exp"] = d["access_token"], time.time() + d.get("expires_in", 3600)
    return _tok["v"]

def get(url, **params):
    for attempt in range(4):
        r = httpx.get(url, params=params, headers={"Authorization": f"Bearer {token()}"},
                      timeout=60, follow_redirects=True)
        if r.status_code == 429 and attempt < 3:
            time.sleep(5 * (attempt + 1)); continue
        r.raise_for_status()
        return r

def enc(uuid):
    e = quote(uuid, safe="")
    return quote(e, safe="") if uuid.startswith("/") or "//" in uuid else e

def all_users():
    users, nxt = [], None
    while True:
        p = {"status": "active", "page_size": 300}
        if nxt:
            p["next_page_token"] = nxt
        d = get("https://api.zoom.us/v2/users", **p).json()
        users += d.get("users", [])
        nxt = d.get("next_page_token")
        if not nxt:
            return users

def recordings(user_id, frm, to):
    out, nxt = [], None
    while True:
        p = {"from": frm.isoformat(), "to": to.isoformat(), "page_size": 300}
        if nxt:
            p["next_page_token"] = nxt
        d = get(f"https://api.zoom.us/v2/users/{quote(user_id, safe='')}/recordings", **p).json()
        out += d.get("meetings", [])
        nxt = d.get("next_page_token")
        if not nxt:
            return out

def participants(uuid):
    people, nxt = {}, None
    while True:
        p = {"page_size": 300}
        if nxt:
            p["next_page_token"] = nxt
        d = get(f"https://api.zoom.us/v2/past_meetings/{enc(uuid)}/participants", **p).json()
        for x in d.get("participants", []):
            key = (x.get("user_email") or x.get("name") or "").lower()
            if key:
                people[key] = {"name": x.get("name") or "", "email": x.get("user_email") or ""}
        nxt = d.get("next_page_token")
        if not nxt:
            return people

def excluded(m, people):
    if "[private]" in (m.get("topic") or "").lower():
        return "private tag"
    internal = all(p["email"] and p["email"].lower().split("@")[-1] in DOMAINS for p in people.values())
    if internal and len(people) <= 2:
        return "internal 1:1"
    return None

def transcript(m):
    for f in m.get("recording_files", []):
        if f.get("file_type") == "TRANSCRIPT":
            vtt = get(f["download_url"]).text
            return "\n".join(l for l in vtt.splitlines()
                             if l and not l.startswith("WEBVTT") and "-->" not in l and not l.strip().isdigit())
    return None

def summary(uuid):
    try:
        d = get(f"https://api.zoom.us/v2/meetings/{enc(uuid)}/meeting_summary").json()
    except Exception:
        return None
    parts = [d.get("summary_overview") or ""]
    for s in d.get("summary_details") or []:
        parts.append(f"- {s.get('label', '')}: {s.get('summary', '')}")
    if d.get("next_steps"):
        parts.append("Next steps:\n" + "\n".join(f"- {x}" for x in d["next_steps"]))
    return "\n".join(p for p in parts if p).strip() or None

def safe(s):
    return re.sub(r"[^A-Za-z0-9._-]+", "-", s or "").strip("-")[:60] or "call"

def run(days):
    os.makedirs(OUT, exist_ok=True)
    lock = open(LOCK, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print("NO_REPLY"); return
    try:
        seen = set(json.load(open(STATE)))
    except Exception:
        seen = set()
    errors, written, today = [], 0, date.today()
    windows, end = [], today + timedelta(days=1)
    while (today - end).days < days:
        start = max(end - timedelta(days=30), today - timedelta(days=days))
        windows.append((start, end))
        end = start
    users = all_users()
    for frm, to in windows:
        for u in users:
            try:
                meetings = recordings(u["id"], frm, to)
            except Exception as x:
                errors.append(f"recordings for {u.get('email')}: {x}"); continue
            for m in meetings:
                uuid = m.get("uuid")
                if not uuid or uuid in seen:
                    continue
                started = datetime.fromisoformat(m["start_time"].replace("Z", "+00:00"))
                try:
                    text = transcript(m)
                    if not text:
                        if datetime.now(timezone.utc) - started > timedelta(days=3):
                            seen.add(uuid)
                        continue
                    people = participants(uuid)
                    if excluded(m, people):
                        seen.add(uuid); continue
                    host = f"{u.get('first_name', '')} {u.get('last_name', '')}".strip() or u.get("email")
                    who = "\n".join(f"- {p['name']} {('<' + p['email'] + '>') if p['email'] else ''}".rstrip()
                                    for p in people.values())
                    body = (f"# {m.get('topic')}\n\nDate: {m['start_time']}\nHost: {host} <{u.get('email')}>\n"
                            f"Duration: {m.get('duration')} min\nLink: {m.get('share_url', '')}\n\n"
                            f"## Participants\n{who or '- (not available)'}\n\n"
                            f"## Zoom summary\n{summary(uuid) or '(no Zoom summary)'}\n\n## Transcript\n{text}\n")
                    name = f"{m['start_time'][:10]}_{safe(host)}_{safe(m.get('topic'))}.md"
                    open(os.path.join(OUT, name), "w").write(body)
                    seen.add(uuid); written += 1
                except Exception as x:
                    errors.append(f"{m.get('topic')} ({m.get('start_time', '')[:10]}): {x}")
    json.dump(sorted(seen), open(STATE, "w"))
    if written:
        r = subprocess.run(["rclone", "copy", OUT, REMOTE], capture_output=True, text=True)
        if r.returncode != 0:
            errors.append("rclone: " + r.stderr[-300:])
    if errors:
        print(f"Zoom to Drive: {written} new calls, {len(errors)} problems:\n- " + "\n- ".join(errors[:10]))
    else:
        print("NO_REPLY")

if __name__ == "__main__":
    days = int(sys.argv[2]) if len(sys.argv) > 2 and sys.argv[1] == "--backfill" else 2
    run(days)
