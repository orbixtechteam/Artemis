# /// script
# requires-python = ">=3.10"
# dependencies = ["google-api-python-client", "google-auth"]
# ///
import os, io, json, subprocess, re
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

CREDS = "/root/.google_workspace_mcp/credentials/noah@thelongevityclinic.net.json"
ROOT_ID = "1KXAwsQh-lzGz27oW9rnfFInkPWx9WkXV"
WS = "/root/.openclaw/workspace"
OUT = WS + "/playbooks-live"

def drive():
    c = json.load(open(CREDS))
    creds = Credentials(None, refresh_token=c["refresh_token"], token_uri=c["token_uri"],
                        client_id=c["client_id"], client_secret=c["client_secret"],
                        scopes=["https://www.googleapis.com/auth/drive.readonly"])
    creds.refresh(Request())
    return build("drive", "v3", credentials=creds, cache_discovery=False)

def safe(n):
    return re.sub(r'[\\/:*?"<>|]+', "-", n).strip() or "untitled"

def download(svc, f, path):
    mt = f["mimeType"]
    if mt == "application/vnd.google-apps.document":
        req = svc.files().export_media(fileId=f["id"], mimeType="text/markdown")
        if not path.endswith(".md"):
            path += ".md"
    elif mt == "application/vnd.google-apps.spreadsheet":
        req = svc.files().export_media(fileId=f["id"], mimeType="text/csv")
        path += ".csv"
    elif mt.startswith("application/vnd.google-apps."):
        return None
    elif mt.startswith("text/") or path.endswith((".md", ".py", ".txt", ".json", ".csv")):
        req = svc.files().get_media(fileId=f["id"])
    else:
        return None
    buf = io.BytesIO()
    dl = MediaIoBaseDownload(buf, req)
    done = False
    while not done:
        _, done = dl.next_chunk()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "wb").write(buf.getvalue())
    return path

def walk(svc, folder_id, local, keep):
    token = None
    while True:
        r = svc.files().list(q=f"'{folder_id}' in parents and trashed = false",
                             fields="nextPageToken, files(id, name, mimeType)",
                             pageSize=200, pageToken=token,
                             supportsAllDrives=True, includeItemsFromAllDrives=True).execute()
        for f in r.get("files", []):
            p = os.path.join(local, safe(f["name"]))
            if f["mimeType"] == "application/vnd.google-apps.folder":
                walk(svc, f["id"], p, keep)
            else:
                got = download(svc, f, p)
                if got:
                    keep.add(got)
        token = r.get("nextPageToken")
        if not token:
            break

def main():
    svc = drive()
    keep = set()
    walk(svc, ROOT_ID, OUT, keep)
    for d, _, files in os.walk(OUT):
        for n in files:
            p = os.path.join(d, n)
            if p not in keep:
                os.remove(p)
    subprocess.run(["git", "-C", WS, "add", "-A", "playbooks-live"], check=True)
    r = subprocess.run(["git", "-C", WS, "diff", "--cached", "--quiet"])
    if r.returncode != 0:
        subprocess.run(["git", "-C", WS, "commit", "-q", "-m", "Playbooks sync from Drive"], check=True)
        print("NO_REPLY")
    else:
        print("NO_REPLY")

if __name__ == "__main__":
    try:
        main()
    except Exception as x:
        print(f"Playbooks sync problem: {x}")
