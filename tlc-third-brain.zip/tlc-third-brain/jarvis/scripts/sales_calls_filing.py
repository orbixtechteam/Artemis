# /// script
# requires-python = ">=3.10"
# dependencies = ["httpx"]
# ///
"""
Sales calls → Sales knowledge base, filed as WON or NOT WON (daily).

1. Collects call transcripts from Zoom (every user's cloud recordings, Personal Meeting Rooms included)
   and Fathom, for the last few days.
2. Keeps sales calls only: at least one outside participant, not an internal 1:1, not tagged [private],
   and (by default) the topic or host looks like a sales call. In a recording with several people,
   each outside person gets their own file with only their part.
3. WON if the person appears in #sales-payment-made (name or email), otherwise NOT WON.
   People filed as NOT WON who pay later are moved to WON on the next run.
4. Writes one Google Doc per person per call into the two Drive folders, with Noah's Google account.

  sales_calls_filing.py            daily run (cron)
  sales_calls_filing.py --test     shows the most recent sales call it finds and its transcript length; files nothing
  sales_calls_filing.py --days 30  backfill
"""
import os, re, sys, json, time, fcntl, httpx
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import payment_summaries as ps   # Zoom, Slack, transcript parsing and name matching live there

D = "/root/.jarvis/sales-calls"
STATE, LOCK = D + "/state.json", D + "/lock"
WON = os.environ.get("WON_FOLDER", "1q3zcp-fZiX7OlI3d8NrJxlYbxFuwOk09")
NOT_WON = os.environ.get("NOT_WON_FOLDER", "1yV_LeTHpEFNXpKzt_gZqKLQzqKoCP9b7")
GOOGLE_CREDS = os.environ.get("GOOGLE_CREDS", "/root/.google_workspace_mcp/credentials/noah@thelongevityclinic.net.json")
SALES_TOPIC = re.compile(os.environ.get("SALES_TOPIC_RE", r"discovery|sales|consult|strategy|intro|personal meeting room|call with noah|longevity call"), re.I)
SALES_HOSTS = [h.strip().lower() for h in os.environ.get("SALES_HOSTS", "noah@thelongevityclinic.net").split(",") if h.strip()]
PAYMENT_LOOKBACK_DAYS = 120

# ---------------- Google Drive (Noah's account) ----------------
_g = {"v": None, "exp": 0}
def gtoken():
    if _g["v"] and time.time() < _g["exp"] - 60:
        return _g["v"]
    c = json.load(open(GOOGLE_CREDS))
    r = httpx.post(c.get("token_uri", "https://oauth2.googleapis.com/token"), data={
        "client_id": c["client_id"], "client_secret": c["client_secret"], "refresh_token": c["refresh_token"], "grant_type": "refresh_token"}, timeout=30)
    r.raise_for_status()
    d = r.json()
    _g["v"], _g["exp"] = d["access_token"], time.time() + d.get("expires_in", 3600)
    return _g["v"]

def drive_create_doc(folder, name, text):
    boundary = "tb" + str(int(time.time() * 1000))
    meta = json.dumps({"name": name, "mimeType": "application/vnd.google-apps.document", "parents": [folder]})
    body = f"--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n{meta}\r\n--{boundary}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n{text}\r\n--{boundary}--"
    r = httpx.post("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true&fields=id,webViewLink",
                   content=body.encode(), headers={"Authorization": f"Bearer {gtoken()}", "Content-Type": f"multipart/related; boundary={boundary}"}, timeout=120)
    if r.status_code >= 400:
        raise RuntimeError(f"Drive {r.status_code}: {r.text[:200]}")
    return r.json()

def drive_move(file_id, to_folder, from_folder):
    r = httpx.patch(f"https://www.googleapis.com/drive/v3/files/{file_id}?addParents={to_folder}&removeParents={from_folder}&supportsAllDrives=true",
                    headers={"Authorization": f"Bearer {gtoken()}"}, json={}, timeout=60)
    if r.status_code >= 400:
        raise RuntimeError(f"Drive move {r.status_code}: {r.text[:200]}")

# ---------------- payments (who has paid) ----------------
def payers():
    ch = ps.channel_id()
    oldest, out = str(time.time() - PAYMENT_LOOKBACK_DAYS * 86400), []
    cursor = ""
    for _ in range(20):
        d = ps.slack("conversations.history", channel=ch, oldest=oldest, limit=200, cursor=cursor)
        for m in d.get("messages", []):
            if m.get("thread_ts") and m.get("thread_ts") != m.get("ts"):
                continue
            p = ps.payer_from_post(ps.message_text(m))
            if p["names"] or p["emails"]:
                out.append({**p, "ts": float(m["ts"])})
        cursor = (d.get("response_metadata") or {}).get("next_cursor") or ""
        if not cursor:
            break
    return out

def has_paid(name, email, pays):
    for p in pays:
        if email and email.lower() in p["emails"]:
            return True
        if name and ps.is_payer(name, p):
            return True
    return False

# ---------------- calls ----------------
def zoom_calls(days):
    now = datetime.now(timezone.utc)
    staff, calls = ps.staff_names(), []
    for m in ps.recordings_between(now - timedelta(days=days), now):
        if "[private]" in (m.get("topic") or "").lower():
            continue
        state, vtt = ps.transcript_state(m)
        if state != "ready":
            continue
        people = ps.participants(m["uuid"]) if m.get("uuid") else []
        cues = ps.parse_vtt(vtt)
        outsiders = sorted({c["speaker"] for c in cues if " ".join(ps.norm(c["speaker"])) not in staff})
        host_email = next((u.get("email", "").lower() for u in ps.zoom_users() if f"{u.get('first_name', '')} {u.get('last_name', '')}".strip() == m.get("_host")), "")
        if not outsiders or not (SALES_TOPIC.search(m.get("topic") or "") or host_email in SALES_HOSTS):
            continue
        start = datetime.fromisoformat(m["start_time"].replace("Z", "+00:00"))
        for who in outsiders:
            seg = ps.payer_segment(cues, {who}, staff)
            if not seg or len(seg["text"]) < 400:     # a few words is not a call
                continue
            email = next((p["email"] for p in people if p["email"] and set(ps.norm(p["name"])) & set(ps.norm(who))), "")
            calls.append({"id": f"zoom:{m['uuid']}:{who}", "source": "Zoom", "name": who, "email": email, "start": start,
                          "topic": m.get("topic") or "", "host": m.get("_host"), "from_min": seg["start_min"], "shared": len(outsiders) > 1, "text": seg["text"]})
    return calls

def fathom_calls(days):
    env = ps.CFG["mcp"]["servers"].get("fathom", {}).get("env", {})
    key = env.get("FATHOM_API_KEY") or env.get("API_KEY") or os.environ.get("FATHOM_API_KEY")
    if not key:
        return []
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat().replace("+00:00", "Z")
    calls, cursor = [], None
    for _ in range(20):
        params = {"created_after": since, "include_transcript": "true"}
        if cursor:
            params["cursor"] = cursor
        r = httpx.get("https://api.fathom.ai/external/v1/meetings", params=params, headers={"X-Api-Key": key}, timeout=60)
        if r.status_code >= 400:
            raise RuntimeError(f"Fathom {r.status_code}: {r.text[:150]}")
        d = r.json()
        for mt in d.get("items", []):
            invitees = [i for i in mt.get("calendar_invitees", []) if i.get("is_external")]
            title = mt.get("title") or mt.get("meeting_title") or ""
            if not invitees or "[private]" in title.lower():
                continue
            lines = [f"[{(t.get('timestamp') or '')[:8]}] {(t.get('speaker') or {}).get('display_name', '?')}: {t.get('text', '')}" for t in (mt.get("transcript") or [])]
            if len("\n".join(lines)) < 400:
                continue
            for inv in invitees:
                calls.append({"id": f"fathom:{mt.get('recording_id') or mt.get('url')}:{inv.get('email')}", "source": "Fathom", "name": inv.get("name") or inv.get("email"),
                              "email": (inv.get("email") or "").lower(), "start": datetime.fromisoformat((mt.get("recording_start_time") or mt.get("created_at")).replace("Z", "+00:00")),
                              "topic": title, "host": (mt.get("recorded_by") or {}).get("name", ""), "from_min": 0, "shared": len(invitees) > 1, "text": "\n".join(lines)})
        cursor = d.get("next_cursor")
        if not cursor:
            break
    return calls

def doc_text(c, won):
    return (f"{c['name']}{' <' + c['email'] + '>' if c['email'] else ''}\n"
            f"Call: {c['start']:%d %b %Y %H:%M} UTC · {c['source']} · {c['topic']} · host {c['host']}"
            + (f" · their part starts at minute {c['from_min']}" if c["shared"] else "") + "\n"
            f"Status: {'WON (paid, see #sales-payment-made)' if won else 'NOT WON (no payment yet)'}\n\n"
            f"Transcript\n\n{c['text']}\n")

# ---------------- main ----------------
def run(days):
    os.makedirs(D, exist_ok=True)
    lock = open(LOCK, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print("NO_REPLY"); return
    try:
        st = json.load(open(STATE))
    except Exception:
        st = {"filed": {}}
    problems, filed, moved = [], {"WON": 0, "NOT WON": 0}, 0
    pays = payers()
    calls = []
    for fn in (zoom_calls, fathom_calls):
        try:
            calls += fn(days)
        except Exception as x:
            problems.append(f"{fn.__name__}: {str(x)[:200]}")
    for c in calls:
        if c["id"] in st["filed"]:
            continue
        won = has_paid(c["name"], c["email"], pays)
        try:
            f = drive_create_doc(WON if won else NOT_WON, f"{c['start']:%Y-%m-%d} - {c['name']} - {c['source']}", doc_text(c, won))
            st["filed"][c["id"]] = {"file": f["id"], "won": won, "name": c["name"], "email": c["email"], "at": time.time()}
            filed["WON" if won else "NOT WON"] += 1
        except Exception as x:
            problems.append(f"{c['name']} ({c['start']:%d %b}): {str(x)[:200]}")
    # People who paid after their call: NOT WON → WON
    for cid, it in st["filed"].items():
        if not it["won"] and has_paid(it["name"], it.get("email"), pays):
            try:
                drive_move(it["file"], WON, NOT_WON)
                it["won"] = True; moved += 1
            except Exception as x:
                problems.append(f"move {it['name']}: {str(x)[:150]}")
    json.dump(st, open(STATE, "w"))
    if problems:
        print("Sales call filing problems:\n- " + "\n- ".join(problems[:10]))
    elif filed["WON"] or filed["NOT WON"] or moved:
        print(f"Sales calls filed: {filed['WON']} WON, {filed['NOT WON']} NOT WON" + (f", {moved} moved to WON after paying" if moved else "") + ".")
    else:
        print("NO_REPLY")

def test():
    calls = []
    for fn in (zoom_calls, fathom_calls):
        try:
            got = fn(7); calls += got; print(f"{fn.__name__}: {len(got)} sales-call parts in the last 7 days")
        except Exception as x:
            print(f"{fn.__name__}: ERROR {x}")
    if not calls:
        print("No sales calls found."); return
    c = max(calls, key=lambda x: x["start"])
    pays = payers()
    print(f"\nMost recent: {c['name']} · {c['start']:%d %b %Y %H:%M} UTC · {c['source']} · {c['topic']} · from minute {c['from_min']}")
    print(f"Transcript: {len(c['text'])} characters, {c['text'].count(chr(10)) + 1} lines · would file as {'WON' if has_paid(c['name'], c['email'], pays) else 'NOT WON'}")
    print("\n" + c["text"][:800] + "\n…")
    try:
        gtoken(); print("\nGoogle Drive access: OK")
    except Exception as x:
        print(f"\nGoogle Drive access: ERROR {x}")

if __name__ == "__main__":
    if "--test" in sys.argv:
        test()
    else:
        run(int(sys.argv[sys.argv.index("--days") + 1]) if "--days" in sys.argv else 3)
