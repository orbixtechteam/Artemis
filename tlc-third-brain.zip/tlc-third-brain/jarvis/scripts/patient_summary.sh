#!/bin/sh
OUT=/root/.jarvis/patients; mkdir -p "$OUT"
for P in "$@"; do
  MSG="Write the patient summary file for $P. Sources: the 'Meeting ai summary with patients' sheet, the Drive folder Jarvis/Zoom calls, Gmail, WhatsApp (periskope find_chat and get_chat_messages) and Asana. Use these headings: Program and phase/week; Coach; Doctor; Latest bloodwork (link and key values); Current medication, peptides and supplements as prescribed; Open issues; Last call (date and 5-line summary); Payment status; Next steps and dates; Sources. Under each heading write what you found with its source, or 'Not found'. Never guess, never include staff scores. Output only the file content in Markdown."
  openclaw agent --agent main --session-key "agent:main:patient-$(echo "$P" | tr ' ' '-')" --message "$MSG" --timeout 400 > "$OUT/$P.md" 2>/dev/null
  echo "done: $P"
done
rclone copy "$OUT" "gdrive:Jarvis/Patients"
