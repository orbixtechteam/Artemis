# /// script
# requires-python = ">=3.10"
# dependencies = ["google-api-python-client", "google-auth", "google-auth-oauthlib"]
# ///
import os, sys, json, fcntl, subprocess, datetime as dt
from zoneinfo import ZoneInfo
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

D = "/root/.jarvis/calendar"
TOKEN, STATE, LOCK = D + "/token.json", D + "/state.json", D + "/lock"
CLIENT = "/root/.google_workspace_mcp/credentials/noah@thelongevityclinic.net.json"
SCOPES = ["https://www.googleapis.com/auth/calendar.events"]
OC = os.environ.get("OPENCLAW", "openclaw")
NOAH_TZ = os.environ.get("NOAH_TZ", "Europe/Madrid")
MAX_NEW, DAYS = 5, 14
FAIL_TEXT = "Jarvis could not prepare this brief yet. It will retry automatically."

def auth_setup():
    from google_auth_oauthlib.flow import InstalledAppFlow
    c = json.load(open(CLIENT))
    cfg = {"installed": {"client_id": c["client_id"], "client_secret": c["client_secret"],
                         "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                         "token_uri": c["token_uri"], "redirect_uris": ["http://localhost:8001/"]}}
    flow = InstalledAppFlow.from_client_config(cfg, SCOPES)
    creds = flow.run_local_server(port=8001, open_browser=False, access_type="offline",
                                  prompt="consent", login_hint="noah@thelongevityclinic.net")
    os.makedirs(D, exist_ok=True)
    open(TOKEN, "w").write(creds.to_json())
    os.chmod(TOKEN, 0o600)
    print("token saved")

def service():
    creds = Credentials.from_authorized_user_file(TOKEN, SCOPES)
    if not creds.valid:
        creds.refresh(Request())
        open(TOKEN, "w").write(creds.to_json())
    return build("calendar", "v3", credentials=creds, cache_discovery=False)

def parse(t):
    return dt.datetime.fromisoformat(t["dateTime"].replace("Z", "+00:00"))

def is_call(e):
    if e.get("status") == "cancelled" or "dateTime" not in e.get("start", {}):
        return False
    if (e.get("extendedProperties", {}).get("private") or {}).get("jarvis") == "context":
        return False
    if "[private]" in (e.get("summary") or "").lower():
        return False
    att = e.get("attendees", [])
    if any(a.get("self") and a.get("responseStatus") == "declined" for a in att):
        return False
    others = [a for a in att if not a.get("self") and not a.get("resource")]
    text = (e.get("location") or "") + (e.get("description") or "")
    return bool(others or e.get("hangoutLink") or e.get("conferenceData") or "zoom.us" in text)

def time_check(e):
    local = parse(e["start"]).astimezone(ZoneInfo(NOAH_TZ))
    warns = []
    if local.hour < 7 or local.hour >= 22:
        warns.append(f"TIME CHECK: starts at {local:%H:%M} your time ({NOAH_TZ}). Please confirm the time.")
    tz = e["start"].get("timeZone")
    if tz and tz != NOAH_TZ:
        warns.append(f"TIME CHECK: booked in {tz}; for you it is {local:%a %d %b %H:%M}.")
    return warns

def pick(obj, skip):
    found = []
    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if isinstance(v, str) and k in ("text", "reply", "content", "output", "result") and v != skip:
                    found.append(v)
                else:
                    walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(obj)
    return max(found, key=len) if found else None

def brief(e):
    att = ", ".join(a.get("email", "") for a in e.get("attendees", []) if not a.get("self"))
    msg = (f"Prepare a pre-call context brief for this calendar event.\n"
           f"Title: {e.get('summary')}\nStart: {e['start'].get('dateTime')}\nAttendees: {att}\n"
           f"Description: {(e.get('description') or '')[:1500]}\n\n"
           "If a 'Pre-call context brief' playbook exists in the Drive Playbooks folder, follow it. "
           "Otherwise include: who they are, the last conversation (Fathom, Gmail, WhatsApp), what was promised "
           "on both sides, open issues, payment or program status, and any bloodwork link. "
           "Plain text, at most 25 lines. If you cannot find something, say so; never guess. "
           "Do not send or change anything.")
    try:
        r = subprocess.run([OC, "agent", "--agent", "main",
                            "--session-key", "agent:main:calbrief-" + e["id"][:40],
                            "--message", msg, "--json", "--timeout", "300"],
                           capture_output=True, text=True, timeout=360)
        out = r.stdout
        return pick(json.loads(out[out.find("{"):]), msg)
    except Exception:
        return None

def description(e, text):
    warns = time_check(e)
    body = (text or FAIL_TEXT)
    return ("\n".join(warns) + "\n\n" + body if warns else body)[:7900]

def find_existing(svc, sid):
    r = svc.events().list(calendarId="primary", privateExtendedProperty=f"source={sid}",
                          maxResults=5).execute()
    items = [x for x in r.get("items", []) if x.get("status") != "cancelled"]
    return items[0]["id"] if items else None

def ctx_body(e, text):
    return {"summary": "Context: " + (e.get("summary") or "call"), "start": e["start"], "end": e["end"],
            "colorId": "8", "description": description(e, text), "transparency": "transparent",
            "reminders": {"useDefault": False, "overrides": []},
            "extendedProperties": {"private": {"jarvis": "context", "source": e["id"]}}}

def run():
    os.makedirs(D, exist_ok=True)
    lock = open(LOCK, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print("NO_REPLY"); return
    svc = service()
    now = dt.datetime.now(dt.timezone.utc)
    try:
        state = json.load(open(STATE))
    except Exception:
        state = {}
    items, token = [], None
    while True:
        r = svc.events().list(calendarId="primary", timeMin=now.isoformat(),
                              timeMax=(now + dt.timedelta(days=DAYS)).isoformat(),
                              singleEvents=True, orderBy="startTime", maxResults=250,
                              pageToken=token).execute()
        items += r.get("items", [])
        token = r.get("nextPageToken")
        if not token:
            break
    seen, made, errors = set(), 0, []
    for e in items:
        if not is_call(e):
            continue
        sid = e["id"]; seen.add(sid)
        st = state.get(sid)
        try:
            if st is None:
                existing = find_existing(svc, sid)
                if existing:
                    state[sid] = {"ctx": existing, "start": e["start"], "end": e["end"], "ok": True, "tries": 0}
                    continue
                if made >= MAX_NEW:
                    continue
                made += 1
                text = brief(e)
                ctx = svc.events().insert(calendarId="primary", body=ctx_body(e, text)).execute()
                state[sid] = {"ctx": ctx["id"], "start": e["start"], "end": e["end"],
                              "ok": bool(text), "tries": 1, "text": text or ""}
            else:
                if st["start"] != e["start"] or st["end"] != e["end"]:
                    svc.events().patch(calendarId="primary", eventId=st["ctx"],
                                       body={"start": e["start"], "end": e["end"],
                                             "description": description(e, st.get("text"))}).execute()
                    st["start"], st["end"] = e["start"], e["end"]
                if not st.get("ok") and st.get("tries", 0) < 3 and made < MAX_NEW:
                    made += 1
                    text = brief(e)
                    st["tries"] = st.get("tries", 0) + 1
                    if text:
                        svc.events().patch(calendarId="primary", eventId=st["ctx"],
                                           body={"description": description(e, text)}).execute()
                        st["ok"], st["text"] = True, text
        except Exception as x:
            errors.append(f"{e.get('summary')}: {x}")
    for sid in list(state):
        if sid in seen:
            continue
        st = state[sid]
        end = parse(st["end"])
        if end < now - dt.timedelta(days=1):
            del state[sid]; continue
        if end < now:
            continue
        try:
            ev = svc.events().get(calendarId="primary", eventId=sid).execute()
            gone = ev.get("status") == "cancelled" or not is_call(ev)
        except HttpError as x:
            gone = x.resp.status in (404, 410)
        if gone:
            try:
                svc.events().delete(calendarId="primary", eventId=st["ctx"]).execute()
            except HttpError:
                pass
            del state[sid]
    json.dump(state, open(STATE, "w"))
    print("Calendar briefs problems:\n- " + "\n- ".join(errors) if errors else "NO_REPLY")

if __name__ == "__main__":
    auth_setup() if sys.argv[1:] == ["auth"] else run()
