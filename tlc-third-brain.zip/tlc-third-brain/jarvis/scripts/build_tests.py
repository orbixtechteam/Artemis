# /// script
# requires-python = ">=3.10"
# dependencies = ["httpx"]
# ///
import os, re, csv, json, time, subprocess, httpx

OC = os.environ.get("OPENCLAW", "openclaw")
CONFIG = "/root/.openclaw/openclaw.json"
WS = "/root/.openclaw/workspace"
ZOOM = "/root/.jarvis/zoom-drive/files"
N = 10

def slack(method, **params):
    tok = json.load(open(CONFIG))["mcp"]["servers"]["slack"]["env"]["SLACK_MCP_XOXB_TOKEN"]
    d = httpx.post("https://slack.com/api/" + method, data=params,
                   headers={"Authorization": "Bearer " + tok}, timeout=60).json()
    if not d.get("ok"):
        raise RuntimeError(f"{method}: {d.get('error')}")
    return d

def pick(obj, skip):
    found = []
    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if isinstance(v, str) and k in ("text", "reply", "content", "output", "result") and v != skip:
                    found.append(v)
                else:
                    walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(obj)
    return max(found, key=len) if found else ""

def ask(key, msg):
    try:
        r = subprocess.run([OC, "agent", "--agent", "main", "--session-key", key,
                            "--message", msg, "--json", "--timeout", "400"],
                           capture_output=True, text=True, timeout=460)
        return pick(json.loads(r.stdout[r.stdout.find("{"):]), msg)
    except Exception as x:
        return f"ERROR: {x}"

def text_of(m):
    parts = [m.get("text") or ""]
    for a in m.get("attachments") or []:
        parts += [a.get("text") or "", a.get("fallback") or ""]
    return "\n".join(p for p in parts if p).strip()

def payment_cases():
    ch = json.load(open("/root/.jarvis/payments/state.json"))["channel"]
    msgs = slack("conversations.history", channel=ch, limit=200).get("messages", [])
    real = [m for m in msgs if (m.get("bot_id") or m.get("subtype") == "bot_message")
            and re.search(r"amount|payment", text_of(m), re.I)]
    rows = []
    for i, m in enumerate(real[:N], 1):
        t = text_of(m)
        when = time.strftime("%Y-%m-%d", time.gmtime(float(m["ts"])))
        msg = ("TEST RUN. Do not post or send anything. A payment was posted in Slack #sales-payment-made on "
               f"{when}:\n---\n{t[:2500]}\n---\nWrite the payment summary as you would for its thread: client, program "
               "and amount, 3 to 5 key points from their most recent call before or around this date, promises on both "
               "sides, next steps. At most 15 lines. If you cannot find the call, say so; never guess.")
        rows.append(["payment-summary", f"P{i:02d}", f"{when} | {t[:300]}", ask(f"agent:main:test-pay-{i}", msg), "", ""])
        print("payment case", i, flush=True)
    return rows

def brief_cases():
    files = sorted(os.listdir(ZOOM), reverse=True)
    pick_files, skip = [], re.compile(r"huddle|team|internal|ops|meeting|catch up|x nebo|x ulvi|denisa", re.I)
    for f in files:
        if not skip.search(f):
            pick_files.append(f)
        if len(pick_files) >= N:
            break
    rows = []
    for i, f in enumerate(pick_files, 1):
        head = open(os.path.join(ZOOM, f)).read().split("## Zoom summary")[0][:1500]
        date = f[:10]
        msg = ("TEST RUN. Do not send or change anything. Prepare the pre-call context brief for this call as if it were "
               f"the morning of {date}, BEFORE the call happened. Use only information dated before {date}; ignore the "
               f"call itself and anything after it.\n---\n{head}\n---\nInclude who they are, the last conversation, "
               "promises on both sides, open issues, payment or program status, bloodwork link. At most 25 lines. "
               "If you cannot find something, say so; never guess.")
        rows.append(["pre-call-brief", f"B{i:02d}", f"{date} | {head.splitlines()[0][:200]}",
                     ask(f"agent:main:test-brief-{i}", msg), "", ""])
        print("brief case", i, flush=True)
    return rows

def save(name, rows):
    hdr = ["playbook", "case", "input", "jarvis_output", "verdict (pass/fail)", "noah_note"]
    d = f"{WS}/playbooks/{name}/tests"
    os.makedirs(d, exist_ok=True)
    path = f"{d}/cases.csv"
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(hdr); w.writerows(rows)
    subprocess.run(["rclone", "copyto", path, f"gdrive:Jarvis/Tests/{name} test set.csv",
                    "--drive-import-formats", "csv"], check=False)

if __name__ == "__main__":
    save("payment-summary", payment_cases())
    save("pre-call-brief", brief_cases())
    print("done")
