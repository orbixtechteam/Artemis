# /// script
# requires-python = ">=3.10"
# dependencies = ["httpx"]
# ///
"""
Payment summaries for #sales-payment-made.

For each new payment post:
  1. Work out who paid (name and email from the post).
  2. Find the Zoom call where they paid: every Zoom user's recordings around the payment time,
     Personal Meeting Rooms included, matched on transcript speaker names and participant emails.
  3. In a recording with several patients, keep only the payer's part (from their first words
     until the next patient starts) and note the minute it starts.
  4. If the recording or its transcript isn't ready yet, wait and try again on the next run.
     Never write a summary from older calls, email or WhatsApp instead.
  5. Jarvis writes the thread reply from that part only, with the Sales Kit template, a source line,
     and price flags only after checking the Payment Links master list.
"""
import os, re, json, time, fcntl, subprocess, unicodedata, httpx
from datetime import datetime, timedelta, timezone
from urllib.parse import quote
from zoneinfo import ZoneInfo

D = "/root/.jarvis/payments"
STATE, LOCK = D + "/state.json", D + "/lock"
CONFIG = "/root/.openclaw/openclaw.json"
CHANNEL_NAME = os.environ.get("PAY_CHANNEL", "sales-payment-made")
OC = os.environ.get("OPENCLAW", "openclaw")
DOMAINS = ("thelongevityclinic.net",)
MAX_PER_RUN = 3
GIVE_UP_HOURS = 24          # no call found by then: alert, don't guess
LOOKBACK_HOURS = 30         # the paying call is usually just before the payment
HEADER = "Jarvis call summary (please check):\n"
# Payments that aren't a programme sale get no call summary
SKIP_PROGRAM = re.compile(os.environ.get("SKIP_PROGRAM_RE", r"\b(B2B|B2C|order|supply|hotel|flights?|refill|shipping)\b"), re.I)

CFG = json.load(open(CONFIG))
ZOOM = CFG["mcp"]["servers"]["zoom"]["env"]
_tok = {"v": None, "exp": 0}

# ---------------- Slack ----------------
def slack_token():
    return CFG["mcp"]["servers"]["slack"]["env"]["SLACK_MCP_XOXB_TOKEN"]

def slack(method, **params):
    r = httpx.post("https://slack.com/api/" + method, data=params, headers={"Authorization": "Bearer " + slack_token()}, timeout=60)
    d = r.json()
    if not d.get("ok"):
        raise RuntimeError(f"{method}: {d.get('error')}")
    return d

def channel_id():
    cursor = ""
    while True:
        d = slack("conversations.list", types="public_channel,private_channel", limit=1000, exclude_archived="true", cursor=cursor)
        for c in d.get("channels", []):
            if c.get("name") == CHANNEL_NAME:
                return c["id"]
        cursor = (d.get("response_metadata") or {}).get("next_cursor") or ""
        if not cursor:
            raise RuntimeError(f"channel #{CHANNEL_NAME} not found (is Jarvis invited?)")

def message_text(m):
    parts = [m.get("text") or ""]
    for a in m.get("attachments") or []:
        parts += [a.get("pretext") or "", a.get("title") or "", a.get("text") or "", a.get("fallback") or ""]
        for f in a.get("fields") or []:
            parts.append(f"{f.get('title')}: {f.get('value')}")
    for b in m.get("blocks") or []:
        if isinstance(b.get("text"), dict) and b["text"].get("text"):
            parts.append(b["text"]["text"])
        for f in b.get("fields") or []:
            if isinstance(f, dict) and f.get("text"):
                parts.append(f["text"])
    return "\n".join(p for p in parts if p).strip()

# ---------------- Zoom ----------------
def zoom_token():
    if _tok["v"] and time.time() < _tok["exp"] - 60:
        return _tok["v"]
    r = httpx.post("https://zoom.us/oauth/token", params={"grant_type": "account_credentials", "account_id": ZOOM["ZOOM_ACCOUNT_ID"]},
                   auth=(ZOOM["ZOOM_CLIENT_ID"], ZOOM["ZOOM_CLIENT_SECRET"]), timeout=30)
    r.raise_for_status()
    d = r.json()
    _tok["v"], _tok["exp"] = d["access_token"], time.time() + d.get("expires_in", 3600)
    return _tok["v"]

def zget(url, **params):
    for attempt in range(4):
        r = httpx.get(url, params=params, headers={"Authorization": f"Bearer {zoom_token()}"}, timeout=60, follow_redirects=True)
        if r.status_code == 429 and attempt < 3:
            time.sleep(5 * (attempt + 1)); continue
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r

def enc(uuid):
    e = quote(uuid, safe="")
    return quote(e, safe="") if uuid.startswith("/") or "//" in uuid else e

_users = None
def zoom_users():
    global _users
    if _users is None:
        _users, nxt = [], None
        while True:
            p = {"status": "active", "page_size": 300}
            if nxt:
                p["next_page_token"] = nxt
            d = zget("https://api.zoom.us/v2/users", **p).json()
            _users += d.get("users", [])
            nxt = d.get("next_page_token")
            if not nxt:
                break
    return _users

def recordings_between(frm, to):
    """Every user's cloud recordings that started in [frm, to], Personal Meeting Rooms included."""
    out = []
    for u in zoom_users():
        nxt = None
        while True:
            p = {"from": (frm - timedelta(days=1)).date().isoformat(), "to": (to + timedelta(days=1)).date().isoformat(), "page_size": 300}
            if nxt:
                p["next_page_token"] = nxt
            r = zget(f"https://api.zoom.us/v2/users/{quote(u['id'], safe='')}/recordings", **p)
            d = r.json() if r else {}
            for m in d.get("meetings", []):
                st = datetime.fromisoformat(m["start_time"].replace("Z", "+00:00"))
                if frm <= st <= to:
                    m["_host"] = f"{u.get('first_name', '')} {u.get('last_name', '')}".strip() or u.get("email")
                    out.append(m)
            nxt = d.get("next_page_token")
            if not nxt:
                break
    return out

def participants(uuid):
    r = zget(f"https://api.zoom.us/v2/past_meetings/{enc(uuid)}/participants", page_size=300)
    return [{"name": x.get("name") or "", "email": (x.get("user_email") or "").lower()} for x in (r.json().get("participants", []) if r else [])]

def transcript_state(m):
    """('ready', vtt) / ('processing', None) / ('none', None)."""
    files = m.get("recording_files", [])
    for f in files:
        if f.get("file_type") == "TRANSCRIPT":
            if f.get("status") and f["status"] != "completed":
                return "processing", None
            r = zget(f["download_url"])
            return ("ready", r.text) if r else ("processing", None)
    if any(f.get("status") == "processing" for f in files):
        return "processing", None
    # The transcript can arrive a while after the video
    st = datetime.fromisoformat(m["start_time"].replace("Z", "+00:00"))
    return ("processing", None) if datetime.now(timezone.utc) - st < timedelta(hours=6) else ("none", None)

# ---------------- transcript parsing and matching ----------------
def norm(s):
    s = unicodedata.normalize("NFKD", s or "")
    return re.sub(r"[^a-z ]", " ", "".join(c for c in s if not unicodedata.combining(c)).lower()).split()

def parse_vtt(vtt):
    cues, t = [], None
    for line in vtt.splitlines():
        m = re.match(r"(\d+):(\d{2}):(\d{2})[.,]\d+\s*-->", line)
        if m:
            t = int(m[1]) * 3600 + int(m[2]) * 60 + int(m[3]); continue
        if not line.strip() or line.strip().isdigit() or line.startswith("WEBVTT"):
            continue
        sp, _, txt = line.partition(": ")
        if t is not None and txt and len(sp) < 60:
            cues.append({"t": t, "speaker": sp.strip(), "text": txt.strip()})
        elif cues:
            cues[-1]["text"] += " " + line.strip()
    return cues

def payer_from_post(text):
    emails = [e.lower() for e in re.findall(r"[\w.+-]+@[\w-]+\.[\w.]+", text) if not e.lower().endswith(DOMAINS)]
    names = []
    # "*Client:* Robynne de Courtenay" (Whop / Stripe posts), "Customer: …", "Name - …"
    for m in re.finditer(r"(?:client|customer|name|buyer|payer)[*_\s]*[:\-][*_\s]*([^\n*|<]{3,60})", text, re.I):
        n = re.sub(r"\s+", " ", m.group(1)).strip(" .,-")
        if len(norm(n)) >= 2 and not re.search(r"\b(ltd|llc|kft|gmbh|inc|marketing|strategic)\b", n, re.I):
            names.append(n)
    if not names:
        names = [m.group(0) for m in re.finditer(r"\b[A-Z][a-z'’-]+(?:[ \t]+(?:(?:de|van|von|der|da|di|le|la|al|el|bin)[ \t]+)?[A-Z][a-z'’-]+){1,2}\b", text)][:3]
    return {"emails": sorted(set(emails)), "names": names}

def is_payer(name, payer):
    toks = set(norm(name))
    return any(len(nt) >= 2 and nt[0] in toks and nt[-1] in toks for nt in (norm(n) for n in payer["names"]))

def staff_names():
    return {" ".join(norm(f"{u.get('first_name', '')} {u.get('last_name', '')}")) for u in zoom_users()}

def payer_segment(cues, payer_speakers, staff):
    """The payer's part: from just before their first words until another (non-staff) patient starts."""
    idx = [i for i, c in enumerate(cues) if c["speaker"] in payer_speakers]
    if not idx:
        return None
    first, last = idx[0], idx[-1]
    is_staff = lambda sp: " ".join(norm(sp)) in staff
    start = first
    while start > 0 and is_staff(cues[start - 1]["speaker"]) and cues[first]["t"] - cues[start - 1]["t"] < 120:
        start -= 1
    end = last
    while end + 1 < len(cues) and is_staff(cues[end + 1]["speaker"]) and cues[end + 1]["t"] - cues[last]["t"] < 600:
        end += 1
    seg = cues[start:end + 1]
    return {"start_min": seg[0]["t"] // 60, "end_min": seg[-1]["t"] // 60,
            "text": "\n".join(f"[{c['t'] // 60:02d}:{c['t'] % 60:02d}] {c['speaker']}: {c['text']}" for c in seg)}

def find_call(paid_at, payer):
    """('found', call) / ('wait', reason) / ('missing', reason)."""
    meetings = recordings_between(paid_at - timedelta(hours=LOOKBACK_HOURS), paid_at + timedelta(minutes=30))
    meetings.sort(key=lambda m: abs((paid_at - datetime.fromisoformat(m["start_time"].replace("Z", "+00:00"))).total_seconds()))
    staff, waiting = staff_names(), []
    for m in meetings:
        people = participants(m["uuid"]) if m.get("uuid") else []
        by_email = [p for p in people if p["email"] and p["email"] in payer["emails"]]
        state, vtt = transcript_state(m)
        if state == "processing":
            if by_email or any(is_payer(p["name"], payer) for p in people) or not people:
                waiting.append(m.get("topic") or "a recording")
            continue
        if state != "ready":
            continue
        cues = parse_vtt(vtt)
        speakers = {c["speaker"] for c in cues}
        match = {s for s in speakers if is_payer(s, payer)}
        match |= {s for s in speakers for p in by_email if set(norm(s)) & set(norm(p["name"])) and " ".join(norm(s)) not in staff}
        if not match:
            continue
        seg = payer_segment(cues, match, staff)
        if not seg:
            continue
        others = {s for s in speakers if s not in match and " ".join(norm(s)) not in staff}
        return "found", {"topic": m.get("topic") or "", "host": m.get("_host"),
                         "start": datetime.fromisoformat(m["start_time"].replace("Z", "+00:00")), "segment": seg, "shared": bool(others)}
    if waiting:
        return "wait", f"recording not ready yet ({waiting[0]})"
    if datetime.now(timezone.utc) - paid_at < timedelta(hours=GIVE_UP_HOURS):
        return "wait", "no matching recording yet"
    return "missing", "no Zoom recording with this payer around the payment time"

# ---------------- newer messages: Gmail and WhatsApp after the call ----------------
GOOGLE_CREDS = os.environ.get("GOOGLE_CREDS", "/root/.google_workspace_mcp/credentials/noah@thelongevityclinic.net.json")
_g = {"v": None, "exp": 0}

def gtoken():
    if _g["v"] and time.time() < _g["exp"] - 60:
        return _g["v"]
    c = json.load(open(GOOGLE_CREDS))
    r = httpx.post(c.get("token_uri", "https://oauth2.googleapis.com/token"), data={"client_id": c["client_id"], "client_secret": c["client_secret"],
                   "refresh_token": c["refresh_token"], "grant_type": "refresh_token"}, timeout=30)
    r.raise_for_status()
    d = r.json()
    _g["v"], _g["exp"] = d["access_token"], time.time() + d.get("expires_in", 3600)
    return _g["v"]

def _plain(part):
    import base64
    if part.get("mimeType") == "text/plain" and (part.get("body") or {}).get("data"):
        return base64.urlsafe_b64decode(part["body"]["data"] + "==").decode("utf-8", "replace")
    for c in part.get("parts") or []:
        t = _plain(c)
        if t:
            return t
    return ""

def emails_after(emails, since):
    """Emails to or from the client since the call (Noah's Gmail), oldest first."""
    if not emails:
        return []
    q = "(" + " OR ".join(f"from:{e} OR to:{e}" for e in emails) + f") after:{int(since.timestamp())}"
    G = "https://gmail.googleapis.com/gmail/v1/users/me"
    h = {"Authorization": f"Bearer {gtoken()}"}
    ids = httpx.get(f"{G}/messages", params={"q": q, "maxResults": 15}, headers=h, timeout=60).json().get("messages", [])
    out = []
    for m in ids:
        d = httpx.get(f"{G}/messages/{m['id']}", params={"format": "full"}, headers=h, timeout=60).json()
        hd = {x["name"].lower(): x["value"] for x in d.get("payload", {}).get("headers", [])}
        files = []
        def walk(p):
            if p.get("filename"):
                files.append(p["filename"])
            for c in p.get("parts") or []:
                walk(c)
        walk(d.get("payload", {}))
        body = re.split(r"\n(?:On .{5,80} wrote:|-----Original Message-----|From: )", _plain(d.get("payload", {})))[0]
        out.append({"at": int(d.get("internalDate", 0)) / 1000, "from": hd.get("from", ""), "subject": hd.get("subject", ""), "attachments": files, "text": body.strip()[:4000]})
    return sorted(out, key=lambda x: x["at"])

def whatsapp_after(names, since):
    """WhatsApp messages with the client since the call (Noah's Periskope number), oldest first."""
    env = CFG["mcp"]["servers"].get("periskope", {}).get("env", {})
    key, phone = env.get("PERISKOPE_API_KEY"), env.get("PERISKOPE_PHONE")
    if not key or not phone or not names:
        return []
    h = {"Authorization": f"Bearer {key}", "x-phone": phone}
    want = [norm(n) for n in names if len(norm(n)) >= 2]
    chat = None
    for off in range(0, 600, 100):
        d = httpx.get("https://api.periskope.app/v1/chats", params={"offset": off, "limit": 100}, headers=h, timeout=60).json()
        chats = d if isinstance(d, list) else d.get("chats", d.get("data", []))
        for c in chats:
            toks = set(norm(c.get("chat_name") or c.get("name") or ""))
            if not (c.get("is_archived") or c.get("archived")) and any(w[0] in toks and w[-1] in toks for w in want):
                chat = c; break
        if chat or len(chats) < 100:
            break
    if not chat:
        return []
    d = httpx.get(f"https://api.periskope.app/v1/chats/{quote(chat['chat_id'], safe='@.')}/messages", params={"offset": 0, "limit": 100}, headers=h, timeout=60).json()
    msgs = d if isinstance(d, list) else d.get("messages", d.get("data", []))
    out = []
    for m in msgs:
        ts = m.get("timestamp")
        try:
            at = datetime.fromisoformat(str(ts).replace("Z", "+00:00")).timestamp() if not str(ts).isdigit() else int(ts) / (1000 if int(ts) > 1e12 else 1)
        except Exception:
            continue
        if at >= since.timestamp():
            out.append({"at": at, "from": "us" if m.get("from_me") else (m.get("sender_name") or "client"), "text": (m.get("body") or f"[{m.get('message_type', 'media')}]")[:1500]})
    return sorted(out, key=lambda x: x["at"])

# ---------------- summary ----------------
def pick(obj, skip):
    found = []
    def walk(o):
        if isinstance(o, dict):
            for k, v in o.items():
                if isinstance(v, str) and k in ("text", "reply", "content", "output", "result") and v != skip:
                    found.append(v)
                else:
                    walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk(obj)
    return max(found, key=len) if found else None

FORMAT = """*Call summary – <Full name>* (<Zoom/Fathom> with <host>, <date>, <length>)

*Who:* age, where they live, one line of relevant context they gave.
*Paid:* programme, length, paid in full or instalments, amount, platform, date. Whether it matches the price quoted on the call / the Payment Links list.

*Why they joined*
• 2–4 bullets: the problems and goals they described.

*What was agreed*
• The plan, who is on their team, what happens first, any conditions.

*Already received (<email/WhatsApp>, <date time>)*
• Everything they sent after the call: labs (lab names, dates), photos, current medication and doses exactly as written, payment confirmation. Leave the section out if nothing came in.

*Next steps*
• Owner: action (date/time if set). Times with the time zone as said; if unclear add ':warning: Please confirm …'."""

def summarise(ts, post, call):
    local = call["start"].astimezone(ZoneInfo("Europe/Madrid"))
    seg = call["segment"]
    source = (f"Zoom call {local:%d %b %Y, %H:%M} Madrid time, \"{call['topic'] or 'meeting'}\", host {call['host']}"
              + (f", their part starts at minute {seg['start_min']}" if call["shared"] or seg["start_min"] > 2 else ""))
    payer = payer_from_post(post)
    since = call["start"]
    newer = []
    try:
        newer += [f"EMAIL {datetime.fromtimestamp(e['at'], ZoneInfo('Europe/Madrid')):%d %b %H:%M} Madrid · {e['from']} · {e['subject']}"
                  + (f" · attachments: {', '.join(e['attachments'])}" if e["attachments"] else "") + f"\n{e['text']}" for e in emails_after(payer["emails"], since)]
    except Exception as x:
        newer.append(f"(Couldn't read email: {str(x)[:120]})")
    try:
        newer += [f"WHATSAPP {datetime.fromtimestamp(w['at'], ZoneInfo('Europe/Madrid')):%d %b %H:%M} Madrid · {w['from']}: {w['text']}" for w in whatsapp_after(payer["names"], since)]
    except Exception as x:
        newer.append(f"(Couldn't read WhatsApp: {str(x)[:120]})")
    msg = (
        "Write the reply for a new payment in Slack #sales-payment-made, following the Payment summary playbook. Read rules.md first.\n\n"
        "PAYMENT POST:\n---\n" + post[:2500] + "\n---\n\n"
        f"CALL WHERE THEY PAID, only their part ({source}):\n---\n" + seg["text"][:60000] + "\n---\n\n"
        "EMAILS AND WHATSAPP WITH THEM SINCE THE CALL (newer than the call):\n---\n" + ("\n\n".join(newer)[:20000] if newer else "none") + "\n---\n\n"
        "FORMAT (Slack):\n" + FORMAT + "\n\n"
        "RULES:\n"
        "- Use ONLY the call above and the newer messages above. Never add people, doctors, promises, prices, pharmacies or plans that aren't in them.\n"
        "- Anything unclear or ambiguous: write ':warning: not confirmed' and what to confirm.\n"
        "- Newer messages win over the call where they differ; say so.\n"
        "- Medication names and doses exactly as the client wrote them. No advice.\n"
        "- Price flags only after checking the Payment Links master list; if it matches, no flag.\n"
        f"- First line under the title: 'Source: {source}'.\n"
        "- Plain Slack text. Do not send or post anything yourself."
    )
    try:
        r = subprocess.run([OC, "agent", "--agent", "main", "--session-key", "agent:main:payment-" + ts.replace(".", "-"),
                            "--message", msg, "--json", "--timeout", "300"], capture_output=True, text=True, timeout=360)
        out = r.stdout
        return pick(json.loads(out[out.find("{"):]), msg)
    except Exception:
        return None

def already_posted(ch, ts, me):
    d = slack("conversations.replies", channel=ch, ts=ts, limit=200)
    return any(m.get("user") == me and (m.get("text") or "").startswith(HEADER.strip()[:20]) for m in d.get("messages", [])[1:])

# ---------------- main ----------------
def run():
    os.makedirs(D, exist_ok=True)
    lock = open(LOCK, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        print("NO_REPLY"); return
    try:
        st = json.load(open(STATE))
    except Exception:
        st = {"oldest": str(time.time() - float(os.environ.get("BACKFILL_HOURS", "0")) * 3600), "items": {}}
    auth = slack("auth.test")
    me, my_bot = auth.get("user_id"), auth.get("bot_id")
    ch = st.get("channel") or channel_id()
    st["channel"] = ch
    for m in reversed(slack("conversations.history", channel=ch, oldest=st["oldest"], limit=100).get("messages", [])):
        ts = m["ts"]
        if float(ts) > float(st["oldest"]):
            st["oldest"] = ts
        if m.get("user") == me or (my_bot and m.get("bot_id") == my_bot):
            continue
        if m.get("subtype") in ("channel_join", "channel_leave", "channel_topic", "channel_purpose"):
            continue
        if m.get("thread_ts") and m.get("thread_ts") != ts:
            continue
        st["items"].setdefault(ts, {"status": "pending", "tries": 0, "seen": time.time(), "text": message_text(m)})

    alerts, done = [], 0
    for ts, it in sorted(st["items"].items()):
        if it["status"] != "pending" or done >= MAX_PER_RUN:
            continue
        try:
            if already_posted(ch, ts, me):
                it["status"] = "posted"; continue
            prog = re.search(r"program[*_\s]*:[*_\s]*([^\n]+)", it["text"], re.I)
            if prog and SKIP_PROGRAM.search(prog.group(1)):
                it["status"] = "skipped"; continue
            paid_at = datetime.fromtimestamp(float(ts), timezone.utc)
            payer = payer_from_post(it["text"])
            if not payer["names"] and not payer["emails"]:
                it["status"] = "failed"; alerts.append(f"Payment {ts}: couldn't tell who paid from the post"); continue
            status, call = find_call(paid_at, payer)
            it["last_check"] = f"{time.strftime('%H:%M')} {status}: {call if isinstance(call, str) else call['topic']}"
            if status == "wait":
                continue                       # next run; never fall back to older sources
            if status == "missing":
                it["status"] = "failed"
                who = (payer["names"] or payer["emails"])[0]
                alerts.append(f"Payment {ts} ({who}): {call}. No summary posted; check Zoom.")
                continue
            done += 1
            it["tries"] += 1
            s = summarise(ts, it["text"], call)
            if s:
                slack("chat.postMessage", channel=ch, thread_ts=ts, text=HEADER + s)
                it["status"] = "posted"
                it["source"] = f"{call['topic']} {call['start']:%Y-%m-%d %H:%M} from minute {call['segment']['start_min']}"
            elif it["tries"] >= 3:
                it["status"] = "failed"; alerts.append(f"Payment {ts}: Jarvis couldn't write the summary after 3 tries")
        except Exception as x:
            alerts.append(f"Payment {ts}: {str(x)[:200]}")
    cutoff = time.time() - 14 * 86400
    st["items"] = {k: v for k, v in st["items"].items() if v["seen"] > cutoff or v["status"] == "pending"}
    json.dump(st, open(STATE, "w"))
    print("Payment summary problems:\n- " + "\n- ".join(alerts) if alerts else "NO_REPLY")

def test(ts):
    """Dry run for one payment post (Slack ts): prints which call was found and the summary. Posts nothing, saves nothing."""
    ch = channel_id()
    m = slack("conversations.history", channel=ch, latest=ts, inclusive="true", limit=1)["messages"][0]
    text = message_text(m)
    payer = payer_from_post(text)
    print("Payer:", payer)
    status, call = find_call(datetime.fromtimestamp(float(ts), timezone.utc), payer)
    if status != "found":
        print(status, call); return
    print(f"Call: {call['topic']} | {call['start']:%Y-%m-%d %H:%M} UTC | host {call['host']} | shared: {call['shared']} | from minute {call['segment']['start_min']}")
    print("\n" + (summarise("test-" + ts, text, call) or "(Jarvis returned nothing)"))

if __name__ == "__main__":
    import sys
    if len(sys.argv) == 3 and sys.argv[1] == "--test":
        test(sys.argv[2])
    else:
        run()
