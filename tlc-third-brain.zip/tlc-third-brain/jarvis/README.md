# Jarvis (server side)

Jarvis is Noah's AI chief of staff: OpenClaw with the Claude API, reachable on WhatsApp and Telegram, running on the VPS.

This folder holds everything Jarvis runs on the server. It was assembled from the build sessions; **the server is the source of truth**, so refresh it from there whenever something changes:

```bash
bash jarvis/collect.sh        # from the repo root; pulls from root@187.126.15.145
git diff                      # review
git commit -am "Jarvis: sync from server"
```

| Folder | Server path | Contents |
| --- | --- | --- |
| `scripts/` | `/root/jarvis/` | Python jobs (calendar briefs, payment summaries, playbooks sync, run monitor, WhatsApp/Google health, Zoom to Drive) |
| `bin/` | `/usr/local/bin/` | Wrappers the cron jobs call (`jarvis-*`, `brain-automations`, `transcribe`) |
| `workspace/` | `/root/.openclaw/workspace/` | `AGENTS.md`, `SOUL.md`, `USER.md`, `rules.md`, live / approved / proposed playbooks |
| `config/` | `/root/.openclaw/openclaw.json`, cron | OpenClaw config **with secrets redacted**, cron job list, crontab, tunnel config |

Not copied, on purpose: `.env` files, credentials, Jarvis's memory (`MEMORY.md`, `memory/`), patient files, logs.

Restoring the config on a new server: copy `config/openclaw.json`, then put each `<redacted>` value back from the password manager.

## Jobs and what runs them

| OpenClaw cron job | Command | Source |
| --- | --- | --- |
| Calendar briefs (pre-call briefs) | `bin/jarvis-calendar-briefs` | `scripts/calendar_briefs.py` |
| Payment summaries | `/usr/local/bin/jarvis-payment-summaries` | `scripts/payment_summaries.py` |
| Playbooks sync (Drive → playbooks-live) | | `scripts/playbooks_sync.py` |
| Run monitor | `bin/jarvis-run-monitor` | |
| WhatsApp / Google health checks | `bin/check-whatsapp`, `bin/check-google` | |
| Zoom recordings to Drive | | `scripts/zoom_to_drive.py` |
| Patient call summaries | `scripts/patient_summary.sh` | |
| Sales calls filing (daily 06:30 UTC): every sales call transcript → WON / NOT WON in the Sales knowledge base | `/usr/local/bin/jarvis-sales-calls` | `scripts/sales_calls_filing.py` |
| Brain automations (every 5 min) | `/usr/local/bin/brain-automations` | `dashboard/scripts/automations-setup.sh` |
| Nightly gateway restart, backup | `bin/jarvis-nightly-restart`, `bin/jarvis-backup` | |

Agent jobs (WhatsApp digest, morning brief, week plan, Monday review) are prompts inside OpenClaw's cron config; see `config/cron-jobs.json` after the first `collect.sh`.

`workspace-research/` is the separate research agent that does web browsing for Jarvis.
