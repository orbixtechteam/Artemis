#!/bin/bash
# Run on the server: bash /root/jarvis/install-backup.sh
set -e
cp /root/jarvis/jarvis-backup /usr/local/bin/jarvis-backup && chmod +x /usr/local/bin/jarvis-backup
command -v sqlite3 >/dev/null || apt-get install -y sqlite3 >/dev/null
echo "== Why the old one stopped (last lines of the log):"; tail -5 /var/log/jarvis-backup.log 2>/dev/null || echo "(no log)"
echo "== Drive connection:"; rclone lsd gdrive:Jarvis 2>&1 | head -3
echo "== Running a backup now:"; /usr/local/bin/jarvis-backup | tee -a /var/log/jarvis-backup.log
( crontab -l 2>/dev/null | grep -v jarvis-backup; echo "30 2 * * * /usr/local/bin/jarvis-backup >> /var/log/jarvis-backup.log 2>&1" ) | crontab -
echo "== Scheduled nightly at 02:30 (server time):"; crontab -l | grep jarvis-backup
echo "== In Drive:"; rclone ls gdrive:Jarvis/Backups | tail -3
