#!/bin/bash
# Copies Jarvis's server side into this folder so it can be committed, with every secret removed.
# Run from the repo root on your Mac:  bash jarvis/collect.sh
# Never copies: .env files, credentials, Jarvis's memory (MEMORY.md, memory/), patient files, logs.
set -euo pipefail
SERVER="${SERVER:-root@187.126.15.145}"
cd "$(dirname "$0")"
rm -rf scripts bin workspace config && mkdir -p scripts bin workspace config

ssh "$SERVER" 'bash -s' << 'REMOTE' | tar -xzf - -C .
set -e
export PATH=/root/.nvm/versions/node/v24.22.1/bin:$PATH
T=$(mktemp -d)
mkdir -p $T/scripts $T/bin $T/workspace $T/config
# Jarvis's own scripts (Python jobs, helpers), without data or state
[ -d /root/jarvis ] && (cd /root/jarvis && find . -maxdepth 2 -type f \( -name '*.py' -o -name '*.sh' -o -name '*.md' -o -name '*.toml' \) -print0 | xargs -0 -r cp --parents -t $T/scripts)
# Command wrappers the cron jobs call
for f in /usr/local/bin/jarvis-* /usr/local/bin/brain-automations /usr/local/bin/transcribe; do [ -f "$f" ] && cp "$f" $T/bin/; done
# Workspace: instructions, rules, playbooks (no memory, no data)
W=/root/.openclaw/workspace
for f in AGENTS.md SOUL.md USER.md TOOLS.md HEARTBEAT.md IDENTITY.md rules.md; do [ -f "$W/$f" ] && cp "$W/$f" $T/workspace/; done
for d in playbooks-live playbooks-approved playbooks-proposed; do [ -d "$W/$d" ] && cp -r "$W/$d" $T/workspace/; done
# OpenClaw config with every secret replaced
python3 - "$T/config/openclaw.json" << 'PY'
import json, re, sys
c = json.load(open("/root/.openclaw/openclaw.json"))
SECRET_KEY = re.compile(r"(key|token|secret|password|passwd|auth|bearer|cookie|credential|private)", re.I)
SECRET_VAL = re.compile(r"^(sk-|xox|GOCSPX|tb_|ghp_|AIza|AKIA|eyJ)")
def clean(x, k=""):
    if isinstance(x, dict): return {kk: clean(v, kk) for kk, v in x.items()}
    if isinstance(x, list): return [clean(v, k) for v in x]
    if isinstance(x, str) and (SECRET_KEY.search(k) or SECRET_VAL.match(x) or len(x) > 40 and re.fullmatch(r"[A-Za-z0-9_\-\.=+/]{40,}", x)): return "<redacted>"
    return x
json.dump(clean(c), open(sys.argv[1], "w"), indent=2)
PY
openclaw cron list --json 2>/dev/null | python3 -c "import json,sys; d=json.load(sys.stdin); [j.pop('state',None) for j in d.get('jobs',[])]; print(json.dumps(d, indent=2))" > $T/config/cron-jobs.json || true
crontab -l > $T/config/crontab.txt 2>/dev/null || true
[ -f /etc/cloudflared/config.yml ] && grep -v -i 'credentials' /etc/cloudflared/config.yml > $T/config/cloudflared-config.yml || true
# remove anything that still looks like a secret line in scripts
grep -rlIE 'sk-ant-|xox[abp]-|GOCSPX-|tb_[A-Za-z0-9]{24}' $T 2>/dev/null | xargs -r sed -i -E 's/(sk-ant-|xox[abp]-|GOCSPX-|tb_)[A-Za-z0-9_-]+/\1<redacted>/g'
tar -czf - -C $T .
rm -rf $T
REMOTE

echo "Collected:"; find . -type f -not -name collect.sh -not -name README.md | sed 's|^\./|  |' | sort | head -80
echo "Now review with: git status && git diff, then commit."
