# rules.md — What the assistant has learned

One rule per line. Noah can edit or delete any line.

Format:
`- [status] [kind] Rule text — source: <type> <reference> — <YYYY-MM-DD>`

- status: `active`, `candidate`, `rejected`, `superseded`
- kind: `style`, `fact`, `preference`, `policy`
- source type: `edit`, `correction`, `approval`, `manual`

Only `active` rules are used. `candidate` rules wait for the Sunday review.

Example:
`- [active] [fact] Derek handles refunds, not Milica — source: correction telegram-msg-1234 — 2026-10-26`

## Rules

(none yet)
