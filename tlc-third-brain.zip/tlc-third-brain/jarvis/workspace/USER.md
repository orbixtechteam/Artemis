<!-- Reconstructed from the build sessions (17 Nov 2026). The server copy is the source of truth: run `bash jarvis/collect.sh` to replace this with the exact file. -->

# USER.md — Noah Laith

## Work pattern

- Around 10 sales calls a day, 7 days a week.
- Also responsible for clinical direction, operations, partnerships, Pepcura, the Skool community and content.
- Goal: step out of day-to-day operations without anything falling through the cracks.

## Time zones

Noah moves between three time zones. Always state which one you mean.

- Dubai: GST, UTC+4 (no daylight saving)
- Greece: EET, UTC+2 / EEST, UTC+3 in summer
- Spain: CET, UTC+1 / CEST, UTC+2 in summer

TODO (with Noah): which time zone is the default for the morning brief and scheduling.

## Companies

- **The Longevity Clinic**: Dubai, Miami, New York, Athens, Vilnius
- **Pepcura**
- **GMP manufacturing group**
- **SciComWiz**
- **The Peptide Doctors** (Skool community)

TODO (with Noah): one or two lines per company on what it does and who leads it.

## Team

| Name | Role | Preferred channel | Escalate to |
| --- | --- | --- | --- |
| Milica | TODO | TODO | TODO |
| James | TODO | TODO | TODO |
| Derek | TODO (handles refunds?) | TODO | TODO |
| Maher | TODO | TODO | TODO |
| Roni | Asana / TODO | TODO | TODO |
| Lara | Reviews LinkedIn drafts / TODO | TODO | TODO |
| Henk | Building agentic AI for finance and fulfilment | TODO | TODO |

## Priorities this quarter

TODO (with Noah)

## Decision rules

TODO (with Noah): how he decides what matters, what can wait, what to delegate.

## Things Noah never wants to handle himself

TODO (with Noah)

## Telegram accounts

- Noah Laith (@biohackerdubai), Telegram ID 949832775: owner, full access.
- Ulvi, Telegram ID 8619174084: setup developer, full access during setup, approved by Noah.

## Current location

Noah is currently in Europe (Amsterdam / Spain). Default time zone: Europe/Madrid (CET). Update this when he moves.
