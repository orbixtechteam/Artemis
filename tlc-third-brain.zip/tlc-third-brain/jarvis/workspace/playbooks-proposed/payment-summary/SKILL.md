# Payment summary

## Purpose
When a client pays (a new post in #sales-payment-made), reply in that post's thread with a short, factual summary the team can act on: who they are, what they paid for, why they joined, what was agreed, what they have already sent us, and the next steps with owners. The standard is Claude's reply in Robynne de Courtenay's thread (18 Nov 2026).

## When
A new payment post in #sales-payment-made for a programme (not B2B orders, product orders or consultations without a call).

## Inputs (gathered by the script, in this order)
1. The payment post: client, email, amount, programme, date.
2. The sales call where they paid: found in Zoom by speaker name and email, only their part of a shared Personal Meeting Room recording. Source line names the date, time and minute.
3. Emails with the client after the call (Noah's Gmail).
4. WhatsApp messages with the client after the call.
5. The Payment Links master list, for price checks.

## Format (Slack, in the thread)
*Call summary – <Full name>* (<Zoom/Fathom> with <host>, <date>, <length>; earlier calls only if mentioned on this call)

*Who:* age, where they live, one line of relevant context they gave.
*Paid:* programme, length, paid in full or instalments, amount and currency, platform, date. Say whether it matches the price quoted on the call / the Payment Links list.

*Why they joined*
• 2–4 bullets in plain words: the problems and goals they described.

*What was agreed*
• What the plan is, who is on their team, what happens first, any conditions (e.g. COA checks).

*Already received (<source>, <date time>)*
• Everything they sent after the call: labs (with lab names and dates), photos, current medication with doses exactly as written, payment confirmation.

*Next steps*
• Owner: action (date/time if set). Calls with the time zone as said; if unclear, add ":warning: Please confirm …".

## Rules
- Only facts stated on the call or in the newer emails / WhatsApp. Never add people, promises, names, prices or plans that weren't said.
- Anything unclear or ambiguous: mark it ":warning: not confirmed" and say what to confirm.
- Newer messages win over the call when they conflict; say so.
- Doses and medication names exactly as written by the client; no interpretation, no advice.
- Price flags only after checking the Payment Links master list.
- No guesses about doctors: write "Doctor: assign after …" unless a doctor was named for this client on the call.
- If the call can't be found, don't write a summary from older calls; say it's waiting for the recording.

## Done right when
Every line can be traced to the call (minute) or a dated message, the next steps have owners, and nothing in it would need correcting by Noah.

## Approval
Noah approves the playbook and checks the first 5 summaries.
